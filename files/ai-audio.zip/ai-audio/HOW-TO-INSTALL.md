# How To Add AI Audio To Your Content

*Installation guide*

This skill works by giving your AI assistant deep knowledge about producing AI-generated audio — voice selection, scripting for the ear, generation, syncing with visuals, and building a repeatable workflow. Once it's set up, you can ask it for help on any audio project and it'll bring the whole methodology to bear without you having to remind it what it knows.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "AI Audio" or "Audio Production"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/choosing-the-right-ai-voice.md`
- `references/scripting-for-audio.md`
- `references/generating-and-editing.md`
- `references/syncing-with-visuals.md`
- `references/the-audio-workflow.md`
- `assets/voice-selection-worksheet.md`
- `assets/audio-script-templates.md`
- `assets/audio-brand-kit.md`
- `assets/audio-workflow-checklist.md`

**Step 3: Add your audio production context**

In the **Project instructions** field, paste and complete the following:

```
My work: [What you do — coach, consultant, founder, creator, etc.]
What audio I'm making: [Course narration, video voiceovers, social clips, podcast intros, etc.]
My current AI audio tool (if any): [ElevenLabs / Play.ht / Descript / not yet decided]
My experience level: [None / I've made a few / I produce regularly]
My main project right now: [What you're trying to make this week]
My Audio Brand Kit (if you have one): [Paste it here, or leave blank — we'll build one in the first conversation]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to an audio producer who already knows your goals and your sound.

A good first message: *"Walk me through producing my first AI-narrated video. I've got a 90-second script and I'm about to open ElevenLabs."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "An audio production coach who helps me add AI-generated narration to my videos, slides, and content. Knows the full workflow from voice selection to export."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all five files in `references/`, and all four in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical audio production coach. Use the uploaded knowledge files to guide every response. Always work from my actual project, not in the abstract. Apply the five-stage workflow (brief → script → audio → sync → export). Have opinions and share them.

My context:
- What I do: [fill in]
- What audio I'm making: [fill in]
- Current AI audio tool: [fill in or "not yet decided"]
- Experience level: [fill in]
- Audio Brand Kit (if you have one): [paste it, or leave blank]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *AI Audio*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- What I do: [fill in]
- What audio I'm making: [fill in]
- Current AI audio tool: [fill in or "not yet decided"]
- Experience level: [fill in]
- Audio Brand Kit (if you have one): [paste it]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your audio production

Three things matter most:

**Your work and what you're making.** "I'm a coach who's about to launch a course and I want to narrate the modules myself" is far more useful than "I'm a coach". Give the actual project shape.

**Your current tool, or that you don't have one yet.** If you've already chosen ElevenLabs or Play.ht, the skill will tailor recommendations to that tool. If you haven't, the first conversation can include picking one — the right answer depends on what you're making.

**Your Audio Brand Kit, if you have one.** If you don't, the worksheet in `assets/audio-brand-kit.md` walks you through building one. Twenty minutes of work; pays off forever.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Walk me through producing my first AI-narrated video, end to end."*
- *"Compress this blog post into a 60-second voiceover script in my voice."*
- *"Help me build my Audio Brand Kit — let's start with voice and tone."*
- *"My narration sounds rushed. What do I tweak?"*
- *"Should I clone my voice or use a preset for [project]? Talk me through the call."*
- *"Run the audio workflow checklist on this project — here's where I'm up to."*
- *"AI keeps mispronouncing [word]. Fix it."*

---

*AI Audio is part of the Fluent skill library. More skills at fluent.md.*
