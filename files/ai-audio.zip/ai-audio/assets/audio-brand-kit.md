# Audio Brand Kit

A single document that captures every settled choice about how your audio sounds. Filled in once, consulted before every new project, updated as your sound evolves.

Twenty minutes to fill in. Pays off forever.

---

## Why this matters

Without a Brand Kit, every audio project starts from scratch. Voice picked again. Settings re-dialled. Music re-chosen. The work creeps back to thirty minutes per piece even after you've made dozens.

With a Brand Kit, every new project starts at minute five. You open the file, copy the settings, paste your script, and you're producing in under ten minutes. The work compounds because the decisions are already made.

---

## 1. Voice profile

The actual voice you use for most content.

**Tool:** _______________ (e.g., ElevenLabs, Play.ht, Descript)

**Voice name or "Cloned — me":** _______________

**Voice ID or model identifier (if applicable):** _______________

**Notes on why this voice:** _______________

---

## 2. Settings

The dial positions you've landed on.

**Default speed:** _______________ (e.g., 1.0x, or 0.97x for tutorials)

**Stability or consistency setting:** _______________ (if applicable)

**Expressiveness or emotion setting:** _______________ (if applicable)

**Clarity or similarity setting:** _______________ (if applicable, mostly ElevenLabs)

**When I deviate from defaults:** _______________

---

## 3. Tone notes

How the voice should *feel*. Two or three adjectives.

**Primary tone (most projects):** _______________

**Secondary tone (when the topic calls for it):** _______________

**Tones I'd never use:** _______________

---

## 4. Reusable phrases

The intros, sign-offs, and bumpers you'll use across projects. Three or four of each is plenty.

**Openers / intros:**

1. _______________
2. _______________
3. _______________

**Closers / sign-offs:**

1. _______________
2. _______________
3. _______________

**Section breaks (if you use them):**

1. _______________
2. _______________

---

## 5. Sound elements

The non-voice components.

**Background music — go-to tracks:**

1. _______________ (license source)
2. _______________ (license source)
3. _______________ (license source)

**Music level under voice:** _______________ (e.g., voice +12dB above music, or "drop music ~70% under voice")

**Sound effects or audio bumpers:**

_______________

**Music or SFX I'd never use:**

_______________

---

## 6. File management

Boring but vital. Where everything lives.

**Folder convention for new projects:**

```
[fill in your folder structure]
```

**Naming pattern for files:**

_______________

**Where source scripts are kept:**

_______________

**Where final audio masters are kept:**

_______________

**Cloud backup or local-only?:**

_______________

---

## 7. Ethics and disclosure

How you handle the trust side.

**Public-facing disclosure habit:** _______________ (e.g., "Audio uses my AI-cloned voice — disclosed in description")

**Who has consented to voice use (if multiple voices in catalogue):** _______________

**Where original voice sample recordings are stored:** _______________

---

## Worked example (partially filled)

```
1. Voice profile
   - Tool: ElevenLabs
   - Voice: Cloned — Lucy (trained March 2026)
   - Notes: Slightly drier than my live speaking voice. Tested against
     three projects, holds up across registers.

2. Settings
   - Default speed: 1.0x
   - Stability: 50%
   - Clarity: 75%
   - When I deviate: 0.97x for course modules longer than 5 minutes

3. Tone notes
   - Primary: warm but direct, occasionally dry
   - Secondary (when topic calls): considered and slow
   - Never: hyped, breathless, "podcast voice"

4. Reusable phrases
   - Openers: "Right." / "Quick one for you today." / "Hello."
   - Closers: "That's the lot — back tomorrow." / "Right, off you go."
   - Section breaks: short two-second silence (no audio bumper)

5. Sound elements
   - Music: minimal-piano licensed track from Artlist (track A); ambient
     pad from Soundstripe (track B). Always behind voice, never lead.
   - Music level: voice ~12dB above music
   - SFX: none — clean voice only

6. File management
   - Folder: /audio/[YYYY-MM-DD-project-slug]/
   - Files: script-final.md, audio-master.wav, audio-export.mp3, settings-notes.md
   - Backup: synced to Dropbox

7. Ethics
   - Public disclosure: footer line on description: "This voiceover uses
     my AI-cloned voice for production efficiency."
   - Consent: only my own voice used.
   - Originals: stored locally in /audio/_voice-samples/, not shared.
```

---

## Update rhythm

Re-read the Brand Kit at the start of each new quarter. Update one or two lines if anything has genuinely shifted. Most updates are small — a new music track that worked, a refined tone note, a new opener that you've started using by default.

The file should grow slightly each quarter. If you're rewriting it from scratch, you've drifted too far and it's time to take stock.
