# Audio Script Templates

Working starter scripts for the formats you'll write most often. Each one is structured for the ear — short sentences, contractions throughout, paragraph breaks where you want pauses, no numbers or acronyms unless essential.

Adapt the structure. Replace the placeholder content. Read the result aloud once before generating.

---

## 30-second social clip

For LinkedIn, Instagram Reels, TikTok, X clips. One hook, one idea, one close. Roughly 65–75 words.

```
[HOOK — one specific sentence that names a sharp observation or contrarian
take. Not a question. Not a setup. The point itself.]

[ONE IDEA — three or four short sentences expanding the hook into a single
useful insight. One thing the listener hadn't quite put together themselves.
Read aloud. Cut anything that doesn't pull weight.]

[CLOSE — one short sentence that lands. Either an invitation to think, or
the takeaway in five words. No CTAs. No "follow for more". The clip ends
when the idea ends.]
```

**Filled example:**

```
Most people don't have a pricing problem. They have a confidence problem.

The price they're charging is fine. The story they tell themselves about
the price is the part that's broken. They quote, they flinch, the client
hears the flinch, the deal falls apart.

You don't fix that with a new price sheet. You fix it by deciding the
price is the price. Then you tell people, calmly. Then they pay it.
```

---

## 60-second voiceover for a video or carousel

For explainer videos, talking-head reels, carousel narration. Roughly 130–150 words.

```
[CONTEXT — two short sentences that set up what this is and why it matters
to the listener right now. Specific, not generic.]

[THE POINT — three or four sentences that deliver the actual idea.
Concrete. One thing per sentence.]

[EVIDENCE OR EXAMPLE — two or three sentences that prove it. A number you
can defend, a specific case, a contrast. One example beats five general
claims.]

[ACTION — one sentence on what to do next. Not "join my list". Something
the listener can do today, in the next five minutes if they wanted to.]
```

---

## 3-minute explainer or training segment

For longer-form video, training modules, in-depth pieces. Roughly 400–450 words.

```
[OPEN — three sentences that frame the question this piece answers. Open
on a specific scene or claim, not a generality.]

[WHY THIS MATTERS — two short paragraphs naming what's at stake for the
listener. Don't over-explain. They came in already half-knowing.]

[THE FRAMEWORK — the central thing you're teaching, broken into three
or four parts. Each part gets one short paragraph. Use ordinal markers
("First," "Then," "After that") rather than numbered lists.]

[A WORKED EXAMPLE — two paragraphs walking through the framework on a
specific real case. This is where most explainers get vague. Don't.]

[CLOSE — one paragraph. The takeaway in plain language, plus what to
think about between now and the next time this comes up.]
```

---

## Welcome / introduction (course module, podcast, lead magnet)

For the first thing a new audience hears. Sets the tone for everything that follows. Roughly 90–120 words.

```
[GREETING — one short sentence. "Welcome." "Hello." "Right." Whatever
sounds like you. Avoid "Hi everyone" and "Welcome to my channel".]

[WHO YOU ARE, IN ONE SENTENCE — your name and what you do, told from the
listener's angle. "I help [audience] with [outcome]" is plenty.]

[WHAT THIS IS — one or two sentences naming what they're about to listen
to and why it'll be worth their time.]

[WHAT TO EXPECT — one sentence on length, format, or shape so they can
settle in. "This will take about twenty minutes" goes a long way.]

[HANDOFF — one short sentence pointing them at the first real piece of
content. "Let's start with..." "First up..." "The thing to know first is..."]
```

**Filled example:**

```
Right. Welcome.

I'm Lucy. I help coaches and consultants use AI to scale their content
without losing the voice their clients trust.

This is a five-step workshop on adding AI audio to your content.
Twenty-five minutes, no faff, you'll have your first narrated clip
finished by the end of it.

Each step is short. You'll do the actual work as you go, not
afterwards.

Let's start with picking the right voice.
```

---

## Sign-off / outro

For the last thing they hear. Short, definite, ends cleanly.

```
[ONE-SENTENCE SUMMARY — the takeaway in plain language.]

[ACKNOWLEDGEMENT — one sentence that thanks them or names what's next.
Optional. Often unnecessary.]

[CLOSE — a phrase that's recognisably yours. "See you next week."
"That's the lot." "Right, off you go." Whatever lands as you, every
time.]
```

**Filled example:**

```
That's the framework. Voice, script, generate, sync, and a workflow
that makes the next project faster than the last.

Go press record on something this week. Even badly. Especially badly.

Right. Off you go.
```

---

## A few rules that apply to every template

**Read the script aloud before generating.** The single most useful step. Anything that trips your tongue gets fixed before AI ever sees it.

**Cut everything that doesn't pull weight.** Audio rewards space. Sentences that look fine on paper but don't earn their seconds get cut.

**Numbers, names, acronyms get special treatment.** Spell phonetically, write out long-form, or rewrite around. Don't trust the AI to handle them on the first pass.

**One idea per sentence.** The listener can't backtrack. Multi-clause sentences become wallpaper.

**Contractions throughout.** "You'll" not "you will". "Don't" not "do not". Without exception unless emphasising.

These five rules carry most of the load. Get them right and any of the templates above works. Skip them and the best template won't save the script.
