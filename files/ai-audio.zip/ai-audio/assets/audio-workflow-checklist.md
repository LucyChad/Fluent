# The Audio Workflow Checklist

Run this on every audio project from brief to publish. Five stages, twenty checks, ten minutes of overhead. Saves an hour of "wait, I forgot to..." per project.

---

## Stage 1 — Brief

Before you write a word of script.

- [ ] **Project clear.** What this is, where it'll live, who it's for. Three lines max in your project notes.
- [ ] **Length target set.** 30s / 60s / 3min / longer. Word count derived from length.
- [ ] **Tone decided.** Primary feel + secondary feel. Two adjectives each.
- [ ] **Voice chosen.** From the Brand Kit if defaults apply, or a fresh selection if this project sits outside the usual.

If any of these are unclear, stop. Don't write the script yet. Vague briefs produce vague scripts which produce wandering audio.

---

## Stage 2 — Script

The script is the single biggest determinant of audio quality. Most fixes happen here.

- [ ] **Drafted or compressed.** Either written from scratch or compressed from existing content using AI.
- [ ] **One idea per sentence.** Multi-clause sentences split into two or three.
- [ ] **Contractions throughout.** "You'll" not "you will" everywhere.
- [ ] **Numbers, names, acronyms handled.** Spelled phonetically, written long-form, or rewritten around.
- [ ] **Read aloud.** Once. Properly out loud. Anything that trips you up gets fixed before generation.
- [ ] **Within length budget.** 130–150 words per minute as a rough rule.

If the script doesn't pass the read-aloud test, no AI tool will save it.

---

## Stage 3 — Audio

Generation and refinement.

- [ ] **Voice tested on real script.** Two or three options auditioned on a real paragraph, not the tool's sample text.
- [ ] **Settings dialled in.** Speed, stability, expressiveness — defaults from Brand Kit unless this project warrants different.
- [ ] **Generated.** Full pass produced.
- [ ] **Listened to end-to-end.** All the way through, not just the first ten seconds.
- [ ] **Refinements applied.** Pronunciation fixes, pacing adjustments, emphasis tweaks. Maximum two passes.
- [ ] **Exported in the right format.** MP3 for audio-only output, WAV if it'll be edited further into video.

---

## Stage 4 — Sync

Only relevant if there are visuals.

- [ ] **Audio dropped onto timeline first.** Visuals come second, always.
- [ ] **Visuals placed against natural beats.** Slide changes at full stops, not mid-sentence.
- [ ] **Music level checked.** Voice clearly louder than music. Tested on a phone speaker.
- [ ] **Transitions smooth.** Half-second pauses between major sections. No mid-sentence cuts.
- [ ] **Full preview watched.** End-to-end, no skipping, before export.

---

## Stage 5 — Export and store

The final tidy.

- [ ] **Right format and resolution for destination.** MP4 1080p for most video. Square or vertical if going to social.
- [ ] **Captions added if going to social.** Most viewers watch sound-off.
- [ ] **File saved with naming convention.** Per Brand Kit folder rules.
- [ ] **Source script saved alongside.** Same folder as the audio.
- [ ] **Settings notes updated.** One line: what worked, one line: what to fix next time.

---

## When to skip a step

Honest answer: never, for the first ten projects. Skipping steps before you've internalised them produces inconsistent output and you can't tell which step you skipped without going back through.

After ten projects, you'll know which checks are second-nature and which still benefit from being explicit. Drop the second-nature ones from the explicit checklist. Keep the rest.

The five checks people most often regret skipping:

1. Reading the script aloud (saves entire regenerations)
2. Auditioning voices on real script (saves picking the wrong voice)
3. Listening end-to-end before export (catches the things you'll otherwise notice in public)
4. Music level on phone speakers (the most common quality fail)
5. Saving source script alongside audio (six months later, future you needs it)

Keep these even when you've got everything else automatic.

---

## Time benchmark

A 60-second narrated video, going through the full checklist, in a tool you know:

- Brief: 5 minutes
- Script: 10 minutes
- Audio: 10 minutes
- Sync (if visuals): 15 minutes
- Export and store: 5 minutes

**Total: roughly 45 minutes from brief to published.**

If you're spending twice that, two things are usually happening: the script is being rewritten in the audio stage (caught by reading aloud), or the voice was wrong and you're re-generating (caught by auditioning on real script). Both come back to skipping Stage 2.
