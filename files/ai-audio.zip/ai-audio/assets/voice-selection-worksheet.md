# Voice Selection Worksheet

A short structured exercise to pick the right AI voice for a project before you ever open a tool. Five minutes of decisions here saves an hour of wandering through voice libraries auditioning the wrong things.

Use this for any new project where the voice choice isn't obvious — which, in practice, is almost every project.

---

## 1. What is this audio for?

Be specific. Not "a video" — a 60-second LinkedIn explainer. Not "a course" — module 3 of an onboarding series for new clients. The format shapes everything else.

**This audio is for:**

_______________________________________________

_______________________________________________

---

## 2. How long will it be?

Rough length matters because it affects how much variation in tone the voice needs to hold. A 30-second clip can lean on one strong note. A 5-minute training segment needs warmth and range that holds up over time.

**Length:**

- [ ] Under 30 seconds (social-style)
- [ ] 30–90 seconds (typical voiceover)
- [ ] 2–5 minutes (explainer or short module)
- [ ] 5+ minutes (training, podcast, longer-form)

---

## 3. How do I want the listener to feel by the end of the first sentence?

The single most important question. The voice has to land that feeling before the words can do their work.

Pick one primary, one secondary:

**Primary feel:**

- [ ] Calm and steady
- [ ] Warm and friendly
- [ ] Confident and direct
- [ ] Energetic and bright
- [ ] Considered and thoughtful
- [ ] Other: _______________

**Secondary (the supporting note):**

- [ ] Calm and steady
- [ ] Warm and friendly
- [ ] Confident and direct
- [ ] Energetic and bright
- [ ] Considered and thoughtful
- [ ] Other: _______________

---

## 4. Is this me, or someone else?

This is the cloned-voice-or-preset call.

- [ ] **My voice (cloned).** This is personal-brand content, course narration, a podcast, or anything where my actual voice is part of the trust.
- [ ] **Preset voice.** This is utility content, an explainer, social, or a project where the voice doesn't need to be specifically mine.
- [ ] **Mixed.** Long-form where I'll use my voice for the personal moments and a preset for the rest.

If you're unsure, default to preset. Cloning is worth it when you're producing audio regularly enough that listeners would benefit from recognising the same voice.

---

## 5. Which tool fits this job?

Cross-reference against the tone, length, and budget for the project.

- [ ] **ElevenLabs** — best voice quality, strongest cloning, multilingual. For anything customer-facing or on-brand.
- [ ] **Play.ht** — fast, web-based, friendly UI. For quick projects and short-form.
- [ ] **Descript** — full audio/video editing suite. For when audio and video editing happen together.
- [ ] **Other:** _______________

---

## 6. The brief

Combine your answers into a three-line brief you'll keep next to the project as you produce it.

```
Project: [from Q1]
Length target: [from Q2]
Voice: [my cloned voice / Adam preset / etc]
Feel: [primary feel] with notes of [secondary feel]
Tool: [from Q5]
Test paragraph: [paste a paragraph of the actual script you'll use to audition voices]
```

---

## Worked example

```
Project: 60-second voiceover for a LinkedIn carousel about pricing your services
Length target: 60 seconds (~140 words)
Voice: ElevenLabs preset — auditioning Adam, Bill, Sam first
Feel: confident and direct, with notes of warm
Tool: ElevenLabs
Test paragraph: "Most pricing problems aren't pricing problems. They're confidence problems. The price is fine. The story you tell yourself about the price is broken."
```

That brief takes ninety seconds to fill in and saves the rest of the production.

---

## Audition rule

Audition voices on your real script paragraph, not the tool's sample text. The right voice becomes obvious within thirty seconds. The wrong voice on real content reveals itself; the wrong voice on sample text doesn't.

If two voices both feel right, pick the one that feels more "you" overall — you'll be using it again on the next project, and consistency compounds.
