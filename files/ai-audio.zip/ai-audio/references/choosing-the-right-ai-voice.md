# Choosing the Right AI Voice

## The decision that shapes everything else

The voice is the single biggest call in the entire project. Get it right and the rest of the work flows — your script polish lands, your sync looks easy, your audience leans in. Get it wrong and no amount of editing fixes it. People feel a wrong voice within the first six seconds and stop listening.

There are only a few real decisions to make. None of them are particularly technical. They're all about matching the project to the right kind of voice and the right tool to produce it.

## The three formats

AI audio comes in three flavours. Each one suits different projects and different stages of comfort with the tools.

**Text-to-speech (TTS).** You paste your script, pick a voice from a preset library, hit generate. The voice isn't yours. It's chosen from a catalogue of pre-built ones. Quick, reliable, perfect for explainers, social clips, training modules, and anything you need to ship today. Most users start here and many never need to leave.

**Cloned voice.** You train the AI on samples of your real voice, and from then on it can read any script in your tone and rhythm. Perfect for personal brand content, course narration, welcome videos, podcast intros — anywhere the user's actual voice is part of the trust the audience is buying. Higher set-up cost (an hour or two), much higher payoff if you produce regularly.

**Mixed narration.** A blend — the user's cloned voice for the personal sections (intros, sign-offs, headline points), a preset voice for the rest. Good for long-form content, courses with multiple modules, or anything where variety improves listening experience. More production complexity but worth it for the right project.

When to use which:

- **TTS:** explainers, demos, social-length clips, short-form content where the voice matters less than the message
- **Cloned voice:** personal brand content, course or membership narration, welcome and onboarding videos, anywhere "this is me" is part of the trust signal
- **Mixed narration:** longer pieces (10+ minutes), multi-module training, content that benefits from rhythmic variety

If a user is hesitating, default to TTS. They can clone later. Most projects don't need cloning.

## Picking a voice that fits the project

Tone matters more than voice gender, accent, or any other surface feature. The first question is always: how do I want the listener to feel by the end of the first sentence?

- **Calm and steady** for instructional content, demos, anything technical
- **Warm and friendly** for welcome messages, customer service, brand storytelling
- **Confident and direct** for sales, leadership content, opinion pieces
- **Energetic and bright** for social clips, launches, moments of hype
- **Considered and thoughtful** for long-form, deep-dive, expert content

The user picks the feel, then auditions two or three voices in that lane against an actual paragraph of their script. Auditioning against generic sample text is misleading — voices behave differently on real content.

## How to evaluate any AI audio tool quickly

The market has many tools and the major ones (ElevenLabs, Play.ht, Descript) are all good enough that the choice comes down to fit, not quality. Look for these five things:

1. **A voice library that actually has range.** If everything sounds like a corporate training video, walk away.
2. **Easy script input.** Paste-in or upload-in, with a working preview before generation.
3. **Tone, pacing, and emphasis controls.** Speed sliders are common; emotion controls and per-word emphasis are the differentiators.
4. **Reasonable preview-then-generate flow.** You shouldn't be paying for or waiting on an export to find out the voice was wrong.
5. **Standard export formats.** MP3 and WAV. If a tool exports to a proprietary format only, skip it.

## The three tools worth knowing

**ElevenLabs.** Industry standard for natural-sounding narration and the strongest voice cloning available. Multilingual. Slightly more learning curve than the simpler tools, but the audio quality justifies it for anything customer-facing.

**Play.ht.** Web-based, fast, friendly UI. Strong for users who want to get going in five minutes. Voice library is broad rather than deep — fewer "wow, that sounded human" moments than ElevenLabs, but very few "that was clearly AI" moments either.

**Descript.** Different beast — it's a full audio/video editing suite with AI narration baked in. Best fit if the user is going to be editing the surrounding video too, or wants script-driven editing (you edit the transcript, the audio updates). Cloning quality is good. Worth it if multiple workflows live in one place.

If the user is making short, simple content: Play.ht. If they're making customer-facing content where audio quality matters: ElevenLabs. If they're editing long video and want the audio to be part of the same project: Descript. None of those are wrong answers.

## On cloning your voice (when, and how to do it well)

Cloning is worth it when the user produces audio regularly enough that "this sounds like me" becomes a recognisable signal to their audience. For a one-off project, skip it. For a course launch, a podcast, a regular newsletter that goes out as audio, do it.

Five rules for getting a clone that doesn't sound off:

1. **Record 1 to 2 minutes of clean, calm speech.** A short script or blog excerpt. More isn't better up to a point.
2. **Quiet room, decent mic.** A USB mic helps but a phone in a quiet room is fine. Background noise wrecks clones more than poor mic quality does.
3. **Read naturally.** Don't perform. Don't try to be louder or more dynamic than you actually are. The AI is learning your real rhythm — give it your real rhythm.
4. **Read the kind of content you'll generate.** If you'll be using the clone for warm coaching content, record warm coaching content for the sample. If it's professional explainer, record that.
5. **Expect the clone to be 90% you, not 100%.** That last 10% is normal. After a few projects you'll learn which sentences your clone handles beautifully and which you'd be better off recording yourself or rephrasing.

If the user is cloning their voice for the first time, suggest they generate three test pieces immediately — a 30-second intro, a 30-second tip, and a 30-second close. Hearing themselves in three different contexts in the first hour cuts months off the learning curve.

## Match tone to message before doing anything else

Before any tool gets opened, the user should know:

- What feel they want the listener to take away
- Whether the voice is them (cloned) or someone else (preset)
- Roughly the speed and emphasis register

That's the brief. Three lines. Once those are written down, the next steps — script polish, voice selection inside the tool, generation — all get faster and more decisive.

The point of this step is to stop the user from disappearing into the tool and emerging two hours later with a confused-sounding 45-second clip. Decide first. Generate second.
