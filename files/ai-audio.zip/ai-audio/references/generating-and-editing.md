# Generating and Editing

## The right way into the tool

The temptation is to paste the script, pick the first voice that sounds nice, and click generate. The output will be passable. But two minutes of voice testing first changes the result from "passable" to "right".

The mistake is auditioning voices on the tool's sample text. Sample text is bland and decontextualised. A voice that sounds great reading "this is a test of the voice quality" can fall apart on real content with real punctuation and real pacing.

Audition voices on a real paragraph of the actual script. Same paragraph, two or three voices. The right answer becomes obvious within thirty seconds.

## What to listen for when comparing voices

Four things, in order of importance:

**Tone match.** Does the voice land in the same emotional register as the message? A friendly script delivered in a steady professional voice feels off. A confident script delivered in a warm soft voice undercuts itself.

**Clarity at normal speed.** Listen at the speed you'll publish at. Some voices are crisp at 1x but mush at 0.95x. Others are wonderful slow but rush at full speed.

**Pacing.** Does it feel rushed, plodding, or just right for the content? Instructional content rewards a slightly slower pace; social clips reward slightly brisker.

**Emotion.** Some voices have a flatter affect than others. Most projects don't need theatrics, but they do need warmth or seriousness or energy at appropriate moments. Listen for whether the voice has emotional range or whether it's a permanent monotone.

If two voices both pass these checks, go with the one that feels more "on brand" for the user's overall content. They'll be using it again.

## The generation flow itself

Every major tool follows roughly the same five-step flow:

1. **Paste or upload your script.** Paragraph breaks become pauses. Punctuation becomes pacing. Both matter.
2. **Choose your voice.** Either a preset from the library or your cloned voice if you've trained one.
3. **Adjust settings.** Speed, pitch, emotion, emphasis — varies by tool. Default settings are usually fine for the first pass.
4. **Generate and listen.** Listen to the whole thing, not just the first ten seconds.
5. **Export.** MP3 for audio-only use; WAV if it'll be edited further before publication.

If the first generation is wrong, the order to debug:

- Wrong voice → re-pick voice
- Right voice, wrong pacing → adjust speed
- Right pace, wrong feel → check emphasis or emotion settings
- Right feel, individual words wrong → fix pronunciation, regenerate that section only if the tool allows

## Settings that actually matter

Tools throw a lot of sliders at the user. Three are load-bearing; the rest are usually decoration.

**Speed.** Default is usually fine. Slow it slightly (0.95x) for instructional content; speed it slightly (1.05x) for social clips. Beyond that, you're distorting the voice.

**Stability or expressiveness.** A few tools (ElevenLabs in particular) let you adjust how much variability the voice has. Lower stability = more emotional range, more risk of weird readings. Higher stability = more consistent, sometimes flatter. Default is usually right; adjust only if specific problems show up.

**Emphasis or stress markers.** Some tools let the user mark words for emphasis (often with bold or specific tags). Worth using for the one or two words per paragraph that genuinely need it. Don't overuse — emphasised words lose their power if every sentence has one.

If a setting doesn't change anything audible, ignore it. Tool builders add more controls than most users need.

## Fine-tuning for a natural sound

After the first generation, the user listens through and notes what's wrong. Common issues and fixes:

**Unnatural pauses.** AI sometimes pauses oddly mid-sentence. Fix: adjust the punctuation in the script (remove an unintended comma, add a paragraph break elsewhere) and regenerate.

**Mispronounced words.** Use phonetic respelling in the script. "Lay-na" for "Lena". Regenerate.

**Rushed emphasis on wrong words.** This is harder. Sometimes a slight rephrase fixes it; sometimes the emphasis tag in the tool fixes it; sometimes you just pick a different voice that handles the line better.

**Inconsistent tone across the piece.** Usually means the script is asking too much of one voice — a sales line in the middle of a calm explainer, for example. Either smooth the script or split into two voices using mixed narration.

**That uncanny "almost human" feeling.** Often means the voice is overplaying. Try a different voice with lower expressiveness. Sometimes a less dramatic voice produces a more human result.

## Knowing when to stop iterating

The ceiling on AI audio is high but not infinite. After two or three rounds of refinement, the gains taper off. The user can keep generating versions for an hour and the third one is probably the one to ship.

The test: would the listener notice the difference between this version and a hypothetical perfect version? Usually no. They'll notice voice clarity, tone, and pacing — the big stuff. Sub-frame timing and micro-emphasis are inaudible to anyone except the person who made it.

Ship the version that's clear and on-tone. Move on.

## Export and file management

Two formats handle 95% of cases:

- **MP3** for audio that will be used as-is — podcasts, audio downloads, anything where compressed file size matters
- **WAV** for audio that will be further edited or mixed — videos with music, multi-track productions, anything that goes through a final mix

Save the source script alongside the audio file in the same folder. Two reasons: future regeneration if anything changes, and reference for similar projects later. Most users discover within a month that they want to reproduce the same voice and pacing on a new piece. Having the original script saves hours.

A simple folder convention that scales:

```
/audio
  /[project-name]
    script-final.md
    audio-master.wav
    audio-export.mp3
    settings-notes.md
```

Three files, one folder, and the user can come back to this project six months later without losing anything.
