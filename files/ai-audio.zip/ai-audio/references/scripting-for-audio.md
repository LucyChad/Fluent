# Scripting for Audio

## The core insight

A sentence that reads beautifully on the page can fall apart when spoken. The eye and the ear process language differently. The eye skims and fills in meaning; the ear handles one word at a time and has to keep up. Most stiff AI narration is not the AI's fault — it's the script's. The text was written for reading.

Once the user understands that, the rest of this step is mechanics.

## Write for the ear

Listening is linear. Whatever a reader can backtrack on, a listener cannot. That puts pressure on the script in three ways: shorter sentences, simpler words, clearer structure.

The rules that produce listenable scripts:

**One idea per sentence.** Multi-clause sentences with three ideas joined by commas read fine but listen badly. The listener loses the thread halfway through. Cut those into two or three sentences.

**Familiar words over formal ones.** "Use" over "utilise". "Help" over "facilitate". "Show" over "demonstrate". Anything the user would actually say out loud, in conversation, is the right register for audio.

**Contractions, always.** "You'll" lands. "You will" sounds like a court summons. AI handles contractions well. The character count drops, the pacing improves, and the result feels human.

**Paragraph breaks where you want pauses.** AI tools treat paragraph breaks as instructions to take a longer breath. Use this. Long, dense paragraphs become wallpaper. Short, broken-up paragraphs become rhythm.

**Limit numbers, dates, and acronyms.** AI mispronounces these more often than anything else. If a number is essential, write it out ("twelve thousand", not "12,000"). If an acronym is essential, sometimes spelling it phonetically helps ("E-S-G", not "ESG"). And often, the better answer is to rewrite the sentence so the number doesn't matter.

## Use AI to write the script faster

Most users are coming from existing content — a blog post, a transcript, a video script, a long-form piece they want to compress into 60 seconds of narration. AI is excellent at this. The trick is the prompt.

A working compression prompt:

> Compress this [blog post / article / transcript / page] into a 60–90 second narration script for a video voiceover.
>
> Tone: [user's tone — pull from the Voice Snapshot if they have one, or describe in two adjectives]
>
> Constraints:
> - Short sentences, max 18 words.
> - No numbers, dates, or acronyms unless essential.
> - Use contractions throughout.
> - One idea per sentence.
> - Paragraph break wherever I'd want a beat.
> - End on a single sentence that lands the takeaway.

That prompt produces a script that's 70% there. The user does a 5-minute polish pass and ships it.

If the AI's output is too formal or too rushed, the right move is one tweak at a time — adjust the tone cue, or tighten the constraint, or specify the ending. Don't rewrite the whole prompt every round.

## Punctuation as pacing instruction

Once the script is roughly right, the user can fine-tune pacing through punctuation. The tools read punctuation as breathing instructions. The rules:

- **Comma:** half-beat pause
- **Full stop:** one-beat pause
- **Paragraph break:** longer pause, like a slide change
- **Em dash:** dramatic mid-sentence pause — use sparingly, AI overuses these unprompted
- **Ellipsis:** trailing off. Use even more sparingly than em dashes. They sound hesitant.

If the script is too breathless, add full stops. If it's plodding, remove some. If a key sentence isn't landing, isolate it as its own paragraph.

## Phonetic fixes for stubborn pronunciations

Every AI mispronounces certain words. Names (especially non-English ones), unusual brand names, technical terms, and acronyms are the usual suspects. Three tactics:

**Phonetic respelling.** Write "Lay-na" instead of "Lena", "Mee-cha-ill" instead of "Mihail". The output sounds right, the listener never sees the spelling.

**Hyphens or spaces between letters.** "S-E-O" instead of "SEO" if you want the AI to read out the letters. "ESG" without spaces if you want it as a word.

**Rephrase around the problem.** Sometimes the easiest fix is just not to use the word. If "phenomenology" is wrecking three sentences in a row, rewrite around it.

## The read-aloud test

The single most useful QA step. After polishing the script, the user reads it out loud — properly, not in their head. Anything that trips their tongue gets fixed before generation. Anything that feels wrong rhythmically gets adjusted.

This catches more issues than any other check. Sentences that look balanced on the page but stumble when spoken; pauses in the wrong places; words that turn out to be hard to say. Two minutes of reading aloud saves twenty minutes of regenerating.

## Length expectations

Rough rule: one minute of audio is roughly 130–150 spoken words. Most users overestimate how much fits in a short clip.

- **30-second clip:** 65–75 words
- **60-second clip:** 130–150 words
- **90-second clip:** 200–225 words
- **3-minute explainer:** 400–450 words
- **5-minute training segment:** 650–750 words

If a script is over its budget, the right move is usually to cut a whole sentence rather than tighten existing ones. Tightening makes scripts dense; cutting makes them spacious. Audio rewards space.

## When the script is ready

Three signals that a script is ready to generate:

1. The user has read it aloud and nothing snags
2. Sentences are mostly short, mostly one idea each, mostly using contractions
3. Numbers, names, and acronyms have been handled (phonetic, rewritten, or accepted)

If those are all true, generate it. Most of the work is done. The next step is settings, not surgery.
