# Syncing with Visuals

## The point of this step

The audio is done. The user has a clean MP3 or WAV that sounds the way they wanted. Now it has to live alongside slides, video clips, or images, and the whole thing has to feel like a finished piece — not a slideshow with narration bolted on.

This is the step most users dread because they associate it with editing software, timelines, and frustration. The good news: you don't need professional editing software for any of it. Canva, Descript, and CapCut all do this work simply, and any of the three is fine for most projects.

The harder part is the principle: lay down the audio first, then build the visuals to match. That's the order. Get it wrong and you're constantly re-editing the audio to fit slides that were timed for nothing.

## The "audio first, visuals second" workflow

Three stages, in order:

**Stage 1 — Drop the audio onto the timeline.** Whichever tool the user is in, the very first thing on the empty project is the narration track. Play it through once at this stage to feel its length and natural pauses.

**Stage 2 — Place the visuals against the audio.** Slides, video clips, photos — drop each one in at the moment in the audio where the new idea begins. Most tools have markers or timestamps. Use them.

**Stage 3 — Adjust visual timing to fit the narration.** Trim slide durations, shorten clips, extend a hold on an image. The audio is fixed; the visuals flex to match it.

This is the opposite of how most users instinctively work. The instinct is to make the slides first, time them, then narrate over them. That produces narration that sounds rushed (because it has to fit the slide length) or padded (because it has to fill the slide length). Audio first solves both problems.

## Tool quick-takes

**Canva.** Very simple. Upload audio, drag video clips or images onto a track, trim, export. Excellent for slide-based content. Limited control over fine timing but more than enough for most projects.

**Descript.** Strongest if the audio came from Descript itself, because the script and audio are bound together. Edit the script, the audio updates. Visuals can be placed on a parallel track and trimmed. Good for longer content.

**CapCut.** Free, capable, more video-editing oriented. Strong for short-form social content and reels where the visuals are doing more work. A bit more learning curve than Canva.

For a coach or consultant making slides + voiceover videos, Canva is the right starting point unless they already use one of the others.

## Music: how to use it without ruining the voice

Background music is a force multiplier for narrated content when used correctly and a disaster when used badly. Two rules.

**The voice has to be louder than the music.** Always. Music sits in the background; voice sits in the foreground. If the user is listening on phone speakers and can't make out the words, the mix is wrong. Most tools default to roughly equal levels; manually drop the music by 12–18 dB until the voice clearly dominates.

**Music should support, not perform.** A single instrumental track that holds a steady mood works for almost any project. Music that has its own dramatic structure (a song that builds, a track with vocals, a dramatic crescendo) competes with the voice and pulls attention away from the message. Pick atmosphere, not narrative.

If the user can't decide whether to use music at all: skip it. Silence under a clear voice is fine. Bad music is worse than no music.

## Timing tweaks that elevate a finished piece

A few small adjustments can take a project from "fine" to "well produced":

**Add a half-second pause before transitions.** A beat between slides or clips lets the previous idea land before the next one starts. Most tools have a "fade" option that handles this automatically.

**Use silence as punctuation.** A two-second hold on a slide with no audio can be more powerful than filling every second. Don't be afraid of empty space — it directs attention to what matters.

**Don't fill every visual second with audio.** If the audio is 90 seconds and the video is 95 seconds, that's fine. The extra five seconds at the end can be a hold on a final slide or a fade to the next thing.

**Match visual transitions to natural audio breaks.** Don't change a slide mid-sentence. Wait for the full stop. Then change.

These details aren't artsy — they're the difference between content that feels considered and content that feels assembled.

## Preview and export

Before exporting, watch the whole thing through once. End-to-end. Without skipping. The temptation is to spot-check three places and call it done. Don't.

Things that only show up on a full play-through:

- A slide that's slightly too long, killing the pace
- A transition mid-sentence
- Music level that creeps too loud at one point
- A typo on a slide that the user only spots in motion
- An audio glitch right at a transition

Two minutes of full preview saves an hour of post-publication regret.

When everything's right, export to MP4 — the universal format for video. Settings:

- 1080p resolution for most uses
- 30fps is fine; 60fps only if there's actual motion that benefits
- Standard codecs (H.264 for video, AAC for audio)

Most tools default to these. If they don't, override them.

## Where the synced piece goes next

Three common destinations. Each has slightly different requirements.

**Social media** — square (1:1) or vertical (9:16) aspect ratio, captions burned in for sound-off viewing, max length 60–90 seconds for most platforms.

**Embedded on a website** — 16:9 widescreen, normal length, normal captions optional.

**Used in a course or training** — 16:9, normal length, often with chapter markers or timestamps in the player. Higher production value expected.

The user should know the destination before exporting. Cropping a finished video to a different aspect ratio always loses something — usually whatever the visual was framed around. Better to make the right size from the start.
