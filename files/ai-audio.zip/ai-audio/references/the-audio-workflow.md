# The Audio Workflow

## What this step is for

By the time a user has produced one finished narrated piece, they have all the components: voice, script, generation, sync. The workflow turns those components into a repeatable system, so the second piece takes a third of the time and sounds noticeably more consistent than it would have if every project started from scratch.

This is what stops AI audio from being a one-off experiment and turns it into a quiet superpower the user has across their whole business.

## The Audio Brand Kit

The single most useful artefact to build at this stage. A short reference document that captures the user's settled choices for voice, tone, pacing, and sound. Once it exists, every new project starts at minute five instead of minute zero.

A working Audio Brand Kit contains six sections.

**Voice profile.** Which voice they're using (preset name or "my cloned voice"), which tool, and any specific configuration. "ElevenLabs — Adam preset, stability 50%, clarity 75%" is enough.

**Tone notes.** Two or three adjectives describing the feel they want most often. "Warm, direct, occasionally dry." Specific enough to remember, vague enough to handle different projects.

**Pacing defaults.** Speed setting, typical adjustments. "Normal speed (1.0x). Slightly slower for tutorials (0.97x)."

**Reusable phrases.** The intros, sign-offs, and bumpers they'll use across projects. "Welcome to..." "Quick one for you today..." "Right, that's the lot — back tomorrow." Three or four of these saves rewriting the same lines every time.

**Sound elements.** Background music tracks they like, sound effects that signal section breaks, audio bumpers if they have a brand sound. License sources for each so they don't have to track them down later.

**Where files live.** The folder convention they're using. The cloud storage. The naming pattern. Boring but vital — most people lose more time hunting for old files than they think.

The Brand Kit asset in this skill pack is a structured worksheet that walks the user through filling each section in. Twenty minutes of work; it pays off forever.

## Reusable script templates

The complementary artefact. A small library of script shapes the user can pull from and adapt — saves the dread of staring at a blank page when a new project lands.

The shapes worth having:

- **30-second social clip** — hook, one idea, one CTA
- **60-second video voiceover** — context, payoff, action
- **3-minute explainer** — problem, framework, walkthrough, takeaway
- **Welcome / introduction** — for course modules, podcasts, lead magnets
- **Sign-off / outro** — closes consistently across content

The Audio Script Templates asset has working starters for each of these. The user adapts, doesn't author from scratch, and the time per script collapses.

## The Audio Workflow Checklist

A short production checklist the user runs on every project. The point is to make the high-quality moves automatic — pause for a music check, pause for an export check, pause to read the script aloud — rather than relying on remembering them.

Five stages, with checks in each:

**Brief stage**
- Project goal and audience clear
- Length target set (30s / 60s / 3min / longer)
- Tone identified

**Script stage**
- Written or compressed
- Read aloud once
- Numbers, names, acronyms handled

**Audio stage**
- Voice chosen and tested on real script
- Settings dialled in
- Generated, listened to end-to-end

**Sync stage**
- Audio dropped on timeline first
- Visuals placed against natural beats
- Music level checked
- Full preview watched

**Export stage**
- Right format and size for destination
- Captions added if going to social
- File saved with naming convention
- Source script saved alongside

Five stages, twenty checks, ten minutes added per project. In return: consistent quality and dramatically fewer "wait, I forgot to..." moments.

## Storing settings so the next project benefits

The habit that compounds the most: every time a project goes well, the user makes a 30-second note of what worked. Voice settings used. Pacing tweaks. Specific tone cues that produced the right feel. Music that worked under the voiceover.

Over a few months this turns into a personal playbook that reflects how *they* produce audio — not how the tool's documentation says to produce audio. By month three, most users are working from their own notes more than from any external guide.

The fastest way to build it: a single notes file in the same folder as the Brand Kit. After every project: one line, what worked, one line, what to fix. Two minutes. Compounds enormously.

## On using AI voices ethically

A short but important section. AI voice tools sit in a space where the technology is ahead of the social norms. Three habits keep the user comfortably on the right side of trust.

**Only clone voices you have explicit permission to clone.** Yours: fine. A team member's, with their consent: fine. A client's voice from a recording: only with consent in writing. Anyone else's: don't.

**Be transparent about AI use when it matters.** "This audio was generated using AI" in the description of public content is a small disclosure that pre-empts a lot of suspicion later. Not every piece needs it; courses, paid content, and high-stakes communications usually do.

**Store voice samples and clones securely.** A trained voice clone is sensitive material. Keep the source recordings in private storage, don't share them, and revoke them when you stop using the tool.

These aren't legal requirements (yet). They're trust requirements. The audio space is going to get more regulated and more scrutinised; being on the right side of these habits early means the user doesn't have to scramble later.

## What "fluent in audio" actually looks like

After two or three months of using this workflow, the user has:

- A Brand Kit they consult before starting any new project
- A small library of saved script templates and prompts
- A folder convention that means they can always find old projects
- Roughly halved the time per finished narrated piece compared to month one
- A consistent sound across their content that listeners recognise

That's the goal of the whole workshop. Not "knows how to use ElevenLabs" — that's the bottom rung. The real goal is being able to add narration to anything in their business — a video, a slide deck, a social clip, a course module — without it feeling like a project, just a thing they do.

That's voice on.
