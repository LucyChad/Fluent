# How To Build Know, Like, Trust In 30 Days

*Installation guide*

This skill works by giving your AI assistant deep knowledge about know-like-trust marketing for small businesses — the framework, the 30-day journey, the daily actions, the rhythms, and how to adapt everything for your specific business. Once it's set up, you can ask it for help on any day's action and it'll bring the whole methodology to bear without you having to remind it what it knows.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Know, Like, Trust" or "30-Day KLT"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/the-know-like-trust-foundation.md`
- `references/getting-known.md`
- `references/getting-liked.md`
- `references/getting-trusted.md`
- `references/running-the-30-days.md`
- `assets/30-day-action-journal.md`
- `assets/klt-baseline-audit.md`
- `assets/action-adaptation-guide.md`
- `assets/post-30-days-momentum.md`

**Step 3: Add your business context**

In the **Project instructions** field, paste and complete the following:

```
My business: [What you do, who you serve. Be specific — "B2B leadership coach for new managers in tech" beats "coach".]
Business shape: [B2B services / B2C products / local / online / personal brand / e-commerce / etc.]
My current audience size and engagement: [Rough numbers and quality — "2,000 LinkedIn followers, modest engagement"]
My biggest KLT gap right now: [Visibility / warmth / trust]
What day of the 30 I'm on (or planning to start): [Day 0 / Day 5 / etc.]
My KLT baseline audit score (if you've taken it): [Phase 1: __ / 30, Phase 2: __ / 30, Phase 3: __ / 30]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a marketing strategist who already knows your business.

A good first message: *"Walk me through day 1 — let's actually do it now."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A know-like-trust strategist who walks me through a 30-day journey of becoming someone my audience knows, likes, and trusts. Knows the full framework, the daily actions, and how to adapt them for my business."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all five files in `references/`, and all four in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical know-like-trust strategist. Use the uploaded knowledge files to guide every response. Always work from my actual business and current audience reality. Apply the three-phase framework (known days 1–10, liked days 11–20, trusted days 21–30) and the daily action discipline. Have opinions and share them.

My context:
- My business: [fill in]
- Business shape: [fill in]
- Audience size and engagement: [fill in]
- Biggest KLT gap: [fill in]
- What day I'm on: [fill in]
- Baseline audit score (if taken): [fill in]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Know, Like, Trust*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- My business: [fill in]
- Business shape: [fill in]
- Audience size and engagement: [fill in]
- Biggest KLT gap: [fill in]
- What day I'm on: [fill in]
- Baseline audit score (if taken): [fill in]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your business

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**Your specific business and audience.** Not just the industry — the specific shape and audience size. "B2B leadership coach for first-time managers in tech, 2,000 LinkedIn followers, low engagement" is far more useful than "coach".

**Your business shape.** B2B services, B2C products, local, online, personal brand, e-commerce, etc. The skill adapts the actions based on this.

**Where you are in the journey.** Day 0 is fine. Day 12 is fine. Have you taken the baseline audit? If yes, paste the scores. If not, the first conversation can be doing it.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Run the KLT baseline audit with me — let's score the business now."*
- *"Walk me through day 1 — what does updating my profiles actually mean for [business]?"*
- *"Adapt day 5 (video introduction) for me — I'm a [business shape] and I'm uncomfortable with video."*
- *"Help me write the day 16 challenge story — I don't know what to share."*
- *"I'm on day 17 and not getting engagement. Diagnose."*
- *"Run the 5-day review with me — here's what I did."*
- *"I've finished the 30 days. Help me plan month 2."*

---

*Know, Like, Trust is part of the Fluent skill library. More skills at fluent.md.*
