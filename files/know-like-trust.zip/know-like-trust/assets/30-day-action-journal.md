# 30-Day Action Journal

The full set of 30 actions, the 5-day reviews, and the end-of-30-days reflection — all in one working document. Print it, fill it in digitally, or paste into your daily planner.

The discipline: one action per day, every day. 30–60 minutes per action. Reviews on days 5, 10, 15, 20, 25. Final reflection on day 30.

---

## Phase 1: Getting Known (Days 1–10)

### Day 1 — Update social media profile

Make name, logo, and bio identical across every platform you use.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 2 — Share one helpful tip

A short blog post or social update with one specific tip your audience would find useful.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 3 — Three quick tips on social

A scannable, shareable list of three small tips. Single carousel, thread, or list post.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 4 — Attend a networking event

In-person or virtual. The point is real conversations with new people in your space.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 5 — Video introduction

60–90 seconds. Phone-recorded is fine. Who you are, what you do, who you do it for.

**What I did:** _______________

**What I noticed:** _______________

---

### Review: Days 1–5

**What activity did I like best?**

_______________

**What got the most engagement?**

_______________

**Which action generated the most messages?**

_______________

**What surprised me?**

_______________

**What I'll lean into for the next 5 days:**

_______________

---

### Day 6 — Smart comments on industry blogs

Two or three substantive comments on blogs or community pages your audience trusts.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 7 — Update the About page

Story, values, who you serve, clear next step.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 8 — Customer success story

A real story. Real customer (with permission). Specific outcome.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 9 — Live Q&A

Announce 24–48 hours ahead. 30 minutes live. Save the recording.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 10 — Free resource

A checklist, cheat sheet, or short guide. No strings.

**What I did:** _______________

**What I noticed:** _______________

---

### Review: Days 6–10

**Best activity:** _______________

**Most engagement:** _______________

**Most messages:** _______________

**Surprises:** _______________

**Lean-in for phase 2:** _______________

---

## Phase 2: Getting Liked (Days 11–20)

### Day 11 — Respond to recent reviews

Within 48 hours. Including negative ones. Acknowledge specifically.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 12 — Conduct a poll

Yes/no or multiple-choice on social. The comments matter more than the votes.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 13 — Behind-the-scenes / candid backstory video

Unpolished. The real texture of running your business.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 14 — Share user-generated content

Repost with credit and permission. The real stuff, not just the flattering stuff.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 15 — Personalised appreciation email

Pure thanks. No call to action. No upsell.

**What I did:** _______________

**What I noticed:** _______________

---

### Review: Days 11–15

**Best activity:** _______________

**Most engagement:** _______________

**Most messages:** _______________

**Surprises:** _______________

**Lean-in for next 5 days:** _______________

---

### Day 16 — Hardest challenge story

The real failure. Specific. With a specific lesson on the other side.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 17 — Motivational moment

A genuine inspirational thought, with your own commentary on why it lands.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 18 — Customer testimonial story

Story format, not pull quote. With photo or clip if possible.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 19 — Quick giveaway

Specifically valuable to your ideal customer. Easy entry mechanic.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 20 — Core values post

Articulate the values driving your business. Ask followers to comment.

**What I did:** _______________

**What I noticed:** _______________

---

### Review: Days 16–20

**Best activity:** _______________

**Most engagement:** _______________

**Most messages:** _______________

**Surprises:** _______________

**Lean-in for phase 3:** _______________

---

## Phase 3: Getting Trusted (Days 21–30)

### Day 21 — Update privacy policy

Current, plain-language, accessible from the footer of every page.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 22 — Secure payment infrastructure

SSL in place. Payment gateways using current secure protocols. Trust badges on checkout.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 23 — Failure-and-lesson story

Specific. Honest. With the lesson learned. Not a humble-brag failure.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 24 — Feature reviews on the homepage

Strongest specific reviews, prominently placed. Names where possible.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 25 — Highlight guarantees

Make every guarantee visible. If you don't have one, add one today.

**What I did:** _______________

**What I noticed:** _______________

---

### Review: Days 21–25

**Best activity:** _______________

**Most engagement:** _______________

**Most messages:** _______________

**Surprises:** _______________

**Lean-in for the final 5 days:** _______________

---

### Day 26 — Data security blog post

Plain-language explanation of what you do to keep customer data safe.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 27 — Update FAQ

Add the questions that have actually come up. Remove the ones nobody asks.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 28 — Customer service philosophy post

How you handle customer service. What customers can expect. Specific.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 29 — Free trial or sample

A way for prospects to try before they buy. Even for service businesses, find a version.

**What I did:** _______________

**What I noticed:** _______________

---

### Day 30 — Prominent contact information

Verify every page has clear contact info — email, phone (if applicable), address (if applicable).

**What I did:** _______________

**What I noticed:** _______________

---

## End-of-30-Days Reflection

The single highest-leverage step in the whole 30 days. 30–60 minutes of honest assessment.

### 1. Three ways my audience now knows me better

1. _______________
2. _______________
3. _______________

---

### 2. Three ways my audience now likes me more

1. _______________
2. _______________
3. _______________

---

### 3. Three ways my audience now trusts me more

1. _______________
2. _______________
3. _______________

---

### 4. Which days produced the most engagement?

_______________

---

### 5. Which days felt most like me?

_______________

---

### 6. What's the audience saying that I didn't expect?

_______________

---

### 7. What action will I keep doing weekly forever?

Pick one or two:

_______________

---

### 8. What action will I never do again?

_______________

---

### 9. What's my next 30-day shape?

_______________

---

## Done

Twenty minutes of honest reflection here is what turns the 30 days into a system. Without it, the next 30 days will look identical to the last. With it, the next 30 days will look refined.
