# Action Adaptation Guide

The standard 30 actions assume a particular shape of small business — public-facing, some social media presence, small-to-medium audience. Most users need to adapt at least a handful of actions to fit their actual situation.

This guide shows how to adapt the standard actions for the most common business shapes. Use it as a reference rather than a rule book — your business is the final arbiter of what fits.

---

## B2B services

The biggest adaptation: most B2B audiences engage with thought leadership and credibility signals more than with personality content — but personality still matters, just at a slightly different register.

| Day | Standard | B2B adaptation |
|---|---|---|
| 3 | Three quick tips on social | Three sharp observations or contrarian takes on LinkedIn |
| 4 | Networking event | LinkedIn Lives, industry roundtables, professional associations |
| 9 | Live Q&A | A roundtable conversation with a peer, or LinkedIn Live with comments |
| 13 | Behind-the-scenes video | A LinkedIn post about the actual texture of how you work, with photos |
| 17 | Motivational quote | A pointed industry observation framed as a quote-graphic, with your context |
| 19 | Giveaway | An exclusive consultation or workshop offer to a small specific cohort |
| 22 | Payment security signals | Professional certifications, insurance, accreditations visible |
| 25 | Guarantees | Scope-and-pricing commitments; clear satisfaction terms |
| 29 | Free trial / sample | Discovery call, scoping conversation, sample deliverable |

The personality work in days 11–20 is non-negotiable for B2B. Buyers are still buying a person, even if the buying process has more committee dynamics around it.

---

## Local-only businesses (physical premises or service area)

The biggest adaptation: in-person presence is a significant multiplier; digital is a complement, not a replacement.

| Day | Standard | Local adaptation |
|---|---|---|
| 4 | Networking event | Local Chamber of Commerce, neighbourhood business association, local meet-ups |
| 6 | Industry blog comments | Local Facebook groups, Nextdoor, neighbourhood newsletters |
| 7 | About page | About page plus visible Google Business Profile description |
| 9 | Live Q&A | In-person open evening / sip-and-shop / community workshop |
| 10 | Free resource | A specific local resource — a "best places in [neighbourhood]" guide, a printed map, a community-focused cheat sheet |
| 14 | UGC | Customer photos taken inside or outside the premises, with permission |
| 19 | Giveaway | Local-only prizes, with in-person pickup if relevant |
| 24 | Reviews on homepage | Reviews on Google Business and on prominent in-store signage |
| 30 | Contact info on every page | Address and hours prominent everywhere; map embed on key pages |

Day 22 (payment security) becomes less prominent if the business doesn't take payment online; redirect that day's effort to physical signage of trust signals at the till.

---

## Solo personal brands

The biggest adaptation: everything is more weighted toward the founder personally. The audience is buying *you*.

| Day | Standard | Personal-brand adaptation |
|---|---|---|
| 1 | Profile updates | Profile updates plus a single sentence "what I do" that's in your actual voice, not consultant-speak |
| 5 | Video introduction | This is the most important day of the 30 — the human face is the entire product |
| 8 | Customer success story | Story formatted as "this is how I work with someone like you" rather than testimonial |
| 13 | Behind-the-scenes | High weight — your audience wants to see the texture of your day |
| 16 | Hardest challenge | High weight — the personal challenge is the brand |
| 17 | Motivational moment | Your real perspective, your real reason. No stock quotes |
| 23 | Failure-and-lesson | High weight — solo brands are built on credibility-via-vulnerability |
| 28 | Customer service philosophy | "How I work with clients" — your specific approach, not a generic policy |

The trust phase in days 21–30 may need adaptation if you don't have a website with checkout, FAQ, etc. Replace with the equivalent for your platform — a clear "what to expect from working with me" page, a tightly-worded scope and pricing structure, a transparent process.

---

## Established business with team / multiple staff

The biggest adaptation: don't centre everything on the founder; make the texture about the whole business.

| Day | Standard | Team adaptation |
|---|---|---|
| 5 | Video introduction | Owner introduction plus team member spotlights over time |
| 7 | About page | About page covers the team, the values, and the founding story |
| 13 | Behind-the-scenes | The team at work, not just the owner |
| 14 | UGC | Customer interactions with multiple team members |
| 18 | Testimonial story | Stories that mention specific team members by name |
| 28 | Customer service philosophy | Team-wide approach, not just owner's |

The personality phase still applies but is distributed across the team. Audiences engage more deeply when they recognise multiple people from the business, not just the founder.

---

## High-end services / premium positioning

The biggest adaptation: avoid moves that read as cheap or mass-market.

| Day | Standard | Premium adaptation |
|---|---|---|
| 10 | Free resource | A specific high-quality resource, not a basic checklist; design and editorial standards matter |
| 19 | Giveaway | An exclusive experience for a specific qualified prospect, not a public contest |
| 25 | Highlight guarantees | A clear scope-and-investment commitment; explicit terms; no "money-back" language that reads as discount-driven |
| 29 | Free trial / sample | A high-touch discovery process, not a self-serve trial |

The personality and trust phases work largely as standard, but the *register* should match the brand. Premium businesses can be warm — they shouldn't be casual or downmarket in tone.

---

## Information / digital products

The biggest adaptation: the trust phase carries enormous weight; buyers are wary of digital products and need extensive trust signals.

| Day | Standard | Digital-product adaptation |
|---|---|---|
| 22 | Payment security | Critical — clear payment methods, secure checkout, refund process visible |
| 24 | Reviews on homepage | Critical — extensive testimonials with names, photos, and (if possible) results |
| 25 | Guarantees | Critical — clear money-back guarantee with specific terms |
| 26 | Data security | Critical — what happens to customer data; account security; deletion policies |
| 29 | Free trial / sample | Critical — a sample chapter, free tier, or limited free version |

Phases 1 and 2 work largely as standard, with extra weight on demonstrating expertise (Days 2, 3, 8) and showing the human behind the product (Days 5, 13, 16).

---

## Product / e-commerce

The biggest adaptation: visual content is heavier; the trust phase is critical for conversion.

| Day | Standard | E-commerce adaptation |
|---|---|---|
| 3 | Three quick tips | Three product-use tips, ideally with photos or short videos |
| 5 | Video introduction | Founder video plus product story video |
| 8 | Customer success story | A story focused on the customer using the product, with photos |
| 10 | Free resource | A buyer's guide for your product category, branded as helpful rather than promotional |
| 14 | UGC | High weight — customer photos and reviews of the product in use |
| 22 | Payment security | Critical — the cart and checkout flow needs full trust treatment |
| 24 | Reviews on homepage | Critical — product reviews prominent on category and product pages, not just homepage |

The personality phase in days 11–20 should still happen; e-commerce that has personality outperforms e-commerce that's pure product photography.

---

## How to use this guide

**On day 0:** Read the section that fits your business shape. Mark the standard actions you'll need to swap. Write the swap into your action journal *before* day 1.

**On day 4 / 9 / 14 / 19 / 24 / 29:** When the standard action genuinely doesn't fit, adapt rather than skip. Use the adaptation rather than inventing your own — the adaptation preserves the principle of the action, which is what matters.

**On day 31:** Note in the reflection which adaptations worked and which didn't. The next cycle is even more bespoke.
