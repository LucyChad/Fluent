# KLT Baseline Audit

A 15-minute scoring exercise to know where your business is on day 0 — before the 30-day journey starts. Without a baseline, you have no way to know whether the 30 days actually moved anything.

Run this on day 0. Run it again on day 31. The comparison is the most useful piece of evidence about whether KLT works for your specific business.

---

## How to score

For each item, score 0–3:

- **0** — Not in place at all
- **1** — Partially in place but inconsistent or out of date
- **2** — In place and current, but could be sharper
- **3** — In place, current, and genuinely sharp

Total possible per phase: 30 points. Total possible overall: 90 points.

Most small businesses score in the 30–50 range on day 0. That's normal.

---

## Phase 1: Known (10 questions, 0–30 points)

| # | Question | Score (0–3) |
|---|---|---|
| 1 | My name, logo, and bio are consistent across every public profile | __ |
| 2 | I post substantive expertise content (not just promotion) at least weekly | __ |
| 3 | I have a current About page that tells my story and values | __ |
| 4 | I attend networking events or industry meetups regularly | __ |
| 5 | There's a clear video of me on my website or social channels | __ |
| 6 | I'm visibly present in the spaces my audience already trusts | __ |
| 7 | I have at least one free resource people can download | __ |
| 8 | I have customer success stories visible on my site or social | __ |
| 9 | I host or attend live events (in-person or virtual) at least quarterly | __ |
| 10 | A new visitor could understand what I do and who I do it for in under 30 seconds | __ |

**Phase 1 total: ___ / 30**

---

## Phase 2: Liked (10 questions, 0–30 points)

| # | Question | Score (0–3) |
|---|---|---|
| 1 | I respond to reviews — including negative ones — within 48 hours | __ |
| 2 | My audience sees me engage with them (replies, comments, DMs) | __ |
| 3 | There's behind-the-scenes / candid content visible somewhere | __ |
| 4 | I share or repost user-generated content from real customers | __ |
| 5 | I send appreciation messages to my audience without an upsell attached | __ |
| 6 | I've shared a real challenge or failure story (not a humble-brag) | __ |
| 7 | My audience has a clear sense of my voice / personality | __ |
| 8 | My core values are visible somewhere on my site or content | __ |
| 9 | Customer testimonials are written as stories, not just pull quotes | __ |
| 10 | I run polls, contests, or interactive content occasionally | __ |

**Phase 2 total: ___ / 30**

---

## Phase 3: Trusted (10 questions, 0–30 points)

| # | Question | Score (0–3) |
|---|---|---|
| 1 | My privacy policy is current, plain-language, and accessible | __ |
| 2 | SSL is active on my whole site (browser padlock visible) | __ |
| 3 | Trust badges or security signals are visible at checkout / sign-up | __ |
| 4 | I've publicly shared a failure with a clear lesson learned | __ |
| 5 | Customer reviews / testimonials are prominent on my homepage | __ |
| 6 | I offer a clear guarantee (money-back, satisfaction, free trial, etc.) | __ |
| 7 | I have a written customer service philosophy or commitment | __ |
| 8 | My FAQ reflects real, recent customer questions | __ |
| 9 | Prospects can try before they buy (sample, trial, discovery call) | __ |
| 10 | My contact information is visible on every page of my site | __ |

**Phase 3 total: ___ / 30**

---

## Total score: ___ / 90

---

## How to read the score

**Below 30.** You're starting from scratch. The 30-day journey will produce a transformative shift. Run the full programme, every action, no shortcuts.

**30–50.** Typical for small businesses that have been running a year or two. Some foundations are in place but with significant gaps. The 30 days will sharpen everything; pay particular attention to the areas where individual scores are 0 or 1.

**50–70.** You're already running solid KLT, probably without thinking of it that way. The 30 days will fill the specific gaps and create coherence between the elements. Focus more on the lower-scoring questions; consider the journey a refinement rather than a build-from-scratch.

**70+.** Strong KLT foundation. The 30 days will mostly be polish and consistency rather than new construction. Consider running an alternate version where you spend each day deepening the practice that scored highest, rather than adding new ones.

---

## Phase imbalance

If one phase scores significantly lower than the others, that's the diagnosis.

**Known low, Liked / Trusted higher.** You're an under-the-radar business doing solid work but not getting credit. The visibility moves in days 1–10 will produce the biggest shift.

**Liked low, Known / Trusted higher.** You're professional but feel anonymous. The personality moves in days 11–20 will produce the biggest shift — and these are usually the hardest, so plan extra time for them.

**Trusted low, Known / Liked higher.** You're warm and visible but haven't built the credibility infrastructure. The trust moves in days 21–30 will close the gap; many of them are technical (privacy, SSL, FAQ) rather than creative, which makes them quick to deliver.

---

## What to do with the audit

**On day 0:** Take the audit. Save the score. Note which specific questions scored lowest — they're your priorities for the 30 days.

**On day 31:** Take the same audit again. Compare scores. The total should be higher; the phase distribution should be more balanced; the lowest-scoring questions should have moved most.

**Quarterly afterwards:** Take the audit again. Track the trajectory over a year. Most businesses see steady incremental improvement; the ones that don't usually need to repeat the 30-day journey rather than continuing to compound the existing baseline.
