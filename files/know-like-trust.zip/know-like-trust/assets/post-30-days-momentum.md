# Post-30-Days Momentum

You've made it through the 30 days. The audience knows you better, likes you more, and trusts you further than they did a month ago. Don't waste the momentum.

This worksheet sets up what happens at day 31 and beyond. The goal: turn a one-off 30-day push into a permanent KLT habit that compounds for years.

---

## What you've established

Before planning what's next, capture what's true now. Refer to your end-of-30-days reflection in the Action Journal.

**The two or three actions that produced the most engagement and warmth:**

1. _______________
2. _______________
3. _______________

**The audience signals that have shifted (more replies / more DMs / higher engagement / new conversations):**

_______________

**The actions that didn't fit and you'd never do again:**

_______________

These three things are the input to everything below.

---

## Pattern 1: The two-action weekly rhythm

The simplest sustainable approach. Pick the two highest-performing actions from the 30 days. Commit to running them weekly, forever. Total time commitment: about an hour per week.

**Action 1 (visibility — from days 1–10):**

_______________

**Cadence:** weekly, on _______________ (specific day)

**Time required:** _______________ minutes

---

**Action 2 (warmth or trust — from days 11–30):**

_______________

**Cadence:** weekly, on _______________ (specific day)

**Time required:** _______________ minutes

---

**Owner:** _______________

**How I'll track that I'm actually doing it:** _______________

A simple repeating calendar entry is usually enough. Without one, the rhythm decays inside three weeks.

---

## Pattern 2: The monthly mini-cycle

Once a quarter, run a focused 30-day cycle on a specific theme. Not the full framework — a deeper version of one phase.

**Quarter 1 (post-launch):** Visibility focus. Lean hardest on the days 1–10 actions, but at higher quality and with bigger ambition. Goal: meaningful audience growth.

**Quarter 2:** Warmth focus. Days 11–20 actions, deepened. Goal: a more engaged existing audience.

**Quarter 3:** Trust focus. Days 21–30 actions, deepened. Goal: stronger conversion infrastructure and visible credibility.

**Quarter 4:** Integrate. Run the full 30 days again — but with all the learning from quarters 1–3 baked in.

| Quarter | Focus | Specific actions to lean into |
|---|---|---|
| 1 | _______________ | _______________ |
| 2 | _______________ | _______________ |
| 3 | _______________ | _______________ |
| 4 | _______________ | _______________ |

---

## Pattern 3: The annual recalibration

Once a year, return to the foundation. Repeat the KLT baseline audit. Re-read your day-30 reflection from a year ago. Look at how the audience has shifted.

Set a calendar reminder for **___________ (12 months from today)** to:

- [ ] Re-take the KLT baseline audit
- [ ] Compare to day-31 audit and to last year's
- [ ] Review what's changed in the audience
- [ ] Plan the next year's KLT shape

The annual recalibration takes 2–3 hours. It's the cheapest insurance the business has against drift.

---

## What to drop and what to keep

The end-of-30-days reflection identified one or two actions that didn't fit. Drop them permanently.

**Dropped from the rotation:**

1. _______________
2. _______________

**Replaced with:**

1. _______________
2. _______________

---

## What about content the audience asked for?

The 30 days probably surfaced unexpected requests — questions that came up multiple times, topics the audience wanted more of, formats that produced disproportionate engagement.

Capture them here so they don't get forgotten:

**Topics the audience explicitly asked about:**

1. _______________
2. _______________
3. _______________

**Formats that worked unexpectedly well:**

1. _______________
2. _______________

These become content for the next quarter — the user knows their audience wants these, so producing them is high-confidence rather than guess.

---

## A note on the 30-day journey itself

The framework isn't supposed to be done once. The most successful users run it twice or three times in the first year — getting incrementally sharper on each iteration — and then settle into the weekly + quarterly rhythm above.

If a future cycle feels like more of the same, change the framing:

- **Theme it:** "The 30 days of helping new customers feel welcomed", or "30 days of building credibility in this specific subcategory"
- **Audience-segment it:** Run the 30 days specifically for one customer segment, with adaptations
- **Co-run it:** Run the 30 days alongside another business owner — accountability buddy, shared reflection at the 5-day reviews

The actions evolve. The principle (known → liked → trusted → buying) doesn't.

---

## The single most important thing

Don't let day 30 be the end. The biggest waste of a successful 30-day journey is treating it as a one-off project. The momentum is real and decays fast.

Decide today — within 48 hours of finishing the journey — what the next thing is. Even if "the next thing" is just the two-action weekly rhythm. Even if it's just a calendar reminder for a quarterly cycle.

Decide. Schedule. Move.

Know, Like, Trust isn't 30 days. It's how the business operates from now on.
