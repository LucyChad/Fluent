# Getting Known (Days 1–10)

## What this phase is for

The first ten days of the 30-day journey are about visibility — making sure the people you want to reach are aware that you exist, what you do, and where to find you. It's the boring infrastructural phase. None of the actions are creatively risky. Most of them feel obvious. They're load-bearing anyway.

The reason most businesses skip past this phase too fast is that the work feels unimpressive. Updating a profile bio doesn't feel like marketing. Writing a Day 7 About page doesn't feel like content. But the entire framework breaks if the audience can't find or identify the business — so the boring work comes first.

## The principle: legible before lovable

Before anyone can decide whether they like you, they need to be able to recognise you. The legibility work in days 1–10 is what makes that recognition possible. Same name, same logo, same description across every platform. A clear and current About page. A consistent voice in tips and short content. A free resource that lets them experience your value before they buy.

Legible does not mean polished. The actions in this phase are mostly about consistency and presence, not perfection. A business owner who's "still working on the brand" before posting anything will never start. The actions are quick wins.

## The ten actions and what each one is really doing

### Day 1 — Update social media profile

The point isn't the cosmetic update. The point is alignment: name, logo, and bio identical across every platform you're on. A potential customer who finds you on LinkedIn and clicks through to your Instagram should see immediately that they've found the same person. Inconsistency reads as amateurism, even if everything individually looks fine.

What "good" looks like: same handle (or as close as possible), same profile picture, same bio (with platform-appropriate length), same primary website link.

### Day 2 — Share your expertise (one helpful tip)

A short blog post or social update with one specific tip that solves a small problem your audience has. Not a manifesto. Not a thread. One tip. The point is to demonstrate that you know your subject, in a format that's quick to consume.

What "good" looks like: 100–300 words, specific enough to be useful, clearly applicable to your audience's actual situation. Save the broader frameworks for later.

### Day 3 — Three quick tips on social

Same energy as Day 2 but three small ones rather than one bigger one. The format works because it's scannable, shareable, and signals breadth ("they don't just know one thing"). Posted as a single piece of content (carousel, tweet thread, list post).

### Day 4 — Attend a networking event

In-person or virtual. The point isn't the event itself; the point is creating "I met you" memories that turn anonymous people into people you've actually had a conversation with. One real conversation at one event beats fifty social comments.

If networking events feel impossible, lower the bar: any context where you actually introduce yourself to two new people in your space counts.

### Day 5 — Video introduction

A short (60–90 seconds) video introducing yourself and your business. Posted on social, embedded on your website. The point is the human face. People are far more likely to remember someone they've seen and heard than someone they've only read.

What "good" looks like: phone-recorded is fine, in good light, in a clean-enough background, saying who you are, what you do, and who you do it for. Don't overproduce. Authentic-feeling beats slick.

### Day 6 — Smart comments on industry blogs

Leave 2–3 thoughtful comments on blogs or community pages where your audience hangs out. Not "great post!". Substantive — a different angle, a useful addition, a sharp question. The point is presence in the spaces your audience already trusts; smart commenting borrows that trust.

### Day 7 — Update the About page

Your website's About page is one of the highest-converting surfaces you have, and most small businesses have About pages that are either generic ("we're passionate about excellence") or absent. Days 1–6 brought people to your space; this is what greets them when they land.

What "good" looks like: the story of how the business started, the values driving the work, who the business serves, and a clear next step. Personal, specific, current.

### Day 8 — Customer success story

Share a real story of how your product or service helped a real customer. Not a testimonial pull quote. The narrative — what the customer was trying to do, how they used your work, what changed. Posted with permission, named where possible, photographed if appropriate.

The point is to provide social proof that's visceral rather than abstract. "Sarah K, dentist in Manchester, doubled her practice's recall rate using this approach" lands differently from "5-star service".

### Day 9 — Live Q&A

Host a livestream Q&A on your social platforms. People can ask questions in real time. The point is the live element — it signals confidence, it creates urgency, and it gives people who've been quietly watching a way to surface as live participants.

What "good" looks like: announce 24–48 hours ahead, run for 30 minutes, take any reasonable question, save the recording for people who couldn't make it.

### Day 10 — Free resource

A piece of content you give away with no strings: a checklist, a cheat sheet, a short guide. The point is letting people experience your value before they buy. The free resource is the bridge between "they know you exist" and "they think you might be useful".

What "good" looks like: actually useful (not a content tease that demands the upsell to be complete), 1–4 pages or one page of useful structure, branded, easy to consume on a phone.

## How to adapt these for your business

The standard actions assume a small business with a public-facing audience and at least some social media presence. Adapt freely for fit.

- **B2B services:** Days 4 (networking), 6 (commenting), 7 (About page), 9 (Q&A) carry more weight. Days 3 (quick tips) and 10 (free resource) translate into thought leadership.
- **Local-only businesses:** Day 4 should genuinely be a local in-person event. Day 6 might be local Facebook groups rather than industry blogs. Day 9 might be an in-person open evening rather than a livestream.
- **Solo creator / personal brand:** All ten actions apply at full force. The video on Day 5 is non-negotiable.
- **Established business with existing audience:** Many of the actions are still worth doing as refreshers. Don't skip Day 7 (About page) — it's almost always out of date.

## What success looks like at day 10

By the end of phase 1, the user should have:

- A consistent identity across every public surface they're on
- A clear About page that does work for them
- Three or four pieces of fresh tip-format content out in the world
- A video introduction that puts a face on the business
- A free resource that people can actually pick up and use
- A handful of new conversations from networking and live Q&A
- A baseline of recognition that the next ten days can build on

What it doesn't look like: a flood of new sales. KLT compounds; phase 1 alone doesn't move revenue. The signal of success at day 10 is that more people know the business exists, full stop.

## The day-5 review

Halfway through this phase, the journal asks: what activity did I like best, what got the most engagement, and what generated the most messages? The point is to spot which moves are working in *this specific business* — not in theory. The actions in days 6–10 should lean into whatever's working, even if it means doubling up on a format the standard plan doesn't.
