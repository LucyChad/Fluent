# Getting Liked (Days 11–20)

## What this phase is for

Days 11–20 are about giving the audience an emotional read on the person and business behind the offer. Days 1–10 made the business legible; this phase makes it human.

The work in this phase is harder than the work in phase 1. The first phase was infrastructural — clear, finite, mostly mechanical. This phase asks the user to show personality, share things they don't usually share, and engage with their audience in a way that requires them to actually *be* present, not just *look* present. Most businesses never run this phase properly. The ones that do, pull ahead of their competitors quickly.

## The principle: warmth, not performance

The actions in this phase are not about being lovable on demand. They're about giving people enough texture — enough of the real person — that they form a feeling about the business, one way or the other. A business that's clearly run by someone with strong opinions, particular ways of working, and a recognisable voice is easier to like than a business that's polished into anonymity.

The warmth has to be real. Performed warmth is recognisable from a long way off. The behind-the-scenes that's clearly staged. The "vulnerability" that's clearly a marketing move. The "human moment" that's been polished within an inch of its life. Audiences see through it. The actions below are designed to invite real warmth, not to engineer it.

## The ten actions and what each one is really doing

### Day 11 — Respond to recent reviews

Especially negative ones. Reply within 48 hours. Acknowledge the experience. If at fault, apologise specifically. If not at fault, express genuine regret about the experience. Take the conversation offline if it needs continuing.

The point isn't fixing the individual review — it's the public signal. Future readers see the response. A business that handles a negative review with grace earns more trust than a business with no negative reviews and no responses.

### Day 12 — Conduct a poll

A simple yes/no or multiple-choice poll on social media asking your audience for their opinion on a relevant industry topic. Use the platform's native poll feature.

The point isn't the data. The point is engagement — every vote is a small action of involvement, and the comments under the poll are the real signal. People who vote are warmer than people who scroll past.

### Day 13 — Behind-the-scenes / candid backstory video

A short video where you share the unpolished part of running your business. Not a glossy "year in review". The actual texture — what your morning looks like, where you work, what's on your desk, what frustrates you, what you're working on right now. 60–120 seconds.

The point is the antidote to highlight-reel content. Most business content shows the polished surface. The candid version makes the audience feel they're seeing the real thing.

### Day 14 — Share user-generated content

Repost photos, share videos, retweet content from your followers that relate to your business. With credit and permission. Useful UGC, not just self-flattering UGC.

The point is two-fold: the original poster feels seen, which deepens their loyalty; everyone else sees real customers using and talking about the business in their own words, which is more persuasive than anything the business could say itself.

### Day 15 — Personalised appreciation email

Send a thank-you email to your customer list. Not a sales email. Not a sales-email-with-thanks-attached. Just thanks, with something specific you appreciate about them as a group, and no call to action.

The point is the rarity. Most lists hear from businesses only when there's something to sell. A pure appreciation email cuts through because nobody else does it. The unsubscribe rate will be lower than your average email; the engagement will be higher.

### Day 16 — Hardest challenge story

A blog post or long-form social post about the hardest moment in the business and how you got through it. Real specifics. The actual mistakes you made. The bits that almost broke you. The lesson on the other side.

The point is the trust-by-vulnerability move. Audiences trust people who've been honest about failure. Audiences are quietly suspicious of people whose brand is uninterrupted success.

A few rules: don't tell a story that's still raw and unprocessed (that's therapy, not content); don't tell a story without a specific lesson learned (that's just sad); don't tell a story that humble-brags (that's worse than no story).

### Day 17 — Motivational moment

Share a genuine motivational or inspirational quote, story, or thought relevant to your industry. With a comment that's *yours* — what the quote means to you, why it lands, when you've used it. Not just a stock quote-graphic with no commentary.

The point is the values signal. Audiences gravitate to businesses whose values they share. Sharing what motivates you is one of the cleanest ways to surface that.

### Day 18 — Customer testimonial story

A specific testimonial from a customer, framed as a story rather than a pull quote. What were they struggling with? What did they try with you? What changed? Posted on social with their permission, ideally with a photo or video clip.

The point is depth. A pull-quote testimonial is "Lucy is great!" — which is forgettable. A story testimonial is "I came to Lucy worried that I was undercharging by 30%. Three weeks later we'd raised my rates twice. I lost two clients and gained four." That sticks.

### Day 19 — Quick giveaway

A small giveaway on social media, with a clear and easy entry mechanic — like, comment, share, or tag a friend. The prize should be valuable enough to motivate but not so valuable that it attracts prize-hunters who'll never become customers. A free month of your service, a relevant product, a short consultation — these all work.

The point is reach amplification. Done well, a giveaway can put the business in front of hundreds of people who weren't following yet. Done badly, it attracts noise. The selection rule: the prize should be specifically valuable to your ideal customer, not universally valuable.

### Day 20 — Core values post

A post sharing the core values guiding your business — the principles that drive how you make decisions. Asking followers to comment with theirs.

The point is two-fold: it forces you to articulate your values clearly (most business owners haven't), and it creates a moment for your audience to react and self-identify with your values, deepening their connection to the business.

## How to adapt these for your business

The standard actions assume a small business with public-facing social media presence. Adapt for fit.

- **B2B services:** Days 11 (responding to reviews), 16 (challenge story), 18 (testimonial story), and 20 (values) carry more weight. The vulnerability moves can be pitched at a slightly more professional register but should still feel real.
- **High-end services / premium positioning:** Day 19 (giveaway) might not fit at all — replace with an exclusive experience for an existing customer rather than a public contest.
- **Established business with team:** Days 13 (behind-the-scenes), 14 (UGC), and 18 (testimonial) can feature team members and longer relationships. Don't centre everything on the founder; make the texture about the whole business.
- **Solo personal brand:** All actions apply, with extra weight on Days 13, 16, 17, and 20 — the audience is buying *you*, so the personality work is the core of the offer.

## What success looks like at day 20

By the end of phase 2, the user should see:

- More replies, DMs, and comments — engagement that goes beyond likes
- Audience members starting to recognise the business's specific tone or perspective
- A measurably higher email open rate, especially on the appreciation email
- A handful of warm conversations with customers who've felt seen by the UGC, the appreciation, or the testimonial work
- A clearer sense — for the user — of what their actual voice and values sound like in public

What it doesn't look like: viral hits, dramatic audience growth, or a flood of sales. KLT is slow-burn. The signal of success is that the existing audience is warmer than it was on day 10, not that the audience itself has tripled.

## The day-15 review

Halfway through this phase, the journal asks: what activity did I like best, what got the most engagement, and what generated the most messages? Pay attention to which moves felt genuinely yours versus which felt forced. The actions in days 16–20 should lean into the formats that fit, and the trust-building work in days 21–30 should build on whichever phase-2 moves landed best.

Most users find the personality phase harder than the visibility phase. That's normal. By day 20 the harder edges have softened, and the warmth that emerges supports everything in phase 3.
