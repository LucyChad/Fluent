# Getting Trusted (Days 21–30)

## What this phase is for

By day 21, the audience knows the business and has a positive feeling about it. The final ten days are about backing that feeling up with the credibility, transparency, and reliability signals that turn warm prospects into willing buyers.

Trust is not the same as warmth. Warmth is "I like this person". Trust is "I'd give this person money, my data, or my recommendation, and I'd expect them to handle it well". The work in this phase is the bridge from one to the other.

## The principle: trust is granular

A common mistake is treating trust as a single signal. It isn't. Trust accumulates from a dozen small specific signals — visible policies, prompt responses, transparent failures, easy contact, public guarantees. The actions in this phase address each of these specifically.

A business that has every one of these signals in place is dramatically more trustworthy than one that has none, even if the underlying offering is identical. Buyers don't articulate this in those terms — they just feel it. The work is making sure all the small signals are present.

## The ten actions and what each one is really doing

### Day 21 — Update privacy policy

Visit your privacy policy. Most small businesses have one that was generated three years ago and hasn't been touched since. Make sure it's current, plainly written, and accessible (linked from the footer of every page).

The point isn't the legal compliance — though that matters. The point is the signal. A current, readable privacy policy says "this business takes your data seriously". A 2019-vintage policy with broken links says the opposite.

### Day 22 — Secure payment infrastructure

Confirm SSL is in place across the site (the padlock in the browser bar). Confirm payment gateways are using up-to-date secure protocols. Display trust badges where they belong — on cart pages, checkout pages, anywhere money changes hands.

The point is the absence of friction at the moment of buying. A buyer hovering over the "complete purchase" button is looking for reasons to abandon. Visible security signals reduce abandonment by closing one specific objection.

### Day 23 — Failure-and-lesson story

Share a specific time something went wrong in your business — a launch that flopped, a project that went sideways, a hire that didn't work. With the lesson learned. Not a humble-brag failure ("I worked too hard!"). A real one.

The point is asymmetric. Audiences expect business content to be polished success. A genuine, specific, well-told failure story is rare and memorable, and it produces trust because it demonstrates honesty in a place where there's no incentive to be honest.

A few rules: only share failures you've genuinely processed (not raw, recent ones); always include the specific lesson; don't blame other people; don't end on "and now everything's wonderful" — the resolution can be ongoing.

### Day 24 — Feature reviews on the homepage

Take your strongest specific reviews or testimonials and place them prominently on the homepage. Above the fold if possible. With names and ideally photos.

The point is location, not novelty. Most businesses have testimonials buried on a separate "testimonials" page that nobody visits. Moving them onto the homepage means they do their work at the moment buyers are deciding.

### Day 25 — Highlight guarantees

Make any guarantees you offer visible. Money-back, satisfaction, free returns, free trial — whatever you've got. On product pages. In the footer. In emails. If you don't have any guarantees, this is the day to add one.

The point is risk reversal. The buyer is weighing the risk of being wrong. A clear guarantee shifts that risk from them to you, which makes saying yes easier.

### Day 26 — Data security blog post

A blog post explaining what you do to keep customer data safe. Not technical jargon. Plain language explanations of the steps you take.

The point is two-fold: educated buyers ask about this and want a place to read about it; less-educated buyers don't ask but feel reassured by its existence. The post is preemptive trust-building.

A small business can write this in 30 minutes. The exercise of writing it usually surfaces gaps that should be addressed anyway.

### Day 27 — Update FAQ

Visit your FAQ page. Update it. Add the questions that have actually come up recently in customer conversations. Remove the questions nobody asks. Make the answers genuinely helpful, not corporate-PR-speak.

The point is the signal of attentiveness. A FAQ that reflects real, recent customer questions says "we listen". A FAQ that's been static for two years says the opposite.

### Day 28 — Customer service philosophy post

A post where you explain how you handle customer service — what your customers can expect, how fast you respond, what you do when something goes wrong. Specific, with examples.

The point is to set the standard publicly. Once it's posted, you have to live up to it. The act of writing the standard makes the standard real, and the post itself becomes a trust signal for prospective customers.

### Day 29 — Free trial or sample

Offer a way for prospects to try before they buy. Software: a free trial. Service: a discovery call or sample session. Product: a sample, a demo, a time-limited refund. Even for service businesses, some form of pre-commitment experience is possible.

The point is the lowest-stakes path into the relationship. Many buyers won't commit to a paid offer without testing first. A clear free-trial path turns hesitation into action.

### Day 30 — Prominent contact information

Verify that every page of your site has clear contact information — at minimum, an email address; ideally a phone number; physical address if you have premises. Linked from the footer, the contact page, and (for service businesses) any high-stakes pages.

The point is accessibility. Buyers trust businesses they can reach. Hidden or hard-to-find contact information signals that the business doesn't want to talk to its customers, which is the worst possible last impression on day 30.

## How to adapt these for your business

The standard actions assume a website-driven small business with some commerce element. Adapt for fit.

- **B2B services:** Days 21 (privacy), 26 (data security), and 28 (customer service philosophy) carry extra weight. Days 22 (payment security) might be less prominent; Day 25 (guarantees) might be replaced with a project-success guarantee or scope-clarity commitment.
- **Local-only businesses:** Day 30 is the most load-bearing — physical address visible, phone number prominent, opening hours current. Day 22 might be less relevant if you don't take payment online.
- **Service / consulting:** Day 29 (free trial) becomes a discovery call or scoping conversation. Day 25 (guarantees) becomes a clear scope-and-pricing commitment.
- **Information / digital products:** Days 22, 25, and 29 are all critical — secure checkout, money-back guarantee, and sample chapter or free-tier are buyer expectations.
- **Product / e-commerce:** All ten actions apply at full strength. Days 22, 24, 25 are particularly important for conversion rate.

## What success looks like at day 30

By the end of phase 3, the user should see:

- Lower abandonment on key conversion paths (cart, signup, contact)
- Faster sales cycles (less back-and-forth before commitment)
- Higher engagement on trust-related content (the failure story, the customer service post)
- A measurable rise in the metrics that matter for their business — sales, leads, bookings — even if the rise is modest
- A foundation that the next 30 days can build on rather than rebuild

What it doesn't look like: an explosion in sales overnight. The trust signals make every future sale easier; they don't suddenly produce sales that weren't going to happen.

## The day-25 review

Halfway through this phase, the journal asks: what activity did I like best, what got the most engagement, and what generated the most messages? Pay particular attention to whether trust-building actions are producing different kinds of engagement than the earlier phases — typically deeper messages, more specific questions, higher-intent inquiries.

By day 30, the full picture across all three phases is visible. The end-of-30-days reflection (the next reference) is where the real learning compounds.
