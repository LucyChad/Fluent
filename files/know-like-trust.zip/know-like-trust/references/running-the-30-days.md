# Running the 30 Days

## Why this part is the actual product

Most businesses fail at "know, like, trust" not because the framework is wrong but because they don't run it. They start enthusiastically, drop off around day 7, recover briefly around day 12, and disappear by day 18. The 30-day journey is built to survive that pattern — but only if the user runs it with the right discipline.

This reference is about the discipline. The daily rhythm, the 5-day reviews, the metrics that genuinely tell you whether the work is working, and the end-of-30-days reflection that turns one cycle into a system.

## The daily rhythm

One action per day. Specific. Achievable in under 60 minutes. Done.

The biggest mistake is treating each daily action as a project to perfect. Day 1 is an hour of profile updates, not a week of brand strategy. Day 5 is a 90-second video shot on a phone, not a professional production. The point of the daily structure is consistency — 30 small acts of presence, accumulated into a measurable shift.

A working daily rhythm:

- **Morning (5 minutes):** read the day's action, decide how it'll fit your day
- **Block of work (30–60 minutes):** do the action
- **End of day (5 minutes):** note what you did, where it lives, anything you noticed about how it landed

That's it. An hour or so per day, every day, for 30 days. Less than people think they'll need; more than most actually deliver.

## When you can't do the day's action

Two acceptable responses:

**Adapt the action.** If Day 4 is "attend a networking event" and there's no relevant event in your area this week, swap to a virtual meet-up, a Twitter Space, an industry Slack. The principle of the action (real-time conversations with new people in your space) is what counts. The specific format is flexible.

**Move the action.** If today is genuinely impossible — sick child, urgent deadline, whatever — move the action to tomorrow and double up. Don't skip it, don't drop the streak, don't pretend it didn't happen.

What's not acceptable: skipping an action because you're not in the mood for it. The actions you don't want to do are usually the ones you most need to do (Day 5's video, Day 16's challenge story, Day 23's failure-and-lesson all tend to feel like "tomorrow's job" indefinitely). The discipline is doing them on schedule.

## The 5-day review checkpoints

Built into the journal at days 5, 10, 15, 20, and 25. Five questions each:

1. What activity did I like best?
2. What activity got the most engagement?
3. Which action generated the most messages or replies?
4. What surprised me?
5. What's the action I'll lean into more, based on the last five days?

The reviews take 10–15 minutes each. Their purpose is twofold:

**Pattern detection.** What's working in *this* business is rarely the same as what works in theory. A single action that lands brilliantly tells you something about your audience that the wider plan doesn't capture. The reviews surface those signals.

**Course correction.** The next five days should lean into whatever's working. If Day 5's video produced more replies than Days 1–4 combined, the next phase should plan more video. If Day 13's behind-the-scenes content was a flop, the equivalent later actions can be adapted.

Skip the reviews and you do the 30 days blind. The differences between people who finish and people who quietly drop off after week 2 usually trace back to whether the reviews happened.

## The metrics that genuinely matter

Most KLT advice focuses on vanity metrics — followers, likes, impressions. These move slowly and tell you almost nothing useful. The metrics that matter for the 30 days are the ones that signal warmth and depth.

**Engagement rate, not engagement count.** Likes and comments per post relative to follower count or reach. If a small audience is engaging hard, that's KLT working. If a larger audience is engaging softly, that's not.

**Replies, comments, and DMs.** The conversational signals. A post that produces 10 likes and 3 replies is doing more KLT work than a post that produces 100 likes and no replies.

**Profile views and click-throughs.** When you post good content, profile views spike — people are checking out who's behind the post. Profile views are an early signal of curiosity, which is an early signal of moving from "saw a post" to "interested in the business".

**Email open rate (if you're using email).** Particularly on the Day 15 appreciation email — the open rate signals whether your list still cares.

**Inbound conversations.** People reaching out to you, not the other way round. DMs asking questions, replies to emails, contact-form submissions. This is the high-value metric. Even one or two extra inbound conversations per week signals the framework is working.

**One thing not to track:** sales. KLT prepares the ground for sales, but it doesn't deliver them in the 30-day window. Tracking sales during the 30 days produces false signals — a bad sales week feels like the framework is failing when actually the framework is doing exactly what it should and the sales team is the unrelated next stage.

## Capturing the data

Keep a single working file — a spreadsheet, a Notion page, a notes file — with three columns:

| Day | Action | What I noticed |
|---|---|---|
| 1 | Updated profiles across LinkedIn, Instagram, X | Realised my LinkedIn bio was three years out of date |
| 2 | Posted a tip about pricing on LinkedIn | More replies than usual; one DM asking for advice |

Three minutes per day to fill in. By day 30 you have a complete record of what worked and what didn't, in your specific business, with your specific audience.

## The end-of-30-days reflection

The single highest-leverage step in the whole 30 days. 30–60 minutes of honest assessment at the end.

Six questions:

1. **Which days produced the most engagement?** Pattern: which formats or topics consistently outperformed?
2. **Which days felt most like me?** The actions that felt natural — not the ones that felt forced.
3. **What's the audience saying that I didn't expect?** New questions, new angles, new requests in the inbound conversations.
4. **What action will I keep doing weekly forever?** Pick one or two from the 30 — the ones that produced disproportionate results — and commit to a weekly cadence beyond the 30 days.
5. **What action will I never do again?** The one that didn't fit your business, your audience, or your style. Drop it.
6. **What's the next 30-day shape?** A second cycle isn't a copy of the first — it builds on what was learned.

Twenty minutes filling in those six questions, on paper or in a document, is what turns the 30 days into a system. Skip the reflection and the next 30 days will look identical to the last — which is fine, but not transformative. Run the reflection and the next 30 days will look refined, with the high-performing actions intensified and the wasted actions dropped.

## Day 31 and beyond

The most common failure mode is treating Day 30 as the finish line. It isn't. It's the end of the discovery phase.

Three patterns that work for ongoing KLT:

**The two-action weekly rhythm.** Pick the two highest-performing actions from your 30 and commit to running them weekly forever. One visibility action, one warmth or trust action. Total time commitment: about an hour per week.

**The monthly mini-cycle.** Once a quarter, run another 30-day cycle — but on a focused theme rather than the full framework. A month of pure visibility (acquisition focus). A month of pure warmth (existing audience deepening). A month of pure trust (conversion infrastructure).

**The annual recalibration.** Once a year, return to the foundation. Re-audit the business's KLT baseline. Re-read the 30-day journal entries from a year ago. Look at how the audience has shifted. Plan the next year's KLT shape.

The framework isn't supposed to be done once. It's supposed to become part of how the business operates. The 30 days are the on-ramp to a permanent system.
