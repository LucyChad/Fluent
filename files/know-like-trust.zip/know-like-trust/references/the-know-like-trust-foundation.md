# The Know-Like-Trust Foundation

## Why this framework, and not another

Know, Like, Trust is one of those marketing concepts that's been said so often it's lost most of its weight. Everyone's heard it. Few people have actually run a system around it. The reason it survives is that, underneath the cliché, it describes a real sequence in how strangers become customers.

People don't buy from people they don't trust. They don't trust people they don't like. They don't like people they don't know. The sequence is non-negotiable. Trying to skip a stage — selling to people who haven't warmed to you, or pushing for warmth before they've heard of you — is the most common reason small business audience-building fails.

The framework's job is to make the sequence operational. Not a vibe. Not a set of values. A specific 30-day action plan that runs through all three stages in the right order, builds the foundations that support each next stage, and produces an audience at the end that's measurably more engaged than the audience at the start.

## Why the order matters

Each stage builds on the previous one.

**Known → Liked.** A stranger can't decide whether they like you because they have nothing to react to. The visibility work in days 1–10 isn't an end in itself — it's the substrate that the personality work in days 11–20 lands on. Without "known", the "liked" content reaches an empty room.

**Liked → Trusted.** A person who's heard your name and seen your tips might know you, but they don't have an emotional read on you yet. They don't know if you're warm or cold, generous or guarded, the kind of person they'd want to deal with. The personality work in days 11–20 builds the warmth that makes trust signals in days 21–30 land. Without "liked", the trust signals feel transactional and corporate.

**Trusted → Customer.** Trust is the final unlock. Once a person knows you exist, has warmed to you, and has seen the credibility signals that prove the warmth was earned, they'll buy when the right offer appears. The 30 days don't make sales directly — they prepare the ground that the sales conversation lands on.

## The compounding effect

Each phase, done well, makes the next phase easier and faster.

A person who's been seeing your visibility content for two weeks doesn't need a hard push when you start showing personality — they already feel like they know you. A person who's warmed to you for two weeks doesn't need elaborate trust theatre when you talk about your guarantees — they're already inclined to believe you. The 30 days work because each phase reduces the friction of the next, not because each phase is independently impressive.

This is why running phase 1 alone (which most businesses do — endless visibility, no personality, no trust) plateaus. The audience knows the business exists. They have nothing to feel about it. They don't buy.

## The common failure modes

**Selling before known.** A business launches a product and sends offers to a list that's barely heard of them. Conversion rate is brutal. Almost everyone unsubscribes. The diagnosis: the audience didn't know who was selling to them. The fix is upstream of the offer.

**Personality without visibility.** A business pours their heart into "behind-the-scenes" content for an audience of three. The content is good. Nobody sees it. The fix is visibility — the personality work needs an audience to land on.

**Trust theatre without warmth.** A business plasters their site with badges, certificates, money-back guarantees, and testimonials. The visitor doesn't trust any of it because they have no warm feeling about the business yet. Trust signals reinforce existing warmth. They don't manufacture it.

**Skipping straight to "trust" because it sounds professional.** Often happens with B2B businesses. They'll do credibility-signalling all day — case studies, certifications, awards — but never let any personality through. The result is a business that looks reputable and feels like a wall. Buyers go with the warmer competitor.

**One-shot KLT.** A business does the 30 days once, then stops. The framework needs to become a habit, not an event. The actions should evolve and continue past day 30; not stop on day 31.

## How the framework adapts to different business shapes

The principle (know → like → trust → buy) is universal. The actions adapt.

**B2C vs B2B.** B2C audiences typically engage with social media, behind-the-scenes content, and personality-driven moments. B2B audiences engage with thought leadership, case studies, and credibility signals — but they still need warmth, just at a slightly different register. Don't skip the "like" phase for B2B; just translate it into appropriate B2B moves (a personal LinkedIn post about the lesson learned from a failed project lands better than a glossy testimonial).

**Service vs product.** Service businesses need to be liked more — buyers are choosing a person, not a thing. Product businesses can lean more on the trust phase — buyers are choosing whether the product works. Both still need all three stages.

**Local vs online.** Local businesses can use in-person presence as a "known" multiplier — networking, community events, sponsorships. Online businesses lean harder on digital visibility moves. The mix changes; the sequence doesn't.

**Old vs new audience.** A business that already has an engaged audience can compress the framework — the audience is already partially "known" to. A business starting from scratch needs to do all 30 days fully. The framework still applies; the time spent in each phase shifts.

## What success looks like

A business that's done the 30 days properly should see, by day 30:

- **More engagement on content** — replies, comments, DMs, shares
- **Higher profile views and click-throughs** to the website
- **More inbound conversations** — DMs asking questions, replies to emails
- **Stronger metrics on existing offers** — when a sale is mentioned, response is warmer than it would have been
- **A small but identifiable group of "warm" audience members** — people who reply, who recommend, who comment on multiple things

What success doesn't necessarily look like by day 30:

- A spike in sales (KLT prepares the ground; sales come from the offers that follow)
- Massive audience growth (the framework deepens the existing audience as much as it grows it)
- Going viral (KLT is slow-burn, not breakout)

The end-of-30-days work is largely about reading these signals correctly. Engagement and warmth before sales is the right shape.

## Where this skill takes the user

The next four references walk through the three phases (with their specific daily actions) plus the rhythm of running the 30 days. The assets in this skill pack are the working artefacts — the action journal itself, the baseline audit, the adaptation guide, the post-30-days momentum plan.

The user shouldn't try to read everything before starting. The right shape is: read this foundation reference, run the baseline audit, start day 1, and let the rest of the references and assets come into play as each phase begins.

Know, Like, Trust is something the user *does*. Not something they study.
