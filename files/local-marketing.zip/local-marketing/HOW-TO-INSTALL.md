# How To Win Your Local Market

*Installation guide*

This skill works by giving your AI assistant deep, specialist knowledge about local marketing for small businesses — customer avatars, UVPs, local SEO, Google Business profile, partnerships, community embedding, social proof, reviews, flash promos, loyalty programmes, and how to pull it all into a working strategy. Once it's set up, you can ask it for help on any local marketing decision and it'll bring the whole framework to bear without you having to remind it what it knows.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Local Marketing" or "Local Marketing"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/know-your-local-market.md`
- `references/get-found-online-locally.md`
- `references/build-the-offline-network.md`
- `references/convert-and-keep-customers.md`
- `references/the-local-strategy-blueprint.md`
- `assets/local-customer-avatar.md`
- `assets/competitor-questionnaire.md`
- `assets/uvp-builder.md`
- `assets/flash-sale-planner.md`
- `assets/local-strategy-planner.md`

**Step 3: Add your business context**

In the **Project instructions** field, paste and complete the following:

```
My business: [What you do, who you serve. Be specific — "family-friendly Italian restaurant in Oakville, mostly weekend families" beats "restaurant".]
My local area: [The geographic scope of "local" for your business — neighbourhood, town, drive radius]
My current marketing: [What's already running — social, Google Business, email, partnerships, etc.]
My main local marketing challenge right now: [The thing you're stuck on or want to fix]
My ideal customer in one sentence: [Specific. Use the Customer Avatar worksheet to build this if you haven't.]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a marketing strategist who already knows your business and your local market.

A good first message: *"Walk me through the Local Strategy Planner — let's pick three initiatives for the next quarter."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A local marketing strategist for small businesses who serve a specific local area. Knows the full local marketing toolkit — customer avatars, UVPs, Google Business, partnerships, community embedding, reviews, loyalty, and quarterly strategy."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all five files in `references/`, and all five in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical local marketing strategist. Use the uploaded knowledge files to guide every response. Always work from my actual business and local market, not in the abstract. Apply the 10-point framework. Have opinions and share them.

My business context:
- What I do: [fill in]
- Local area: [fill in]
- Current marketing activity: [fill in]
- Main challenge: [fill in]
- Ideal customer (one sentence): [fill in]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Local Marketing*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- What I do: [fill in]
- Local area: [fill in]
- Current marketing activity: [fill in]
- Main challenge: [fill in]
- Ideal customer (one sentence): [fill in]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your business

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**Your specific business and local market.** Not just your industry — the specific kind of business and the specific kind of local market. "Family-friendly independent restaurant in Oakville (mostly weekend families)" is far more useful than "restaurant".

**Your current marketing activity.** What's already running, even imperfectly. The skill needs to know whether your Google Business Profile is set up, whether you're doing social, whether you're already running a loyalty programme. Otherwise it'll suggest things you've already done.

**Your ideal customer in one sentence.** If you've built the Customer Avatar from the worksheet, paste it. If not, the first conversation can be building it. Either is fine.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Walk me through building my Local Customer Avatar."*
- *"Help me write a UVP for my [business]. Here's what I've got."*
- *"What should I be doing on my Google Business profile that I'm not?"*
- *"I want to set up a partnership with [neighbouring business]. How do I approach them?"*
- *"Help me plan a flash sale for [date]. The goal is [outcome]."*
- *"How do I respond to this negative review without making it worse?"*
- *"Pull my marketing into one strategy I can actually run for the next quarter."*

---

*Local Marketing is part of the Fluent skill library. More skills at fluent.md.*
