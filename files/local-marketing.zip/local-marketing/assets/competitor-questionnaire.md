# Local Competitor Questionnaire

A structured way to capture useful intel on your top three local competitors. The point isn't to copy them — it's to position around them. Knowing what they do well, badly, and not at all is what lets you carve a position they can't credibly claim.

Fill one of these in for each of your top three competitors. Aim for an hour total — twenty minutes per competitor.

---

## How to identify your top three competitors

Not industry-wide. Not the biggest national chain. The three businesses your ideal customer would most likely consider before choosing you.

Three quick tests:

1. If a customer Googled "[your kind of business] near me", who are the top three results?
2. If a customer asked a friend "where should I go for [your kind of thing]", who would the friend mention?
3. Of all the businesses in your local area that serve your kind of customer, which three are pulling business that could plausibly be yours?

The answers usually overlap. The competitors that show up in two or three of those tests are the real competition.

---

## The questionnaire (one per competitor)

Fill this in for **Competitor 1**, then duplicate the structure for Competitor 2 and Competitor 3.

### Identity

**Business name:** _______________

**Location relative to you:** _______________

**How long they've been operating:** _______________

**Roughly how big (solo / small team / large staff):** _______________

---

### Their offer

**What they sell, in plain terms:**

_______________________________________________

**Their price point relative to yours:** Cheaper / similar / premium

**Their visible target customer:**

_______________________________________________

**Their UVP, if they have one (or your best guess at how they'd describe themselves):**

_______________________________________________

---

### Their physical and online presence

**Storefront / premises (if visible):**

- [ ] Well-presented
- [ ] Tired or dated
- [ ] Distinctive in some way — note: _______________

**Website:**

- [ ] Strong (clear UVP, photos, easy to navigate)
- [ ] Adequate
- [ ] Weak or out of date
- [ ] Don't have one

**Google Business Profile:**

- Number of reviews: _______________
- Average rating: _______________
- Photos: many / few / none
- Posts: regular / occasional / never

**Social media:**

- Most active platform: _______________
- Posting frequency: _______________
- Engagement (rough sense): high / medium / low

---

### What they're known for locally

The thing customers actually mention. Word-of-mouth reputation, good or bad.

**The thing locals consistently say about them (positive):**

_______________________________________________

**The thing locals consistently say about them (negative or neutral):**

_______________________________________________

---

### Visible gaps

Where is this competitor weak? What are they not doing? What customer needs are they leaving on the table?

Three to five gaps:

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________

---

### What I can learn from them

Honest answer. Where are they ahead of you? What are they doing that's working that you should match or borrow?

_______________________________________________

_______________________________________________

---

### Where I could win against them

The flip side. Where can your business credibly claim ground that this competitor can't claim?

_______________________________________________

_______________________________________________

---

## After all three are filled in

Read the three questionnaires together. Three patterns usually emerge:

**Common gaps.** Things none of your competitors are doing well. These are the highest-value openings for you.

**Common strengths.** Things they all do well. These are the things you have to at least match — they're the table stakes for your local market.

**Distinctive points.** Things only one competitor does well. These tell you what each of them owns specifically, and where direct comparison would be unfavourable.

Your UVP should plant a flag in the common gap. Your basic competence has to match the common strengths. Your messaging should avoid head-on collision with each competitor's distinctive point.

---

## What this isn't

This isn't an exercise in tearing your competitors down. Most of them are running real businesses, mostly doing reasonable work. The point is to understand the landscape clearly enough to position yourself where you can win, not to convince yourself they're inadequate.

Done well, you should come away from this exercise with respect for what each competitor does plus a clearer view of what you specifically should do. Both at once.
