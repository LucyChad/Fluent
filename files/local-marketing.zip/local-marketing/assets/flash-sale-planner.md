# Flash Sale Planner

A structured plan for one flash sale, from decision to follow-up. The whole thing fits in a week — three days of planning and promotion, the sale itself, then the after-the-fact follow-up that compounds the impact.

Use this once a quarter at most. Flash sales work because they're rare. Run them every fortnight and you've trained your customers to wait.

---

## The brief: decide before you plan

Before you write a single promotional post, answer these three questions clearly.

### 1. What's the goal of this flash sale?

Pick one. Mixing goals dilutes the offer.

- [ ] **Boost visibility.** Get the business in front of new people. The sale is the hook for awareness.
- [ ] **Attract new customers.** Convert prospects who've been on the fence. Discount is the nudge.
- [ ] **Sell surplus stock.** Move inventory that's tying up cash or shelf space.
- [ ] **Increase sales at quiet times.** Drive activity in a typically slow period.
- [ ] **Generate revenue.** Pull forward future demand to hit a number.

Different goals call for different offer structures. A new-customer sale needs to lower the entry barrier; a stock-clearance sale needs aggressive pricing; a visibility sale needs to be talkable.

**Goal:**

_______________________________________________

---

### 2. What's the offer?

Specific. Quantifiable. With clear terms.

**The offer:**

_______________________________________________

**Who can use it:** _______________ (existing customers / new customers / both)

**Minimum spend or other conditions:** _______________

**Exclusions:** _______________

---

### 3. When does it run, and for how long?

A flash sale needs a real, short window. Vague urgency gets ignored.

**Start date and time:** _______________

**End date and time:** _______________

**Total duration:** _______________

The sweet spot is usually 24 to 72 hours. Less than 24 risks people not seeing it; more than 72 dilutes the urgency.

---

## The promotion plan: three to four days

A flash sale lives or dies on the build-up. Here's a working sequence.

### Day –3 (or –4): The tease

The first hint that something's coming. Don't reveal the offer yet — create curiosity.

**Channels for the tease:**

- [ ] Social media post: cryptic image or short video, "Something's coming this Friday..."
- [ ] Email subject line: "I've got news for you on Friday"
- [ ] Story / Reels: short countdown post

**Notes for this day:**

_______________________________________________

---

### Day –2: The reveal

Tell people what the offer is. This is the main promotional push.

**Channels:**

- [ ] Email to full list with offer details
- [ ] Long-form social post explaining the sale
- [ ] Story / Reels announcement
- [ ] Update Google Business Profile with the offer post
- [ ] Print signage in physical premises (if applicable)
- [ ] WhatsApp / SMS to VIP customers

**Notes for this day:**

_______________________________________________

---

### Day –1: The reminder

People who saw the reveal and meant to act but didn't. Reminder + countdown.

**Channels:**

- [ ] Reminder email
- [ ] Story / Reels countdown
- [ ] Social media post emphasising "tomorrow only" or similar
- [ ] Last chance to partners / cross-promotion friends to amplify

**Notes for this day:**

_______________________________________________

---

### Day 0: The sale runs

Most of the work is done. On the day:

- [ ] Morning post: "It's live."
- [ ] Mid-day check-in: highlight take-up, social proof if possible ("Already X have done it")
- [ ] Late-day final call: "Closes at [time]"
- [ ] Stories / Reels throughout
- [ ] Live engagement — respond to comments and questions quickly

**Notes for the day:**

_______________________________________________

---

### Day +1: The follow-up

Often skipped. Always valuable.

- [ ] Thank-you email to people who bought
- [ ] Social post sharing results ("Thanks to the X of you who...")
- [ ] Photos / behind-the-scenes content from the sale
- [ ] Plan next steps for new customers acquired (welcome sequence, follow-up offer)

**Notes for follow-up:**

_______________________________________________

---

## Multi-channel promotional checklist

Tick what you'll use for this specific flash sale. Don't try to use everything every time — match the channels to the goal and the audience.

### Digital

- [ ] Email to mailing list
- [ ] SMS / WhatsApp to subscribers
- [ ] Social media organic posts (Facebook, Instagram, LinkedIn, TikTok)
- [ ] Stories / Reels (short-form video)
- [ ] Google Business Profile post
- [ ] Website banner or pop-up
- [ ] Paid ads (geo-targeted, urgency creative)

### Physical

- [ ] Window decals / posters
- [ ] Sidewalk chalkboard / sandwich board
- [ ] Counter signage / printed cards next to till
- [ ] Flyers in local relevant places (cafés, gyms, community boards)
- [ ] Door-to-door delivery in immediate catchment

### Local press / community

- [ ] Local newspaper listing
- [ ] Community newsletter
- [ ] Local radio shout-out (especially community stations)
- [ ] Community Facebook group post (if rules allow)
- [ ] Cross-promotion partners share with their lists

---

## Track the result

After the sale closes, capture the basics:

- **Total sales / revenue from the offer:** _______________
- **Number of new customers acquired:** _______________
- **Number of existing customers re-activated:** _______________
- **Channel that drove the most response (rough sense):** _______________
- **What worked that I'd repeat next time:** _______________
- **What I'd skip or change next time:** _______________

A 20-minute review the day after the sale captures most of the learning. Skip it and the next flash sale starts from scratch.

---

## Common mistakes to avoid

**Running the offer too long.** Anything over 72 hours stops feeling urgent. Vague deadlines kill flash sales.

**Promoting only on the day.** People need 2–4 days of awareness build-up. A same-day announcement will under-perform.

**Discounting too deep.** Fifty per cent off everything trains customers to wait for sales. Be strategic about depth and frequency.

**Ignoring follow-up.** New customers acquired during a flash sale are the gold. Without a follow-up sequence they buy once and disappear.

**Making the offer too complicated.** "20% off if you spend over £40 between 2pm and 6pm on Tuesday" is too much friction. Simpler offers convert better.
