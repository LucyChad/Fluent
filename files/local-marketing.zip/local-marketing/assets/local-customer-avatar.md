# Local Customer Avatar

A structured exercise to build one specific, real-feeling customer avatar for the local business. Twenty minutes of focused thinking; produces an artefact you can test every later marketing decision against.

The mistake most people make is staying at the demographic level. "Women aged 35–55 with disposable income" describes everyone and is therefore useful for nobody. Push for specificity. One particular person you could pick out in a café.

---

## Before you start

Open your existing customer data — even a quick mental walk-through of your last twenty paying customers. Pick the one who felt like the *most* ideal: bought the right things, paid the right price, came back, didn't haggle, told their friends. That person is the model for the avatar.

If you don't have data yet, picture the customer you'd most love to fill the diary with. Same exercise, slightly more imaginative.

---

## 1. Name and basic identity

Make up a first name and last initial. Choose a name that sounds local to your area — it grounds the rest of the avatar in your actual market, not in a generic stock photo.

**Name:** _______________

**Age (specific number):** _______________

**Lives in (specific neighbourhood, not just the town):** _______________

**Occupation:** _______________

---

## 2. Bio — life shape

Two or three sentences on the texture of their life. Family situation, what their week looks like, what they care about beyond your product or service. The point is to put real flesh on this person so you can imagine them clearly.

_______________________________________________

_______________________________________________

_______________________________________________

---

## 3. Motivation

What are they actively trying to do or solve right now? The live concern, not the lifetime concern. This week or this month.

For a restaurant customer it might be: "Trying to find a family-friendly local Saturday-night option that the kids will eat and the parents will enjoy." For a divorce solicitor's client: "Trying to get through a complicated split without ruining the kids' relationship with the other parent and without paying for endless legal time." Specific.

_______________________________________________

_______________________________________________

---

## 4. Pain points

What's frustrating them about their current options? What gap in the market does your business fill for them?

Three or four specific pain points, in their own kind of language:

1. _______________
2. _______________
3. _______________
4. _______________

---

## 5. Behaviours

How do they actually shop and decide? Where do they spend time? Whose opinion do they trust?

- **How they research before buying:** _______________
- **Where they spend time online:** _______________
- **Where they spend time offline:** _______________
- **Who they trust for recommendations:** _______________
- **How often they buy your kind of thing:** _______________

---

## 6. Quote

The kind of thing they'd actually say, in their own words, about the problem your business solves. Imagine them describing it to a friend over a coffee — slightly informal, half-formed, real.

This single sentence does more work than any other field. It captures their voice and it captures the specific frustration that makes them a customer.

> "______________________________________________________
>
> _______________________________________________"

---

## Worked example: Family-friendly independent restaurant

```
Name: Amanda S.
Age: 38
Location: Oakville (10-minute walk from the high street)
Occupation: Accountant, works hybrid

Bio: Busy mum of two — kids are 4 and 6. Lives in Oakville for 8 years.
Husband works long hours, so weekend dinners out are her chance to feel
like a person again. Looking for somewhere local she can take the family
that doesn't feel like a chain.

Motivation: Finding a great local restaurant for weekend family dinners
that fits both kids' picky eating and her wanting to actually enjoy a
meal.

Pain points:
- Lack of family-friendly dining options nearby that aren't loud chains
- The chaos of taking small kids out — wants somewhere relaxed about it
- Picky eaters at home, so menu has to appeal to all four

Behaviours:
- Reads online reviews before trying anywhere new
- Values fast and friendly service ("we don't have an hour to wait for mains")
- Active on local Facebook parents' groups
- Goes out to eat 2–3 times a month, mostly Saturday evenings
- Trusts friend recommendations more than ads

Quote: "I'm tired of the usual chain restaurants. I'd love to find a
local spot the whole family enjoys. The kids are picky so it has to
work for them too — not just adults. And honestly, somewhere we don't
feel judged when the four-year-old is being a four-year-old."
```

That avatar is testable. Every marketing decision — what to put on the menu page, what photos to use on Google Business, whether to sponsor a local school event — can be checked against Amanda. Would Amanda notice this? Would Amanda care? Would Amanda click?

---

## How to use the avatar

Save it to a single document. Refer to it by name when you talk about your marketing. "Would Amanda book this?" is a much more useful question than "is this on brand?"

Most marketing decisions get faster and clearer once you can answer them by checking against one specific imagined person rather than abstract considerations.

---

## When to update

Re-read the avatar every quarter. Ask: is this still my ideal customer? Has the business shifted? Have I learned things about real customers that should refine the avatar?

Most updates are small. Occasionally you'll realise the business has shifted enough that the avatar has too — that's a signal that the wider strategy may also need a look.
