# Local Strategy Planner

The master worksheet that pulls every tactic in this skill into a single working plan for the next quarter. One page, three sections, three or four metrics. The discipline is reviewing it monthly, not perfecting it once.

If you're new to local marketing or coming back after a quiet year, this is the planner that turns scattered effort into a system.

---

## What this planner does

It forces three decisions:

1. **What's already running** that I need to keep maintaining
2. **What new initiatives** I'll launch this quarter (maximum two per month)
3. **What I'll measure** to know if any of it is working

Without those three, the work drifts. With them, the work has a shape.

Fill it in once at the start of each quarter. Look at it monthly. Adjust between quarters.

---

## The 10-point framework — your map

Every local marketing tactic sits inside one of these ten areas. Knowing where you are on each helps you spot what's missing.

For each, mark whether you're: 🟢 actively running it, 🟡 partially or inconsistently, 🔴 not doing it.

| # | Area | Status |
|---|---|---|
| 1 | Local SEO (website optimised for local search) | 🟢 / 🟡 / 🔴 |
| 2 | Online visibility (Google Business Profile, listings) | 🟢 / 🟡 / 🔴 |
| 3 | Localised content (regular posts about local area) | 🟢 / 🟡 / 🔴 |
| 4 | Strategic partnerships (active cross-promotion) | 🟢 / 🟡 / 🔴 |
| 5 | Community embedding (sponsorship, charity, schools) | 🟢 / 🟡 / 🔴 |
| 6 | Local engagement events (workshops, contests) | 🟢 / 🟡 / 🔴 |
| 7 | Social proof (testimonials displayed prominently) | 🟢 / 🟡 / 🔴 |
| 8 | Online reviews (active collection and response) | 🟢 / 🟡 / 🔴 |
| 9 | Flash promotions (occasional, well-executed) | 🟢 / 🟡 / 🔴 |
| 10 | Loyalty programme (running and promoted) | 🟢 / 🟡 / 🔴 |

Scan the list. Most local businesses have three or four greens, three or four ambers, and three or four reds. Your priorities for the quarter come from the reds and ambers — but pick *only two* to upgrade per quarter, not all of them.

---

## Section 1: Maintenance — what's already running

The boring but essential. The tactics that are alive and need to stay alive over the quarter.

For each maintenance item, name it and assign an owner (you, a team member, an outsourced person) and a cadence (daily / weekly / monthly).

| Tactic | Owner | Cadence | Notes |
|---|---|---|---|
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |

Common maintenance items:
- Posting to social media (twice weekly)
- Updating Google Business Profile (one post per fortnight)
- Asking for reviews at point of sale (every transaction)
- Responding to new reviews (within 48 hours)
- Localised blog or content publishing (one a week)
- Email to subscriber list (monthly)

The maintenance list is what keeps the system alive. Without it, the new initiatives in Section 2 sit on top of an empty foundation.

---

## Section 2: New initiatives this quarter

Pick **two or three** new things you'll launch this quarter. Maximum. The temptation is always to pick five or six. Resist. More than three new initiatives in a quarter and none of them get the attention they need.

For each:

### Initiative 1

**What it is:** _______________________________________________

**Which of the 10 areas it strengthens:** _______________

**The first specific action to take:** _______________________________________________

**Owner:** _______________

**Deadline for launch:** _______________

**Definition of done (how I'll know it's launched):** _______________________________________________

---

### Initiative 2

**What it is:** _______________________________________________

**Which of the 10 areas it strengthens:** _______________

**The first specific action to take:** _______________________________________________

**Owner:** _______________

**Deadline for launch:** _______________

**Definition of done:** _______________________________________________

---

### Initiative 3 (only if you're confident you can fit it)

**What it is:** _______________________________________________

**Which of the 10 areas it strengthens:** _______________

**The first specific action to take:** _______________________________________________

**Owner:** _______________

**Deadline for launch:** _______________

**Definition of done:** _______________________________________________

---

## Section 3: Tracking — three or four metrics

Pick three or four metrics to watch this quarter. Three or four — not ten.

The metrics worth picking from:

- **Foot traffic** (head counts, transactions, footfall counter)
- **New customer acquisition** (count + "how did you hear about us?")
- **Review velocity** (number of new reviews per month)
- **Online engagement on local content** (likes, shares, comments)
- **Conversion from prospect to customer** (enquiries → bookings)
- **Repeat purchase rate** (existing customers buying again)
- **Email list growth** (subscribers added per month)
- **Social media local follower growth**

Pick the ones that match your goals for the quarter. If you're focused on visibility, track engagement and review velocity. If you're focused on retention, track repeat purchase rate and loyalty programme sign-ups.

| Metric | Starting baseline | Target by quarter end |
|---|---|---|
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |

The starting baseline is what the number is right now. The target is what would make this quarter feel like a win.

---

## Review rhythm

This planner only works if you actually look at it.

**Monthly check-in (30–60 minutes):**

- Are the maintenance items actually happening?
- Are the new initiatives on track?
- What do the metrics say?
- What needs adjusting before next month?

**Quarterly replan:**

- Which initiatives worked? Which didn't?
- What's the highest-leverage thing for next quarter?
- What gets dropped?
- Update the 10-point framework status — what's moved from red to amber to green?

A monthly hour spent reviewing is the cheapest insurance the strategy has against drift.

---

## A worked example

Quarter Q3, family-friendly independent restaurant in Oakville.

**10-point status:**
- 🟢 Local SEO, online visibility, social proof
- 🟡 Localised content, online reviews, engagement events
- 🔴 Partnerships, community embedding, flash promos, loyalty

**Maintenance:**
- Two social posts a week (owner: Sarah)
- Monthly Google Business post (owner: Mike)
- Ask every guest for a review at end of meal (owner: floor team)
- Respond to all new reviews within 48 hours (owner: Sarah)

**New initiatives this quarter:**
1. Launch a partnership with the local independent cinema across the road — diner-and-film evening menu (owner: Mike, launch by week 4, done = first joint event run)
2. Set up a simple loyalty programme — 10th meal free, basic stamp card (owner: Sarah, launch by week 6, done = cards printed and live)
3. Run a back-to-school flash promo end-of-September — kids eat free for the first weekend (owner: Mike, launch by week 12, done = promotion delivered)

**Metrics tracked:**
- Foot traffic on Saturday evenings (baseline 78, target 95 by quarter end)
- New customer count via "how did you hear?" (baseline 8/week, target 12)
- Loyalty programme sign-ups (baseline 0, target 100 by quarter end)
- Review velocity (baseline 4/month, target 8/month)

That fits on a single sheet of paper. A monthly hour reviewing it. Quarterly replan. Most local businesses never get this clear, and they wonder why their marketing feels chaotic.
