# UVP Builder

A working session to write a Unique Value Proposition that's actually useful. Most local businesses don't have a UVP. Of those that do, most have a UVP that could apply to any other business in their category. Both are problems.

A good UVP is specific enough that it makes a particular kind of customer feel addressed and a particular kind of competitor feel beaten. This worksheet gets you to one in about forty-five minutes.

---

## What a UVP actually does

A UVP is a short statement — usually one sentence, sometimes two — that says:

- **Who you serve specifically**
- **What you help them achieve**
- **What's different about how you do it**

It's the answer to the question: *"Why should I choose you over the alternatives?"* — answered in a way that's clear, concrete, and credible.

Three things a UVP is *not*:

1. **A tagline.** "Excellence Delivered" is a tagline (also a bad one). It says nothing.
2. **A list of features.** "20 years' experience, fully insured, satisfaction guaranteed" is features. It tells me what you have. It doesn't tell me why I'd choose you.
3. **A vision statement.** "To make every local business thrive" is aspiration. It belongs on a wall, not in your shop window.

---

## Before you start

Have these three things to hand:

1. Your **Local Customer Avatar** (or a clear sense of one specific ideal customer)
2. Your **Competitor Questionnaires** (or notes on your top three competitors)
3. Five to ten minutes thinking through the question: "What do my best customers tell me they value about working with us?"

Without these, you'll end up writing a UVP based on guesses rather than evidence.

---

## Step 1: Name the primary problem

What's the single biggest problem your ideal local customer has, that your business genuinely solves?

Not "marketing problems" or "needing legal help". Specific. The thing that, when they think about it, makes them go: "I need to do something about this."

Use the language they'd use, not industry language.

**The primary problem:**

_______________________________________________

_______________________________________________

---

## Step 2: Describe the outcome you deliver

What changes for them when they work with you? What's different about their life or their business after you've done your bit?

The outcome is the thing they actually want. The product or service is just the vehicle.

**The outcome:**

_______________________________________________

_______________________________________________

---

## Step 3: Identify what's different about how you do it

Now the hard part. Look at your competitor questionnaires. What does your business do that:

- Solves the customer's problem at least as well as the alternatives, **and**
- Is specifically *different* from how the competition does it?

This is the bit most local businesses fudge. They want to claim differences they can't really back up. Don't. Pick something that's genuinely true and specifically yours.

It can be:

- A method or approach (faster, simpler, more thorough, more personal)
- A specialisation (this exact kind of customer, this exact kind of problem)
- A service depth (we do X that they don't)
- A relational quality (longer relationships, more trust, more accountability)

**What's different about how I do it:**

_______________________________________________

_______________________________________________

---

## Step 4: Combine into a draft UVP

Use this template as a starting point:

```
For [specific customer], [your business name] provides [outcome they want]
by [your distinctive method or approach].
```

Or its inverse:

```
[Your business name] is the [your kind of business] in [area] that helps
[specific customer] [outcome] without [the thing alternatives make them
put up with].
```

**Your draft:**

_______________________________________________

_______________________________________________

---

## Step 5: Test the draft

Run the draft through five tests. If any of them fail, tighten until they pass.

**Test 1 — The substitution test.** Could a competitor put this exact sentence on their website? If yes, it's not specific enough. Tighten until the answer is no.

**Test 2 — The customer test.** Would your ideal customer (Amanda from your avatar) read this and recognise themselves and their problem? If they'd think "this is for someone else", you've drifted.

**Test 3 — The plain English test.** Read it aloud. Does it sound like something a real person would say, or like marketing? Cut anything that sounds like marketing.

**Test 4 — The credibility test.** Can you actually deliver what you've claimed? If yes, fine. If "yes, mostly" or "yes, sometimes", scale the claim back to what's reliably true.

**Test 5 — The memorability test.** Could you say this aloud in conversation without checking your notes? If you can't, the customer can't either.

---

## Worked examples

**Craft Bakery (decent):**

> The Crafty Baker is the only neighbourhood bakery in [town] making fresh artisanal cakes, pies, cookies, and pastries every morning — for the kind of locals who'd rather buy from a person than a brand.

That sentence does work: it's specific (artisanal, fresh, neighbourhood, every morning), it positions against the alternative (brand-led chains), and it speaks to a particular customer (the kind who value the relational dimension of buying local).

**Local Law Firm (decent):**

> Smith & Associates is the family law practice in [town] that takes the time to understand each client's situation properly — rather than treating divorce as paperwork on a timer.

Specific, positions against a real competitor problem (corporate law firms billing every six minutes), and speaks to the underlying anxiety the ideal client is feeling.

**A weaker UVP rewritten:**

Weak: "Smith & Associates: Compassionate legal guidance from experienced local attorneys."

Why it's weak: every law firm could plausibly claim this. There's no specificity, no positioning against alternatives, no language that distinguishes Smith & Associates from any other "compassionate" firm.

The rewrite (above) is what happens when you actually do the four steps with rigour.

---

## How to use the UVP once you have it

Put it everywhere:

- Homepage hero section
- Google Business Profile description
- Top of your social media bios
- Email signature
- Networking introduction (paraphrased into spoken English)
- Sales conversations
- Pitch documents

Consistency matters. The UVP isn't just a tagline — it's the spine of all your messaging. Every piece of marketing should be a variation on it, not a departure from it.

---

## When to revisit

Re-read the UVP every six months. Ask:

- Is it still true?
- Is it still distinctive (or have competitors caught up)?
- Is it still aimed at the customer I most want?

If any answer is "not really", it's time for a tightening pass.
