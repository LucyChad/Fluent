# Convert and Keep Customers

## What this step is for

The user has a clear customer avatar, a sharp UVP, online visibility, and an offline network bringing prospects into orbit. Now those prospects need to convert into customers — and once they do, they need to keep coming back.

The four levers in this step are social proof, online reviews, flash promotions, and loyalty programmes. Each one solves a specific friction in the buying or repeat-buying process. None of them are sophisticated. All of them work when done with discipline.

The mistake most local businesses make is doing each of these once. They put up a single testimonial, ask for reviews for a fortnight, run a flash sale at Christmas, fiddle with a loyalty card system once. Each one needs to be a habit, not an event.

## Social proof: showing real people choosing you

Consumers trust the recommendations of strangers more than the claims of businesses. Social proof is the body of evidence the business can show that proves real people — ideally local people — have chosen, used, and recommended what's on offer.

The sources the user already has, often without realising:

- **Customer testimonials.** Quotes, written or video, from real customers about what the business did for them.
- **Online reviews.** Google, Facebook, Yelp, industry-specific. (Detail on managing these in the next section.)
- **Awards and certifications.** Local business awards, industry certifications, professional credentials. Even minor ones earn trust.
- **Press mentions.** Local newspaper coverage, community newsletter mentions, podcast appearances.
- **Customer photos and social posts.** People posting about their experience, often unprompted.
- **Visible client lists.** For B2B local businesses — logos of recognised local clients.
- **Specific case studies.** Longer-form stories of customer transformations.

The discipline:

**Collect actively.** Most local businesses get a stream of social proof by accident — a kind email here, a review there, a customer's social media tag. The user should treat collection as systematic. Every transaction is an opportunity for a review. Every happy customer is a potential testimonial. A simple monthly habit (review request, testimonial ask) compounds quickly.

**Prefer specific over general.** "Great service!" is forgettable. "I came in stressed about a leak the day before guests arrived. They came out within an hour and fixed it for less than I expected" is unforgettable. Ask customers to be specific.

**Display prominently.** Social proof needs to live where prospects are deciding. Homepage. Product or service pages. Above the fold on landing pages. Physical signage in the business. Email signatures. Social media bio. Anywhere a prospect might be hovering.

**Local beats national.** A testimonial from someone visibly local — same town, recognisable area, ideally photographed at the venue — is more persuasive than a higher-profile testimonial from someone the prospect doesn't relate to.

The asset Local Customer Avatar is for clarifying who needs to see what proof. The right testimonial is the one that mirrors the avatar's profile and concerns.

## Online review management

Online reviews are the highest-leverage form of social proof for most local businesses. They influence both ranking (more reviews and faster review velocity boost local search performance) and conversion (most prospects read reviews before deciding).

**Encourage positive reviews actively.**

- Generate a QR code linked directly to the Google Business review page. Tools like QR Code Generator (from Bitly) make this free and easy.
- Display the QR code where customers are happy and have a moment — back of business cards, sign next to the till, wall at the exit, on receipts, in email signatures, on the website, on product packaging or materials.
- Pair the QR code with a clear call to action: "Scan here to leave us a review" or "How was today? Tell Google about it."
- Train staff to ask. A simple "If you've got a moment, a quick Google review would help us a lot" produces results when delivered warmly at the right moment.
- Aim for review velocity over review volume. Twenty reviews in a year tells Google the business is alive; twenty reviews on a single Saturday looks suspicious.

**Respond to every review, positive and negative.**

For positive reviews: short, warm, specific to what they said. Not "thanks for the review!" — "Thanks for mentioning the carrot cake — it's our manager's recipe and she'll be chuffed."

For negative reviews: handle with care. Three rules.

1. **Respond promptly and professionally.** Within 24 hours where possible. Never defensive. Never combative.
2. **Acknowledge their experience.** If the fault is the business's, apologise specifically. If the fault is more complicated, express genuine regret about the experience without admitting fault.
3. **Take the conversation offline.** "Could you email me at [direct address] so I can look into this for you specifically?" — gets the back-and-forth off the public review.

A useful template for negative review responses:

> Hello [Name],
>
> I'm [Owner name], and I'm so sorry to hear that [the specific issue]. That's not the experience we want anyone to have, and I'd really like to understand what happened.
>
> Could you drop me an email at [address] so I can look into this directly and make it right? Either way, thank you for letting us know — feedback like this is how we improve.
>
> [Owner name]

A well-handled negative review often produces *more* trust with prospects than a perfect five-star average. It shows the business is human, listening, and willing to take ownership. Future readers see that.

## Flash sales and limited-time promotions

A flash sale is a one-time discount or special offer with a short deadline — usually 24 hours to a week. Done well, it produces a burst of revenue, attracts new customers, clears stock, or fills quiet times. Done badly, it cheapens the brand and trains customers to wait for the next discount.

The discipline:

**Be clear about the goal.** Each flash sale serves one of: boosting visibility, attracting new customers, selling surplus stock, increasing sales at quiet times, or generating revenue. The goal shapes everything — the offer structure, the audience, the channels, the messaging.

**Pick the right format for the business.** A clearance sale for a fashion retailer. A happy-hour discount for a restaurant. An "oil change special" for a garage. A "free 30-minute consultation" for a service business. The format has to be plausible for the kind of business — surprise discounts on bespoke services often look desperate; weekend specials at a restaurant look natural.

**Create real urgency.** A flash sale only works if there's a genuine deadline. "This weekend only." "Until 5pm Friday." "First 50 customers." Vague urgency ("for a limited time") gets ignored.

**Don't run them too often.** Flash sales work because they're rare. A business running a "flash sale" every fortnight has trained its customers to wait. Two or three a year is a healthy cadence; once a quarter for retailers; less for service businesses.

**Plan the promotion in a week.** From decision to launch, a flash sale doesn't need months. Decide the offer, the deadline, the channels. Spend three or four days promoting (social, email, SMS, signage, partner amplification). Run it. Follow up.

**Promote across every channel.** Social media (with countdown posts and visuals), email and SMS (with urgency triggers), physical signage (window decals, sidewalk signs, banners), local press (where applicable), partners (cross-promote each other's flash sales).

The Flash Sale Planner asset walks through the full plan from decision to follow-up.

## Loyalty programmes that retain customers

Acquiring a new customer costs five times more than retaining an existing one. A loyalty programme — even a simple one — is the most cost-effective marketing tool a local business has.

The forms that work:

**Stamp or punch cards.** The classic. Buy nine coffees, get the tenth free. Buy ten haircuts, get a free deep-condition treatment. Cheap to print, instantly understood, works for most retail and service businesses.

**Spend-tracking cards.** Customers earn points or status based on cumulative spending. Tier-based — gold, platinum — with better perks at each tier. Suits businesses with higher-value transactions or recurring service contracts.

**Birthday rewards.** A small gift, free service, or discount delivered around the customer's birthday. Requires capturing birth dates at sign-up. Powerful for retention; customers feel remembered.

**Customer appreciation giveaways.** Periodic "we're saying thank you" gestures. A free month of service after a year. A free product on a repeat customer's tenth visit. Creates moments of delight that drive word-of-mouth.

**App-based programmes.** Tools like Flex Rewards, Oappso, StampMe automate the tracking. Customers don't have to bring a card. Works well for businesses where customers visit frequently and want frictionless rewards.

The selection rule: the programme has to be simple enough that staff can explain it in 30 seconds and customers can grasp it in 60. Complicated multi-tier systems with redemption restrictions kill participation.

The promotion rule: the loyalty programme has to be actively visible. Mentioned at every transaction. On every receipt. In every email signature. On the website. The biggest reason loyalty programmes fail is that customers never know they exist.

## What this step produces

By the end of this work the user has:

1. A live system for collecting and displaying social proof, especially online reviews
2. A QR-code-driven review encouragement habit and a template for handling negative reviews
3. The plan for one flash sale in the next quarter, sequenced and ready to run
4. A simple loyalty programme up and running, with promotion built into every customer touchpoint

That's the conversion and retention layer. Combined with the visibility layer (online and offline) and the foundation layer (avatar, UVP, market knowledge), the business now has the full local marketing stack — minus the strategy that ties it all together. That's the next module.
