# Get Found Online Locally

## What this step is for

The user has a clear avatar, a defined geography, and a sense of who they're competing with. Now they need to be findable when an ideal local customer searches for what they offer. Not findable in general — findable when the search has local intent.

Most local businesses get this wrong by trying to compete with national-level SEO strategies. They don't need to. The local search game is much smaller, much more winnable, and centres on three things: a great Google Business profile, sensible local SEO on the website, and a steady stream of localised content. Done reasonably well, this puts a small business at the top of the local results within a few months. Done badly, it's a website nobody finds and a half-completed listing nobody clicks.

## The Google Business Profile is the highest-priority surface

Most local searches now happen on Google, and most local Google searches surface the local pack — the map and three-business box that appears above organic results. The Google Business Profile is what determines whether the user is in that pack.

A Google Business Profile that wins:

- **Complete in every field.** Name, address, phone, hours, website, category, description. Missing fields hurt ranking and trust.
- **Categorised correctly.** Primary category that matches what the business actually is, plus secondary categories for everything else relevant. The categories are signals.
- **Photos that earn clicks.** Exterior, interior, products or services, the team. Real photos, taken on a phone in good light, beat stock photography every time. Aim for at least 10 to start, more over time.
- **Posts published regularly.** Updates, offers, events, news. A business that posts to its profile signals to Google that it's active, which helps ranking. Once a fortnight is enough; once a week is better.
- **Reviews actively encouraged.** More reviews and faster review velocity both lift ranking. (Detail on review tactics is in the convert-and-keep-customers reference.)
- **Q&A managed.** Google lets users ask questions of the business. Unanswered questions hurt; answered ones help.

The user's first job is making sure the basics are airtight. Most local businesses skip half of this and wonder why they don't rank.

## Local SEO basics that actually move the needle

There's a lot of local SEO advice that's either over-engineered or false. The moves that actually matter:

**Location keywords on the website.** The town or neighbourhood name should appear naturally in the homepage, about page, contact page, and key service or product pages. Not stuffed; mentioned. "Family-friendly Italian restaurant in [town]" beats "the finest dining experience in our region".

**Long-tail keyword phrases.** People searching with intent use specific phrases — "best vegan brunch in [neighbourhood]", "emergency plumber [town] near me", "wedding cake bakery [town]". These are easier to rank for than generic terms and signal high purchase intent. The user's keyword list should be heavy on long-tail.

**Page titles and meta descriptions.** Every page needs a title tag and a meta description that includes location. These show in search results and influence both ranking and clicks.

**Service or location-specific pages.** A business serving multiple neighbourhoods or offering multiple services should have a dedicated page for each one. One thin "services" page hurts; six focused pages help.

**Schema markup.** A small technical addition that helps Google understand the business — its category, hours, location, reviews. Most modern website builders (Squarespace, Wix, Shopify) add basic schema automatically. If the user's site doesn't, a one-time setup is worth the effort.

**Backlinks from local sources.** Local newspapers, community organisations, business associations, partner websites. A handful of links from real local sources outweighs hundreds of generic directory links.

The user doesn't need to master SEO to do this well. They need to do these basics consistently, and ignore the noise about "advanced" tactics that don't apply to local businesses.

## Localised content: the slow-burn lever

Search engines reward businesses that publish relevant content over time. For a local business, the most useful content is content that's anchored in the local community.

What to write or post about:

- **Local events the business is part of or supporting.** "We're at the [town] Christmas market this Saturday."
- **Neighbourhood references.** "Our favourite walking routes after a coffee" or "What's open during [local festival]".
- **Customer stories.** "Meet [name], one of our regulars and what brought them in" — with permission.
- **Behind-the-scenes content.** Setup, team introductions, sourcing stories. Anything that humanises the business.
- **Local-relevant tips.** "Five things we wish more [town] residents knew about [topic]".
- **User-generated content.** Customer photos, reviews, social posts — reposted with credit. Costs nothing, builds local social proof.

The cadence: one piece of localised content a week is more than enough. The user shouldn't aim for daily; they should aim for consistent. Six months of weekly localised content is a serious search asset.

## Third-party listings: when to bother

After Google Business Profile, the question is which other listings are worth claiming.

The shortlist:

- **Bing Places.** Free, easy, takes 15 minutes. Worth doing for the Microsoft search audience.
- **Apple Maps.** Free, important for users on iPhones who use Maps for local search.
- **Facebook Page.** Necessary if the user does any Facebook activity. Acts as a secondary listing.
- **Yelp.** Worth claiming if it's culturally relevant in the user's market (US restaurants and services especially). Less critical in the UK.
- **Industry-specific directories.** Tradespeople: Checkatrade, Trustpilot, Bark. Restaurants: TripAdvisor, OpenTable. The user knows their industry.

Beyond this list, most directories are SEO theatre — they exist to charge fees, not drive customers. Skip them.

The discipline that makes any listing strategy work: **identical NAP data across every listing.** Name, address, phone number — written exactly the same way everywhere. Different phone numbers, abbreviated addresses, or business name variations confuse search engines and hurt ranking. Boring but vital.

## What this step produces

By the end of this work the user has:

1. A complete, photo-rich, regularly-posted Google Business Profile
2. A website with location keywords sensibly placed across the key pages
3. A starter list of long-tail keyword phrases to target in content
4. A weekly cadence for publishing localised content
5. A handful of third-party listings claimed and consistent

That's the visibility infrastructure. Once it's in place, the partnerships and offline tactics in the next module amplify it — every offline event becomes content, every partnership becomes a backlink, every customer interaction becomes a potential review.
