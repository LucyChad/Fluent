# Know Your Local Market

## Why this is the foundation

Most local marketing fails because the business never properly defined the local market it's trying to win. They aim at "people in the area" — and "people in the area" is not a market. It's a postcode. The actual market is a specific kind of person with a specific live concern, in a specific geography, who would walk past three competitors to choose this business.

Knowing the local market means three things specifically: knowing the geographic scope, knowing the customer in detail, and knowing the competitors well enough to position around them. Get those three right and almost every later marketing decision becomes obvious. Skip them and the user spends years on tactics that don't connect to anything.

## Define what "local" means for this business

Local isn't always a postcode. Sometimes it's a five-mile radius. Sometimes it's a fifteen-minute drive. Sometimes it's a single neighbourhood within a larger town. Sometimes it's a few specific streets where this kind of customer concentrates.

The right local scope is whatever distance your real customers are actually willing to travel for what you offer. Not what you wish they'd travel. What the data shows.

Three rough templates:

- **Walking-distance local.** Cafés, salons, corner shops, takeaways. The catchment is the neighbourhood. Maybe a fifteen-minute walk.
- **Short-drive local.** Restaurants, dentists, gyms, garages. The catchment is the town or a section of a city. Maybe a fifteen-minute drive.
- **Service-area local.** Plumbers, mobile beauty, in-home care, mobile pet groomers. The catchment is wherever the business will travel to. Could be wide.

The user's actual scope might not match the obvious template. A specialist butcher might pull customers from forty miles for a specific cut. A general newsagent won't pull anyone from outside two streets. The data tells the truth: where do existing paying customers actually live? That's the answer.

Once the scope is defined, every later decision — where to advertise, where to network, which keywords to target, which events to attend — gets sharper.

## Build the Local Customer Avatar

A Local Customer Avatar is a structured description of one specific real-feeling person who represents the user's ideal local customer. Not a marketing-avatar archetype with a stock photo. Not a demographic ("women, 35–55, professional"). A person with a name, a job, a routine, a specific live concern, and a specific reason to walk through this particular door.

The point isn't accuracy at the population level. The point is specificity strong enough that every marketing decision can be tested against it: would *this person* notice this poster? Would *this person* want this offer? Would *this person* find this Google Business photo helpful?

The fields that matter:

- **Name.** Made up. Use a name that sounds local to the area.
- **Age.** A specific number, not a range.
- **Location.** Not just "the local area" — the actual neighbourhood or street section.
- **Occupation.** What they do for work, in plain language.
- **Bio.** Two or three sentences on their life shape — family, routine, what their week looks like.
- **Motivation.** What they're actively trying to do or solve right now. Specific to today.
- **Pain points.** What's frustrating them. The frictions that this business could remove.
- **Behaviours.** How they shop. Where they look. What they read. Who they trust.
- **Quote.** The kind of thing they'd actually say about the problem this business solves. In their words.

The Customer Avatar asset in this skill pack walks the user through filling each of these in. One detailed avatar beats five vague ones.

## Research the local market quickly

A good avatar is built from real evidence, not invention. Five quick-and-cheap research tactics that produce a usable avatar in an afternoon:

**Existing customer data.** If the business has any record of who buys — even just card payments, a CRM list, social media followers — patterns appear. Most-frequent ages. Most-common postcodes. Repeat-purchase patterns.

**Short surveys.** Five questions sent to existing customers via email, text, or a card at the till. The questions: who do you live with, what would you change about [the business], where else do you go for [the same product/service], how did you first hear about us, what would make you visit more often.

**Review mining.** Reading the user's own reviews and competitor reviews on Google, Facebook, Yelp. The phrases customers use to describe the experience are the language to use in marketing. Praise tells you what's working; complaints tell you what gaps exist in the market.

**Local social media observation.** Following local-area Facebook groups, Nextdoor neighbourhoods, local Instagram accounts. People say what they want, what they hate, and what they'd recommend in these spaces. Free market research.

**Conversations with staff.** Front-line staff hear customer complaints, requests, and casual remarks all day. A 20-minute conversation with the right team member produces insights that take a market researcher weeks.

Most local businesses skip this step entirely. They guess. The ones that do it pull ahead within a single quarter.

## Benchmark local competitors

Knowing the competition isn't about copying. It's about positioning. The user has to know who else is competing for the same local customer's attention so they can differentiate clearly and fill the gaps.

Pick the top three real competitors. Not industry-wide. Not national chains (unless they're the actual competition). The three businesses that an ideal local customer would consider before walking through this user's door.

For each one, capture:

- **Their core offer.** What they sell, who they sell it to.
- **Their UVP, if they have one.** Or their best guess at how to position the business if they don't.
- **Pricing relative to this business.** Cheaper, similar, premium.
- **Their physical and online presence.** Storefront, website, Google Business profile, social media, review count and average.
- **What they're known for locally.** Word-of-mouth reputation. The thing customers actually mention.
- **Visible gaps.** Where they're weak, slow, or missing — and where this business could win.

The Competitor Questionnaire asset walks through this for each of the top three. The questionnaire matters less than the discipline of *actually researching* — actually visiting the competitor's premises, actually reading their reviews, actually scrolling their social media.

The output of competitor benchmarking isn't a spreadsheet. It's a clear-eyed view of what the user's business does that no one else in the area does, and what the others are doing better that this business needs to match or beat. That clarity drives the UVP work that follows.

## What this step produces

By the end of this work the user has, on paper:

1. A defined local scope — the geography their marketing should target
2. A specific Local Customer Avatar with a name, profile, motivation, and quote
3. A set of competitor profiles for the top three local rivals
4. A working understanding of where the gap is — what their business can credibly own that no one else owns

That's the foundation. Every later module — UVP, online visibility, partnerships, conversion, loyalty — is shaped by these four artefacts. Skip them and you build a house on sand. Do them and the rest of the work compresses by a factor of five.
