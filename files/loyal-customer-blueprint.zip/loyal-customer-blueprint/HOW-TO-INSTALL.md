# How To Turn One-Time Buyers Into Loyal Customers

*Installation guide*

This skill works by giving your AI assistant deep, specialist knowledge about customer loyalty for small businesses — identifying who your loyal customers actually are, building a communication system that earns trust, designing offers that reward loyalty, gathering feedback that improves the business, monitoring what's working, and pulling it all into a 30-day plan you can actually run. Once it's set up, you can ask it for help on any loyalty decision and it'll bring the whole framework to bear without you having to remind it what it knows.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Loyal Customer Blueprint" or "Customer Loyalty"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/identifying-your-loyal-customers.md`
- `references/communicating-with-customers.md`
- `references/offering-something-special.md`
- `references/asking-for-feedback.md`
- `references/monitoring-and-implementation.md`
- `assets/loyal-customer-profile.md`
- `assets/communication-plan.md`
- `assets/offers-design-worksheet.md`
- `assets/feedback-question-bank.md`
- `assets/30-day-loyalty-plan.md`

**Step 3: Add your business context**

In the **Project instructions** field, paste and complete the following:

```
My business: [What you do, who you serve. Be specific — "yoga studio in Oakville, mostly working women aged 30–55" beats "fitness business".]
Roughly how many customers I have: [Total customer base size — paying customers, not list size]
Channels I'm currently using: [Email, Instagram, SMS, etc.]
My biggest customer loyalty challenge: [The thing you're stuck on or want to fix]
My loyal-customer profile (if you have one): [Paste it here from the worksheet, or leave blank if you haven't built it yet]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a customer loyalty strategist who already knows your business.

A good first message: *"Help me identify my loyal customers — let's start with the questions and work through to a profile."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A customer loyalty strategist for small businesses. Knows the full loyalty toolkit — identifying loyal customers, building communication systems, designing offers, gathering feedback, and running a 30-day implementation plan."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all five files in `references/`, and all five in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical customer loyalty strategist for small businesses. Use the uploaded knowledge files to guide every response. Always work from my actual customer base, not in the abstract. Apply the six-step framework — identify, communicate, offer, feedback, monitor, plan. Have opinions and share them.

My context:
- My business: [fill in]
- Roughly how many customers I have: [fill in]
- Channels I'm currently using: [fill in]
- My biggest loyalty challenge: [fill in]
- Loyal-customer profile (if you have one): [paste it, or leave blank]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Loyal Customer Blueprint*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- My business: [fill in]
- Roughly how many customers I have: [fill in]
- Channels I'm currently using: [fill in]
- My biggest loyalty challenge: [fill in]
- Loyal-customer profile (if you have one): [paste it]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your business

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**Your specific business and customer base.** Not just your industry — the specific kind of customers you have. "Local yoga studio in Oakville with about 200 active members, mostly working women" beats "fitness business".

**The channels you're already using.** The skill needs to know whether you're already running email, social, SMS — otherwise it'll suggest things you've already done.

**Your loyal-customer profile, if you have one.** If you've built it from the worksheet, paste it. If not, the first conversation can be building it. Either is fine.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Help me build my loyal-customer profile — let's start with the questions."*
- *"Design three loyalty offers for me — a welcome, an ongoing reward, and a surprise."*
- *"What feedback questions should I ask my VIPs this quarter?"*
- *"Walk me through the 30-day loyalty plan — let's set it up for next month."*
- *"My loyalty programme has stalled. Diagnose what's wrong."*
- *"How do I get more of my one-time customers to come back?"*
- *"I want to start a referral programme. What's the simplest version that works?"*

---

*Loyal Customer Blueprint is part of the Fluent skill library. More skills at fluent.md.*
