# 30-Day Loyalty Plan

The implementation worksheet that turns your loyalty strategy into specific actions over the next 30 days. Pre-launch checklist, action plan, tracking, and end-of-month reflection — all on one page.

Plan for 30 minutes to fill in initially. 60 minutes total over the month for monitoring and reflection.

---

## Set the 30-day goal

Specific, measurable, achievable, relevant, time-bound.

**Examples that work:**

- *Increase repeat customer purchases by 5% over the next 30 days*
- *Collect feedback from 50% of VIP customers within 30 days*
- *Launch tiered reward system and enrol 25 customers within 30 days*
- *Increase email open rate on loyalty communications by 15% over the next 30 days*

**Examples that don't:**

- *Improve customer loyalty* (not measurable)
- *Get more loyal customers* (not specific)
- *Build a world-class programme* (not time-bound, not achievable in 30 days)

**Your 30-day goal:**

_______________________________________________

**How you'll measure success:**

_______________________________________________

**Starting baseline (the number today):**

_______________________________________________

---

## Pre-launch checklist

Before day 1, the foundations should be in place. Tick each item as it's done.

### Identification
- [ ] Loyal-customer profile completed (use the worksheet)
- [ ] VIP segment of 10–30 names identified
- [ ] Profile patterns documented in plain language

### Communication
- [ ] Two or three core channels chosen
- [ ] Touchpoint map drafted (pre-purchase, at-purchase, post-purchase, between, reactivation)
- [ ] Personalisation commitments decided
- [ ] Frequency cadence set per channel

### Offers
- [ ] Welcome / first-time-repeat offer designed
- [ ] Ongoing loyalty reward designed
- [ ] At least one surprise offer planned
- [ ] Delivery mechanism for each set up

### Feedback
- [ ] Question bank chosen (3–4 closed + 2–3 open)
- [ ] Gathering method picked (email / forms / direct / etc.)
- [ ] Follow-up message template drafted

### Tracking
- [ ] Tracking system (spreadsheet or tool) set up
- [ ] Three monthly metrics decided
- [ ] First-day baselines recorded

### Goal
- [ ] 30-day goal written down
- [ ] Success metric and starting baseline noted above

If any of these are unticked, the launch is premature. Don't go without them.

---

## Action plan

Sequence the work over the four weeks. Specific tasks, owners, deadlines.

### Week 1

| Task | Owner | Due | Status |
|---|---|---|---|
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |

**Suggested week 1 priorities:**
- Issue welcome offer to the eligible cohort
- Send first newsletter to the loyalty segment
- Surprise offer to two or three named VIPs
- Record day-1 metrics

---

### Week 2

| Task | Owner | Due | Status |
|---|---|---|---|
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |

**Suggested week 2 priorities:**
- Run first feedback round (one of the question sets)
- Issue loyalty reward to VIPs eligible
- Mid-month metrics check
- Adjust frequency or offers based on early signal

---

### Week 3

| Task | Owner | Due | Status |
|---|---|---|---|
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |

**Suggested week 3 priorities:**
- Send follow-up to feedback respondents (thank-you + what you'll do)
- Surprise offer to two or three more VIPs
- Reactivation outreach to lapsed customers (if applicable)
- Week 3 metrics check

---

### Week 4

| Task | Owner | Due | Status |
|---|---|---|---|
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |
| _______________ | _______________ | _______________ | ☐ |

**Suggested week 4 priorities:**
- End-of-month metrics summary
- 30-day reflection (use the section below)
- Decide what's repeating, what's stopping, what's new for next 30 days
- Set the next 30-day goal

---

## Tracking dashboard

Update weekly. Twenty minutes max.

| Metric | Day 1 | Day 7 | Day 14 | Day 21 | Day 30 |
|---|---|---|---|---|---|
| _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |

| Offer | Issued | Redeemed | Redemption rate |
|---|---|---|---|
| Welcome offer | _______________ | _______________ | _______________ |
| Loyalty reward | _______________ | _______________ | _______________ |
| Surprise offer | _______________ | _______________ | _______________ |

**Feedback round metrics:**
- Survey response rate: _______________
- CSAT (average): _______________
- NPS: _______________

---

## End-of-30-days reflection

Twenty minutes of honest assessment at day 30. The single highest-leverage step in the whole programme — without it, the next 30 days are guesswork.

### What worked

What hit the goal? What exceeded expectations? What surprised you in a good way?

_______________________________________________

_______________________________________________

---

### What didn't work

Where did the metrics fall short? What was harder than expected? What was wasted effort?

_______________________________________________

_______________________________________________

---

### What you learned about your customers

What did the feedback, the redemption patterns, or the engagement signals tell you about your customers that you didn't know on day 1?

_______________________________________________

_______________________________________________

---

### What you'll change for the next 30 days

Based on this reflection — what's stopping, what's repeating, what's new?

**Stopping:**

_______________________________________________

**Repeating (with what adjustments):**

_______________________________________________

**Adding:**

_______________________________________________

---

### The next 30-day goal

The single specific outcome you'll aim for in the next month. Built on what you learned this month, not just a continuation of the same intent.

_______________________________________________

---

## How this compounds

A 30-day cycle done once is a launch. A 30-day cycle done six times in a row is a system that's been refined six times — usually unrecognisable from where it started.

The discipline isn't doing the first cycle perfectly. It's doing the next cycle informed by the last one. Most loyalty programmes fail not because the strategy was wrong but because the cycle never got past month one. Don't be that user.
