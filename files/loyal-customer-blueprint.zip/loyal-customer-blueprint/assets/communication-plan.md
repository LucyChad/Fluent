# Communication Plan

A one-page plan for how the business will communicate with customers between purchases. Channels, touchpoints, personalisation, frequency, and metrics — all settled in one document, ready to execute.

Plan for 30 minutes. Have your loyal-customer profile to hand — channel choices and frequency should match what your VIPs actually engage with.

---

## 1. Channel selection

Pick two or three core channels. Not all five.

- [ ] **Email** — best for: structured content, segmented offers, anything with substance. Cost: low. Friction to start: low.
- [ ] **Social media** — best for: ongoing brand presence, community, real-time engagement. Cost: time. Friction to start: low (likely already running).
- [ ] **SMS / text** — best for: time-sensitive moments, appointment reminders, flash offers. Cost: per-message charges. Friction to start: medium (opt-in setup).
- [ ] **WhatsApp** — best for: closer relationships, image and video sharing, international reach. Cost: low. Friction to start: medium (broadcasting setup).
- [ ] **Video calls** — best for: high-value services, workshops, focus groups, premium tier. Cost: time. Friction to start: low (any video tool).

**Your two or three:**

1. _______________
2. _______________
3. _______________ (optional)

Why these match your VIP profile: _______________________________________________

---

## 2. Touchpoint map

For each stage of the customer relationship, what's the specific touchpoint you'll deliver?

### Pre-purchase (discovery, research, first contact)

**Touchpoint:**

_______________________________________________

**Channel:**

_______________________________________________

---

### At-purchase (welcome, thank-you, confirmation)

**Touchpoint:**

_______________________________________________

**Channel:**

_______________________________________________

---

### Post-purchase (delivery, satisfaction check, feedback ask)

**Touchpoint:**

_______________________________________________

**Channel:**

_______________________________________________

**Timing (how soon after purchase):**

_______________________________________________

---

### Between purchases (newsletter, social, offers, useful content)

**Touchpoint:**

_______________________________________________

**Channel:**

_______________________________________________

**Cadence:**

_______________________________________________

---

### Reactivation (when a customer has gone quiet)

**Touchpoint:**

_______________________________________________

**Channel:**

_______________________________________________

**Trigger (e.g., 90 days since last purchase):**

_______________________________________________

---

## 3. Personalisation

What's the minimum viable personalisation you'll commit to in every communication?

- [ ] First name in greeting (when you have it)
- [ ] Reference to last purchase (when relevant)
- [ ] Segmented messaging (different content for new / regular / lapsed / VIP)
- [ ] Lifecycle moments (birthday, anniversary of first purchase, milestone)
- [ ] Channel preference per customer (don't send to channels they ignore)

**The one personalisation move you'll definitely commit to in every communication:**

_______________________________________________

---

## 4. Frequency

How often will each channel send?

| Channel | Frequency | Notes |
|---|---|---|
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |

A working starting point for most small businesses:

- Email newsletter: twice monthly
- Social media: 2–4 posts per week per platform
- SMS: only for time-sensitive moments (less than monthly on average)

You can adjust later based on what the metrics show. Better to start at sensible defaults than to over-optimise the calendar.

---

## 5. Metrics to track

Pick three metrics to watch monthly:

- [ ] Open rate (email / SMS)
- [ ] Click-through rate (email / social)
- [ ] Conversion rate (the action you actually want)
- [ ] Engagement metrics (likes, comments, replies)
- [ ] List growth (net new subscribers)
- [ ] Unsubscribe rate (the canary)

**Your three:**

1. _______________
2. _______________
3. _______________

**Where you'll log them (spreadsheet / dashboard / notes file):**

_______________________________________________

---

## 6. The owner

Who is responsible for actually delivering this plan?

| Channel / Touchpoint | Owner |
|---|---|
| _______________ | _______________ |
| _______________ | _______________ |
| _______________ | _______________ |
| _______________ | _______________ |

If the answer is "me" for everything, fine — but be honest about how much you can deliver consistently. A communication plan that nobody runs is worse than a smaller plan that runs reliably.

---

## Worked example

For a yoga studio with the loyal-customer profile from the worksheet:

**Channels:** Email (newsletter + lifecycle), Instagram (daily-ish stories, 3 posts/week), SMS (appointment reminders only)

**Touchpoints:**
- Pre-purchase: Instagram presence + studio Google Business Profile
- At-purchase: automated booking confirmation email
- Post-purchase: 24h follow-up text, 3-day check-in email
- Between: Bi-monthly newsletter, Instagram stories daily, 3 grid posts a week
- Reactivation: 60-day quiet trigger → personal email from owner

**Personalisation:** First name in every email, reference to most recent class type, segmentation between new students / regulars / pass-holders / lapsed.

**Frequency:**
- Email: 2x monthly newsletter + lifecycle triggers
- Instagram: 3 grid posts/week, daily-ish stories
- SMS: appointment reminders only

**Metrics:** Email open rate, Instagram engagement rate, lapsed-customer reactivation rate

**Owner:** Studio manager runs Instagram and emails; owner does reactivation outreach personally.

That's a one-page plan. It's executable. It can be reviewed monthly against actual metrics. It scales as the business grows.

---

## Review and adjust

Read this plan at the end of each month. Check:

- Are the touchpoints actually happening?
- What do the metrics say?
- Is the frequency right? (Look at unsubscribe rate.)
- Are the channels matching where the VIP profile actually engages?

Adjust at the quarterly review, not in the heat of the moment.
