# Feedback Question Bank

A working set of feedback questions — closed and open-ended — that you can adapt to your business. Plus a guide for picking the right gathering method for the question.

The principle: every feedback round should mix three or four closed questions (for the metrics) with two or three open-ended questions (for the insight). More than that and response rates plummet.

---

## Closed questions (rating, ranking, yes/no)

Pick three or four for any single feedback round. Mix the formats so the customer isn't doing the same thing every question.

### Overall experience

- *On a scale of 1 to 10, how would you rate your overall experience with us?*
- *How satisfied were you with [your specific service / product]? (Very satisfied / Somewhat satisfied / Neutral / Somewhat dissatisfied / Very dissatisfied)*
- *Did your experience meet your expectations? (Exceeded / Met / Below)*
- *Would you recommend us to a friend or colleague? (Yes / No / Maybe)*
- *On a scale of 0 to 10, how likely are you to recommend us to someone like you? (NPS question)*

### Specific touchpoints

- *How satisfied were you with our customer service? (1–5 scale)*
- *Was your order delivered in the time you expected? (Yes / No / Earlier than expected / Later than expected)*
- *How easy was it to find what you were looking for? (Very easy / Easy / Neutral / Difficult / Very difficult)*
- *Did our product or service solve the problem you came to us with? (Yes / Mostly / Partially / Not really)*

### Repeat intent

- *How likely are you to buy from us again in the next [3 months / 6 months / year]? (Very likely / Likely / Unsure / Unlikely / Very unlikely)*
- *What would make you more likely to come back? (Multiple-choice list — better prices, more product variety, faster service, etc.)*

### Comparative

- *How do we compare to other [your category] businesses you've used? (Significantly better / Slightly better / About the same / Slightly worse / Significantly worse)*
- *Where else do you go for [your category]? (Multiple-choice or open-ended)*

---

## Open-ended questions

The questions that produce the gold — direct customer language about the business. Pick two or three per round, no more.

### About the experience

- *What did you like best about [your product / service]?*
- *What's one thing you'd change about your experience with us?*
- *What were you hoping to get from working with us, and did you get it?*
- *Tell us about a moment that stood out — good or bad — during your experience.*

### About the relationship

- *What's the main reason you chose us over alternatives?*
- *What would have to be true for you to keep choosing us in the future?*
- *What do you tell your friends about us, if anything?*
- *Is there anything we should be doing that we're not?*

### About what they need next

- *What problem are you currently trying to solve in your [business / life] that we might be able to help with?*
- *What other products or services would you like to see us offer?*
- *Are there features or improvements you'd value enough to pay extra for?*

### About concerns or hesitations

- *What hesitations or doubts did you have before buying from us?*
- *What questions did you wish we'd answered better?*
- *Is there anything we say or do that doesn't quite ring true to you?*

---

## Question sets for specific situations

Pre-built groupings that work for common feedback rounds.

### Quarterly customer satisfaction check

(Three closed + two open. Sent to all customers who've bought in the last 90 days.)

1. On a scale of 0 to 10, how likely are you to recommend us to a friend? (NPS)
2. On a scale of 1 to 10, how would you rate your overall experience with us?
3. How likely are you to buy from us again in the next 6 months?
4. What's the main reason you chose us over alternatives? (open)
5. What's one thing you'd change about your experience with us? (open)

### Post-purchase follow-up

(Two closed + one open. Sent 7 days after first purchase.)

1. Did your purchase meet your expectations? (Exceeded / Met / Below)
2. How likely are you to buy from us again? (1–5 scale)
3. What would make you more likely to come back? (open)

### VIP deep dive

(One closed + four open. Sent personally to the VIP segment, once a year.)

1. On a scale of 0 to 10, how likely are you to recommend us? (NPS)
2. What do you value most about working with us? (open)
3. What's the one thing we're not doing that we should be? (open)
4. What other problems are you trying to solve that we might be able to help with? (open)
5. If we could do one thing brilliantly that we currently do adequately, what should it be? (open)

### Lapsed-customer reactivation

(Two closed + two open. Sent to customers who haven't bought in 90+ days.)

1. Did something specific cause you to stop buying from us? (Yes / No / Not sure)
2. How likely are you to buy from us again? (1–5 scale)
3. What would bring you back? (open)
4. Is there anything you'd want to tell us about your last experience? (open)

---

## Picking the right gathering method

| Method | Best for | Avoid for |
|---|---|---|
| **Email survey** | Structured rounds with multiple questions, defined segments, scheduled cadence | Time-sensitive feedback, customers who don't open emails |
| **Google Forms** | Simple surveys, getting started fast, sharing in social or messages | Sophisticated logic, large samples needing analysis |
| **Social media polls** | Quick read on what an active social audience thinks | Depth, demographic breakdown, anonymity |
| **Direct outreach (call / email / coffee)** | High-value customers, depth interviews, the VIP cohort | Scale beyond ~30 customers per round |
| **Focus groups** | Deep insight, exploring new directions, hearing customer language live | Cost, bias from louder voices, anonymity |
| **AI chatbots** | High-volume, low-friction collection at scale | Nuance, qualitative depth, sensitive topics |
| **Review monitoring** | Passive, ongoing intelligence; what customers say to others | Targeted feedback on specific topics |
| **Follow-up calls** | Catching early-stage experience issues; building VIP relationships | Scaling beyond your weekly capacity |

A working setup for most small businesses: email surveys for structured quarterly rounds, direct outreach for the VIP cohort once a year, review monitoring as the always-on signal.

---

## The follow-up message

After every feedback round, the user sends a thank-you and a "what we're going to do" message. This is what turns one-time feedback into ongoing engagement.

A working template:

> Hi [first name],
>
> Thank you for taking the time to fill in our [survey / call / email] last week. Reading through everyone's responses, [specific theme] came up most often — [paraphrase what people said in plain language].
>
> Here's what we're going to do about it: [specific change, with a rough timeframe].
>
> If you spot anything else worth flagging in the next few months, you can always reply directly to this email. We read every one.
>
> Thank you again — feedback like yours is how we get better.
>
> [signature]

Send this within two weeks of the feedback round closing. Three weeks later and customers have forgotten they gave feedback at all, which means the loyalty effect of the follow-up is lost.

---

## A note on what to do with the answers

Every feedback round produces three things:

1. **Numbers** — track CSAT, NPS, response rate over time to see trends
2. **Quotes** — paste the most striking open-ended responses into a single document. This becomes your marketing copy bank, your website testimonials source, your social proof library
3. **One thing to act on** — pick the single most important change suggested. Schedule it. Tell customers it's coming. Ship it. Tell them it's done.

A single concrete change per round, communicated back to customers, is what makes feedback compound. Five vague intentions to "look into things" make customers stop responding next time.
