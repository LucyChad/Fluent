# Loyal Customer Profile

A structured exercise to identify the customers who are actually loyal to the business — distinct from the merely repeat — and to extract the patterns that mark them out. The output is a one-page profile that sharpens every later marketing and loyalty decision.

Plan for an hour with this worksheet. Open against actual customer data — point of sale records, e-commerce dashboards, booking systems, or just your most recent fifty paying customers.

---

## Part 1: Identify your loyal customers

The trap most businesses fall into: confusing repeat with loyal. A repeat customer buys often. A loyal customer chooses you over alternatives, talks about you, and gives you feedback. The two overlap, but they're not the same.

### Step 1: Pull the repeat-customer list

List every customer who has bought from you more than three times in the last twelve months.

| Customer name | First purchase | Last purchase | Total purchases | Total spend |
|---|---|---|---|---|
| _____________ | _____________ | _____________ | _____________ | _____________ |
| _____________ | _____________ | _____________ | _____________ | _____________ |
| _____________ | _____________ | _____________ | _____________ | _____________ |

(Add as many rows as you need. Don't truncate.)

### Step 2: Mark engagement signals

For each repeat customer, tick which of the loyalty signals applies:

| Customer | Replies to emails | Engages on social | Leaves reviews | Refers others | Gives feedback | Forgives mistakes |
|---|---|---|---|---|---|---|
| _____________ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| _____________ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| _____________ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |

A loyal customer ticks at least three boxes. Two or fewer means they're a repeat customer rather than a loyal one.

### Step 3: Identify the VIP segment

Of the customers who ticked three or more boxes, pick the top 10–15% by spend or by engagement intensity. These are your VIPs — the engine of the loyalty programme.

**Your VIP list (10 to 30 names is normal for a small business):**

1. _____________
2. _____________
3. _____________
4. _____________
5. _____________
6. _____________
7. _____________
8. _____________
9. _____________
10. _____________

(Keep going if you have more.)

---

## Part 2: Build the loyal-customer profile

Look at the VIP list as a group. The patterns you see become the profile. The profile is what tells you who to target with future marketing — people who look like your VIPs are the most likely to become VIPs themselves.

### Demographics

What patterns do you see across age, location, occupation, household composition?

**Age range pattern:**

_______________________________________________

**Location pattern:**

_______________________________________________

**Occupation or income pattern:**

_______________________________________________

**Household / life-stage pattern:**

_______________________________________________

---

### Psychographics

What patterns do you see in what they value about your business, in their broader interests, in their pain points, in the language they use?

**What they value about your business:**

_______________________________________________

**Broader interests / lifestyle patterns:**

_______________________________________________

**Pain points they describe in feedback or reviews:**

_______________________________________________

**Words and phrases they use about your business (paste actual quotes):**

_______________________________________________

_______________________________________________

---

### Purchase behaviour

What patterns do you see in what they buy, when, and how?

**Average order value:**

_______________________________________________

**Purchase frequency (per month / per year):**

_______________________________________________

**Specific products or services they buy most:**

_______________________________________________

**Day-of-week or time-of-day pattern:**

_______________________________________________

**Channel they buy through (in-person / online / phone / app):**

_______________________________________________

---

### Engagement patterns

How do they interact with the business between purchases?

**Channel they prefer for communications:**

_______________________________________________

**How often they engage between purchases:**

_______________________________________________

**What kind of content they engage with:**

_______________________________________________

---

## Part 3: The summary

Combine your patterns into a one-paragraph profile of the ideal loyal customer for your business.

Use this template:

> *My most loyal customers tend to be [demographic pattern], living in [location pattern]. They value [what they value most] and dislike [what they avoid]. They tend to buy [purchase pattern] through [channel]. They engage with us via [communication channel] and respond to [content type].*

**Your profile:**

_______________________________________________

_______________________________________________

_______________________________________________

_______________________________________________

---

## Worked example

```
My most loyal customers tend to be working women aged 35–55, living
within a 15-minute drive of the studio. They value the personal
relationship and the calm atmosphere; they dislike feeling rushed or
upsold. They tend to buy 6–8 sessions a year, mostly midweek mornings,
through our online booking system. They engage with us via Instagram
stories and respond to short, warm emails — not promotional ones.
```

---

## What to do with the profile

**Three immediate uses.**

**Targets your marketing.** When you're deciding where to advertise, what content to make, what partnerships to pursue — test against the profile. Will this reach more people who look like my VIPs? If not, why am I doing it?

**Shapes your loyalty programme.** When you're designing offers, communications, and rewards — design for the profile. The kind of perks that would delight your VIPs are the right ones, even if generic loyalty advice would suggest something else.

**Surfaces who to invest in personally.** A small business can have actual personal relationships with 30 VIPs. Birthday cards. Hand-written thank-you notes. The occasional check-in. These don't scale — but at this scale, they're transformative.

---

## Update rhythm

Re-read the profile every six months. Ask:

- Are these still the patterns I see in my VIPs?
- Has the business shifted in a way that changes who my best customers are?
- Are there new patterns emerging that the profile doesn't capture?

Most updates are small. Occasionally you'll realise the business has shifted enough that the profile has too — that's a signal that the wider strategy may also need a look.
