# Offers Design Worksheet

A structured exercise to design two or three concrete loyalty offers — typically a welcome offer for first-time repeat customers, an ongoing reward for long-term loyal customers, and at least one surprise offer that creates an unprompted "wow" moment.

Plan for 45 minutes. Have your loyal-customer profile and your communication plan to hand. The offers should fit both — make sense for the customer profile, and run cleanly through the communication channels.

---

## The exclusivity test

Before you design any offer, the test that filters out the bad ones:

> *Could I run this exact offer to my whole list — including non-loyal customers — without it feeling weird?*

If yes, it's not a loyalty offer. It's a promotion. Loyalty offers have to be genuinely exclusive — given to specific customers because of who they are or what they've done.

---

## Offer 1 — Welcome / first-time-repeat offer

The offer that converts a one-time buyer into a regular. Designed to make the second purchase easier than it otherwise would have been.

**What the offer is:**

_______________________________________________

**Who gets it:**

_______________________________________________

(Typically: customers who've bought once or twice. Trigger: 7–30 days after first purchase.)

**How it's delivered:**

_______________________________________________

(Email / SMS / in-person / via the till system.)

**The exclusivity:**

_______________________________________________

(What makes this *not* available to non-loyal customers? Be specific.)

**Trigger / timing:**

_______________________________________________

**Cost to deliver (per customer):** _______________

**What you expect it to produce:**

_______________________________________________

(More second purchases? Higher second-purchase value? Faster conversion to regular?)

---

## Offer 2 — Ongoing loyalty reward

The offer that recognises and reinforces the long-term loyal customer. Designed to deepen the relationship, not just to drive an extra transaction.

**What the offer is:**

_______________________________________________

**Who gets it:**

_______________________________________________

(Typically: VIP segment, or customers past a defined threshold of spend, frequency, or tenure.)

**How it's delivered:**

_______________________________________________

**The exclusivity:**

_______________________________________________

**Cadence (how often it's offered):**

_______________________________________________

(Annual? Quarterly? Tied to specific milestones? Reset every year?)

**Cost to deliver (per customer):** _______________

**What you expect it to produce:**

_______________________________________________

(Higher CLV? Increased referral activity? Stronger advocacy?)

---

## Offer 3 — Surprise offer

The unprompted, unexpected, personalised gesture. The offer that breaks the transactional frame and creates the strongest loyalty effect of the three.

**What the surprise is:**

_______________________________________________

**Who you'll surprise:**

_______________________________________________

(Specific named VIPs, or a small segment chosen for a specific reason.)

**How it's delivered:**

_______________________________________________

**The personalisation hook:**

_______________________________________________

(Why this offer for this person, on this day? What makes it feel chosen rather than mass-distributed?)

**Cost to deliver (per customer):** _______________

**Frequency rule:**

_______________________________________________

(How often you'll do this kind of thing — without it becoming a predictable pattern.)

---

## How to launch all three

A working sequence for the next 30 days:

| Week | Action |
|---|---|
| 1 | Set up Offer 1 trigger system. Identify the eligible customers and prepare the delivery method. |
| 1 | Launch Offer 1 to current eligible cohort. |
| 2 | Identify the VIP cohort eligible for Offer 2. Send Offer 2 to first batch. |
| 3 | Pick five specific VIPs to surprise this week. Deliver Offer 3 personally. |
| 4 | Review redemption rates. Note what's working, what isn't. Adjust before the next cycle. |

---

## Tracking the offers

For each offer, track three metrics over the first 30 days:

| Offer | Issued | Redeemed | Redemption rate | Repeat purchase impact |
|---|---|---|---|---|
| Offer 1 — Welcome | _____ | _____ | _____ | _____ |
| Offer 2 — Loyalty | _____ | _____ | _____ | _____ |
| Offer 3 — Surprise | _____ | _____ | _____ | _____ |

The redemption rate tells you whether the offer was wanted. The repeat purchase impact tells you whether it actually deepened loyalty.

---

## Adjusting the offers

After 30 days, review:

- Which offer had the highest redemption rate?
- Which one moved repeat purchase rate the most?
- Which one was the most expensive per outcome?
- What did customers say about each?

Keep what's working. Replace what isn't. Don't add a new offer until one of the existing three has been retired or refined — three is the working maximum for most small businesses, four is too many to track properly.

---

## A few rules

**Test small first.** Run new offers with a dozen VIPs before scaling. Cheap to learn, expensive to undo.

**Document who gets what.** A simple log of "this customer received this offer on this date" prevents the chaos of one customer getting the same offer twice or different offers on conflicting timelines.

**Don't apologise with offers.** When something has gone wrong, the right response is a sincere fix, not a discount. Discounting after a problem trains customers to associate the relationship with the failure.

**Stop offers that aren't working.** If an offer's redemption rate is consistently below 10%, replace it. Loyalty is built on offers customers actually want, not on offers the business thought were nice.
