# Asking for Feedback

## Why this step does double work

Asking for feedback is two things at once. Surface level, it's information-gathering — the business learns what's working, what's not, and what customers want next. Deeper level, it's a loyalty move in itself. The act of asking demonstrates that the customer's opinion matters. The act of acting on the feedback demonstrates that they were right to give it.

Done well, feedback compounds. Each round produces both useful insights and stronger loyalty than existed before. Done badly — surveys nobody fills in, feedback that disappears into a void, the same questions asked over and over without changes following — it actually erodes loyalty. Customers feel ignored.

The work in this step is designing feedback that does both jobs.

## Closed versus open-ended questions

The two basic question types serve different purposes.

**Closed questions** ask for a specific, structured answer — yes/no, a rating, a multiple-choice. Examples:

- *How would you rate your overall experience? (1–10)*
- *How satisfied were you with our customer service? (Very satisfied / Somewhat satisfied / Neutral / Somewhat dissatisfied / Very dissatisfied)*
- *Would you recommend us to a friend? (Yes / No / Maybe)*
- *Did the product meet your expectations? (Yes / No)*

Closed questions are easy for customers to answer (they take seconds), and they produce data that's easy to compare across customers and across time. They tell the user *what's true* but not *why*.

**Open-ended questions** invite the customer to explain, in their own words. Examples:

- *What did you like best about our [product / service]?*
- *What could we do better next time?*
- *What other products or services would you like to see us offer?*
- *What were the main factors that influenced your decision to buy from us?*
- *What questions did you have when you were considering your purchase?*
- *What do you value most about our brand?*

Open-ended questions take longer to answer, get fewer responses, and produce text rather than numbers. But the responses are gold — direct quotes from the customer, in their language, about what they actually think. Marketing material, product roadmap, and positioning all benefit from this language.

The discipline: a good feedback exercise uses both. Closed questions produce the metrics; open-ended questions produce the insight. Three or four closed plus two or three open is a sensible default.

## The methods worth knowing

Eight ways to gather feedback. Each suits different situations.

**Email surveys.** Sent through tools like Mailchimp or SurveyMonkey. Best for: structured surveys with multiple questions, sent to defined segments, collected over a window. Falls down for: instant feedback, customers who don't open emails.

**Google Forms.** Free, easy, embeddable. Best for: simple surveys, collecting feedback from a wide audience, getting started without much setup. Falls down for: more sophisticated logic, larger samples needing analysis.

**Social media polls.** Built-in features on most platforms. Best for: quick read on what an active social audience thinks. Falls down for: depth, demographic breakdown, anonymity.

**Direct outreach.** A phone call, a personal email, a coffee. Best for: high-value customers, the VIP segment, depth interviews where the user wants to understand reasoning, not just opinion. Falls down for: scale.

**Focus groups.** Small gatherings (in person or online) where 5–10 customers discuss the business and its products. Best for: deep insight, exploring new directions, understanding the language customers use. Falls down for: cost (your time and theirs), bias (the loudest voice can dominate).

**AI chatbots.** Conversational feedback collection embedded in apps, websites, social media. Best for: high-volume, low-friction collection. Falls down for: nuance, qualitative depth.

**Review monitoring.** Watching what customers post on Google, Facebook, Yelp, industry sites. Best for: passive, ongoing intelligence; understanding what customers tell *others* (which is often more honest than what they tell the business directly).

**Follow-up calls or emails.** Short, personal, soon after purchase. Best for: catching early-stage customer experience issues; building the personal relationship that produces loyalty.

The selection rule: a working feedback system uses two or three methods, not all eight. Most small businesses get a long way with email surveys for structured feedback, plus direct outreach to VIPs for depth, plus review monitoring for the unprompted signal.

## The metrics that matter

Three feedback metrics worth tracking.

**Survey response rate.** The percentage of customers asked who responded. A response rate of 15–25% is normal; over 30% is strong. Below 10% means either the audience is wrong, the survey is too long, or the ask is unclear.

**Customer Satisfaction Score (CSAT).** A simple rating (1–10 or 1–5) of how satisfied customers are. Track over time. A static score isn't telling you much; the trend is. A score that's slowly rising is a working business; a score that's flat or declining needs attention.

**Net Promoter Score (NPS).** *"How likely are you to recommend us to a friend?"* on a 0–10 scale. The score is calculated as (% who scored 9–10) minus (% who scored 0–6). NPS is famously imperfect as a single metric — but as a longitudinal signal of how customers feel about the business, it's useful.

The discipline: track CSAT and NPS quarterly, not weekly. Loyalty signals are slow-moving. A monthly bounce in NPS is noise; a sustained move over two quarters is real.

## Following up on feedback

The single move that distinguishes feedback that builds loyalty from feedback that erodes it.

After a customer gives feedback, the user does three things, in this order:

1. **Thanks them, specifically.** "Thank you for the feedback on [specific thing]" — not a generic auto-reply.
2. **Tells them what they're going to do with it.** Either: "We're going to look into [specific change]" or "We're going to keep doing [specific thing] because of feedback like yours". Even if the answer is "we don't think we'll change this, but we hear you", that's a real response — it shows the user read it.
3. **Closes the loop later.** When something does change as a result of feedback, the user lets the people who gave the feedback know. *"You'll remember you told us X — we've done Y about it. Wanted to say thank you."*

Most businesses skip step 3. It's the move that turns one-time feedback into a long-term feedback culture. Customers who see their input reflected back will give feedback again. Customers who don't, won't.

A small "thank you" gift after substantive feedback — a discount, a freebie, a hand-written note — is icing. Optional but powerful.

## Acting on what you hear

The mistake almost every business makes: collecting feedback and not acting on it. Two tactics that prevent this.

**Pick one thing to act on per round.** Don't try to address every piece of feedback every quarter. Pick the one thing that came up most consistently and commit to fixing it. Tell customers that's what you're doing.

**Schedule the analysis.** A reading-and-synthesis session, on a calendar, after each feedback round. Without it, the responses pile up unread. With it, the round produces a one-page summary of what was said and what's going to be done about it.

The summary lives somewhere visible. Future feedback rounds reference it: "Last quarter you told us X. We did Y. This quarter we'd like to know about Z."

## What this step produces

By the end of this work the user has:

1. A short bank of closed and open-ended questions tailored to their business
2. Two or three feedback gathering methods set up and running on a regular cadence
3. CSAT and NPS being tracked quarterly
4. A follow-up habit that closes the loop with customers who give feedback
5. One concrete change being made per feedback round, communicated back to the customers who suggested it

That's the feedback engine. With it, the business stops guessing what customers want and starts knowing — and the act of asking becomes one of the most powerful loyalty levers available.
