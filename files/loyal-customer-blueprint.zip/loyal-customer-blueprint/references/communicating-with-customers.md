# Communicating with Customers

## What this step is for

Loyalty is built between purchases, not just at the point of sale. Customers who never hear from a business after they've bought drift, forget, and eventually churn. Customers who hear from a business too often, or in the wrong way, unsubscribe just as fast.

The work in this step is designing a communication system that lives in the middle: regular enough to stay top of mind, valuable enough that customers welcome it, personalised enough that it doesn't feel like marketing-by-numbers.

There are five components: channels, touchpoints, personalisation, frequency, and metrics. Each one solves a specific problem.

## The five core channels

Each channel does some things well and some things badly. The right system uses two or three, not all five.

**Email.** Direct, detailed, asynchronous. Excellent for newsletters, offers with substance, longer-form content, transactional follow-ups. Falls down in cluttered inboxes — open rates of 20–35% are normal, meaning two-thirds of emails go unread on any given send.

**Social media.** Real-time, conversational, public. Excellent for ongoing brand presence, community building, behind-the-scenes content, engaging with customers in a way they can see. Falls down on reach — organic reach on most platforms is now a fraction of follower count, so it's a slow-burn relationship channel rather than a broadcast one.

**SMS / text.** Fast, personal, almost always read. Excellent for time-sensitive things — appointment reminders, flash offers, urgent updates. Falls down for length (limited characters), for cost (per-message pricing on most platforms), and for the higher friction of getting customers to opt in.

**WhatsApp (and similar messengers).** All the immediacy of SMS plus richer content (images, video, documents). Excellent for ongoing conversations with high-value customers and for international reach. Falls down on platform dependency and on the more personal feel — it can become intrusive faster than email.

**Video calls.** The most personal channel. Excellent for high-value services (coaching, consulting), workshops, focus groups, premium tier customer support. Falls down on scale — it doesn't.

The selection rule: pick the smallest number of channels that cover the user's customer base. Most local businesses do well with email + one social channel + occasional SMS for time-sensitive moments. Adding more channels rarely improves loyalty; it usually dilutes the user's attention across all of them.

## Customer touchpoints

A touchpoint is any moment of interaction between the business and the customer — purchase, follow-up email, social comment, review response, in-person visit, casual run-in. Loyal customers accumulate dozens of touchpoints over a year. Disengaged ones accumulate two or three.

Mapping the touchpoints is what turns "we should email them more" into a specific plan.

A working touchpoint map covers:

- **Pre-purchase.** Discovery, research, first contact, consideration moments.
- **At-purchase.** Welcome, thank-you, confirmation, order details, expectation-setting.
- **Post-purchase.** Delivery or service experience, follow-up, satisfaction check-in, request for feedback or review.
- **Between purchases.** Newsletters, social interactions, useful content, offers, surprise touches.
- **Reactivation.** When a customer has gone quiet, the touch that brings them back.

The user's job is to identify the specific touchpoint for each stage that they'll actually deliver, and to build the lightest possible system to make those touchpoints happen reliably.

## Personalisation that earns its keep

Personalised communications outperform generic ones — but only if the personalisation is real. "Hi [First Name], we have something special just for you!" followed by a generic mass offer is worse than no personalisation. Customers see through it.

Real personalisation:

- **Name and known context.** First name plus a reference to something specific about their relationship with the business — last purchase, length of time as a customer, a known preference.
- **Behaviour-based segmentation.** Sending different messages to first-time customers, regulars, and lapsed customers. Each segment hears something relevant to their stage.
- **Purchase-history-driven offers.** Recommending products that genuinely complement what they've bought, rather than generic bestsellers.
- **Lifecycle-driven moments.** Birthday, anniversary of first purchase, milestone of total spend or visits.
- **Preference-based channels.** If a customer engages on social but ignores email, lean into social.

The discipline: every personalisation move has to be possible to execute. There's no point designing a beautiful "we noticed you haven't been in for three months" email if the user has no way to identify who that's true of.

## Frequency: the most-debated question

There's no universal right answer, but there are sensible patterns by channel:

- **Email newsletter:** twice monthly is a strong default for most small businesses. Weekly works for some (highly engaged audience, content-rich brand). Monthly is the floor — less than that and customers forget.
- **Email transactional / behavioural:** as often as the behaviour warrants. A customer who just bought should hear from the business within a day. A customer at the 90-day mark might warrant a check-in.
- **Social media:** 2–5 posts per week per platform is a working range. Daily is overkill for most small businesses; less than weekly is invisible.
- **SMS:** sparingly. Once or twice a month for non-transactional messages, plus appointment reminders or time-sensitive moments. SMS over-use kills opt-ins.
- **WhatsApp:** depends on the relationship. For closed groups with engaged customers, several times a week is fine. For broadcast-style use, treat it like SMS — sparingly.

The deeper rule: better to communicate slightly less often with high-quality, valuable messages than to communicate more often with filler. The unsubscribe rate tells you when you've crossed the line.

## The metrics that tell you it's working

Six metrics worth tracking, depending on the channels in use:

- **Open rate** — for email and SMS. The first signal of relevance.
- **Click-through rate** — for emails and posts with links. The signal of motivation.
- **Conversion rate** — the share of recipients who took the desired action (bought, booked, signed up).
- **Engagement metrics** — likes, shares, comments, replies. The signal of relationship strength.
- **List growth** — net new subscribers over time. The signal of overall channel health.
- **Unsubscribe rate** — the canary. A spike in unsubscribes after a particular send is a sharp signal that something's off — frequency, content, or audience match.

The discipline: pick three of these to actually track, not all six. Most small businesses watch open rate, click-through rate, and unsubscribe rate as a baseline. Add engagement metrics if social is a major channel.

## What this step produces

By the end of this work the user has:

1. Two or three core channels identified and configured for active use
2. A touchpoint map covering pre-purchase, at-purchase, post-purchase, between purchases, and reactivation
3. A clear plan for personalisation that the business can actually execute
4. A working frequency cadence for each channel
5. Three metrics being tracked monthly to know whether the system is working

This is the communication scaffold. Once it's running, the offers, feedback, and monitoring layers in the next steps slot into it cleanly — and the user stops having to reinvent how to talk to customers each week.
