# Offering Something Special

## Why exclusivity is the engine

Loyalty offers fail when they look like the same offer everyone gets, dressed up. A 10% discount available to "loyal customers" is meaningless if the business runs 10% off promotions to its email list every other month. The customer can't tell the difference, and so the offer doesn't feel like a reward — it feels like another sale.

What makes a loyalty offer work is exclusivity. Something the customer gets *because* of their relationship with the business that other customers don't get. The exclusivity can be small (a free upgrade, an early-access window) or large (a private sale, a significant discount), but it has to be real.

Without exclusivity, "loyalty programme" is just "discount system, slightly differently named". With exclusivity, it's a genuine reason for customers to stick around.

## The toolkit of loyalty offers

The categories worth knowing:

**Free gifts.** Small physical or digital extras given to customers at relevant moments. A free sample with a repeat purchase, a free download with a milestone, a thank-you item at year one as a customer.

**Discounts on relevant products.** Targeted discounts on items the customer has shown interest in, or on complements to their purchase history. Generic across-the-board discounts dilute the loyalty signal; targeted ones reinforce it.

**Exclusive products.** Products only available to loyal customers — a bottle reserved for VIPs, a pre-launch version of a new offering, a member-only colour or variant. Restricting access creates value.

**Free access to membership or premium content.** A complimentary month of a subscription, a free download of a paid resource, access to a private community. Useful when the business has digital assets that scale cheaply.

**Cross-business offers.** Partner perks — a discount at a complementary local business, a partner-supplied gift, an event hosted with a partner. Adds value without costing the user directly.

**Points systems.** Earn-redeem mechanics — buy ten coffees, get one free; spend £200, get a £20 voucher. Simple to understand, easy to manage, but only effective if the rewards are achievable in a reasonable timeframe.

**Tier-based programmes.** Status levels — silver, gold, platinum — with progressively better perks. Suits businesses with higher transaction values where customers can plausibly climb tiers. Overkill for most small businesses.

**Event access.** Invitations to private events — workshops, tastings, previews, networking nights. Costs little, feels significant.

The selection rule: choose two or three from this list, not eight. A loyalty programme with too many moving parts becomes hard to administer and hard for customers to remember.

## Tiered offers: first-time repeat versus long-term loyal

Different customers are at different stages of the loyalty journey, and the same offer doesn't suit both.

**For first-time repeat customers** (they've bought once or twice — the goal is to make them regulars):

- Welcome discounts on a second purchase
- Free shipping on a follow-up order
- Introductory access to a complementary product or service
- Referral discounts (bring a friend, both get something)
- Free upgrade or sample with the next purchase

The pattern: lower the friction of becoming a regular. Make the second and third purchases easier, faster, and slightly more rewarding than they otherwise would have been.

**For long-term loyal customers** (regulars who've been with the business for months or years):

- Tier-based programmes with status that grows over time
- Exclusive access to new products before launch
- Special discounts framed as appreciation, not promotion
- Anniversary rewards (one year, three years, five years of being a customer)
- Free products or services after a milestone (buy ten, get one free)
- Customer-only events

The pattern: deepen the relationship. The long-term loyal customer doesn't need an incentive to come back — they're already coming back. They need a reason to feel that the business sees and values them, beyond the transaction.

A loyalty programme without this distinction either over-rewards new customers (eroding margin without building lifetime loyalty) or under-rewards long-term customers (taking them for granted, which is the silent killer of loyalty).

## The power of surprise offers

The category of offer most under-used by small businesses, and the highest-impact for the relative cost.

A surprise offer is unprompted, unexpected, and personalised. It's the reverse of an opt-in or a points-based redemption. The customer didn't know it was coming; suddenly the business does something nice.

Examples that work:

- An unexpected discount on the next purchase, sent the day after a lovely customer interaction
- A free upgrade applied without being asked ("we noticed you've been with us a year — your next service is on us")
- A free gift based on the customer's known preferences ("we got these in and thought of you")
- A birthday note with a small treat
- Random acts of kindness — unannounced free shipping, an invitation to a soft-launch event, a hand-written thank-you note

Why surprise offers work disproportionately well: they break the transactional frame. Most loyalty offers are transactions ("spend X, get Y"). Surprise offers are *gifts*. Gifts create gratitude, and gratitude is the strongest form of loyalty available.

The discipline: surprise offers should be genuinely surprising. If they happen on a schedule the customer can anticipate, they stop working. The user shouldn't surprise *every* customer every quarter. They should pick moments based on the customer's actual relationship with the business.

## The metrics that tell you it's working

Three metrics worth tracking on loyalty offers specifically:

**Redemption rate.** The percentage of offers issued that customers actually use. A high redemption rate (over 30% for most categories) means the offer is appealing and accessible. A low one (under 10%) means either the offer is wrong or the friction to redeem is too high.

**Repeat purchase rate.** Among customers who received the offer, did their purchase frequency change? This is the actual loyalty test — not whether they used the offer, but whether the relationship deepened.

**Conversion rate.** Among customers who received the offer, what proportion went on to take the desired next action (a purchase, a referral, a sign-up)?

The discipline: track these three over a quarter, not a week. Loyalty effects compound slowly. A single offer might not move any of the metrics; a year of consistent loyalty offers should move all three.

## A few rules

**Test before scaling.** Run a new offer with a small segment first — a dozen VIPs, or a single tier of customers — before rolling it out broadly. Cheap to learn, expensive to undo.

**Document what you offer to whom.** When loyalty programmes have multiple moving parts and the user can't remember what they offered to whom, the system breaks down. A simple spreadsheet listing every offer issued, to whom, when, and what the response was, is enough.

**Don't apologise with offers.** When something has gone wrong, the right response is a sincere fix, not a discount. Discounting after a problem trains customers to associate the relationship with the failure rather than the solution.

**Stop offers that aren't working.** If an offer's redemption rate is consistently low, replace it. Loyalty is built on offers customers actually want, not offers the business thought were nice.

## What this step produces

By the end of this work the user has:

1. Two or three concrete loyalty offers designed and ready to launch
2. A clear segmentation between offers for first-time repeat customers and long-term loyal customers
3. At least one surprise offer planned for the next quarter
4. A simple tracking system for redemption, repeat purchase, and conversion

That's the offer engine. With identification, communication, and offers in place, the user has the front three-fifths of the loyalty system. Feedback and monitoring complete it.
