# How To Create Content That Pulls People In

*Installation guide*

This skill works by giving your AI assistant deep knowledge about content marketing for small businesses — the 5 Secrets of magnetic content, content goal-setting across awareness/engagement/conversion, building an idea bank from real audience signals, repurposing your back catalogue, and running a 90-day content calendar that produces measurable results. Once it's set up, you can ask it for help on any content decision and it'll bring the whole framework to bear.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Magnetic Content" or "Content Strategy"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/the-five-secrets-of-magnetic-content.md`
- `references/setting-content-goals.md`
- `references/the-magnetic-idea-bank.md`
- `references/repurposing-and-distribution.md`
- `references/the-90-day-calendar-system.md`
- `assets/content-goals-worksheet.md`
- `assets/magnetic-idea-bank.md`
- `assets/repurposing-audit.md`
- `assets/90-day-content-calendar.md`

**Step 3: Add your business and content context**

In the **Project instructions** field, paste and complete the following:

```
My business: [What you do, who you serve. Specific.]
What I create content about: [The two or three primary topic areas]
Where I publish: [The channels you actively use]
My current content cadence: [How often you publish, in practice]
My biggest content challenge: [Volume? Resonance? Distribution? Measurement? Consistency?]
My audience size and warmth: [Rough numbers and engagement quality]
My 90-day content goals (if you have them): [Paste from the goals worksheet, or leave blank]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a content strategist who knows your business.

A good first message: *"Walk me through setting my 90-day content goals — let's do this now."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A content strategist for small business owners. Knows the 5 Secrets of magnetic content, content goal-setting, idea bank ideation, repurposing, and 90-day calendar planning. Helps me build a system, not just produce more content."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all five files in `references/`, and all four in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical content strategist for small business owners. Use the uploaded knowledge files to guide every response. Always work from my actual business and content situation. Apply the 5 Secrets framework — resonance, repurposing, distribution, measurement, consistency. Have opinions and share them.

My context:
- My business: [fill in]
- Topic areas: [fill in]
- Where I publish: [fill in]
- Current cadence: [fill in]
- Biggest challenge: [fill in]
- Audience size and warmth: [fill in]
- 90-day goals: [paste them, or leave blank]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Magnetic Content*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- My business: [fill in]
- Topic areas: [fill in]
- Where I publish: [fill in]
- Current cadence: [fill in]
- Biggest challenge: [fill in]
- Audience size and warmth: [fill in]
- 90-day goals: [paste them]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your content

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**Your specific business and what you produce content about.** Not just the industry — the topic areas and the kind of audience. "B2B leadership coach for first-time managers in tech, content focuses on team dynamics, performance feedback, and 1:1 effectiveness" beats "coach".

**Your current cadence and channels.** Where you publish, how often. The skill needs to know what's already running so it doesn't suggest things you've already tried.

**Your biggest current content challenge.** The thing you're stuck on. Naming it specifically focuses the first few conversations.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Run the content goals worksheet with me — let's set the three 90-day goals."*
- *"Generate 20 ideas for my magnetic content idea bank using the 8 prompts."*
- *"Audit my back catalogue with me — I'll list what I have, you help me pick the top 5 to repurpose."*
- *"Help me build next month's content calendar — pull from the idea bank, slot in repurposed pieces."*
- *"Diagnose: I publish weekly, decent reach, but no conversions. What's going wrong?"*
- *"How should I repurpose this 2,000-word blog post into 4 different formats?"*
- *"Walk me through the end-of-month review."*

---

*Magnetic Content is part of the Fluent skill library. More skills at fluent.md.*
