# 90-Day Content Calendar

The working planner for the next 90 days. Quarterly view, three monthly views, weekly tactical detail, and daily plans. Use this as a structure; copy it into a spreadsheet or planning tool of your choice.

---

## Quarterly view (one page)

Fill this in once at the start of the 90 days. Refer to it before every monthly plan.

### The quarter's shape

**Quarter:** _______________ (e.g., "Q3 2026" or "Apr–Jun")

**Three primary topic areas this quarter:**

1. _______________
2. _______________
3. _______________

**The arc / theme:**

_______________________________________________

(What's the through-line that connects this quarter's content?)

---

### The 90-day goals

Pulled from the goals worksheet. Three goals, one per category.

**Awareness goal:**

_______________________________________________

**Engagement goal:**

_______________________________________________

**Conversion goal:**

_______________________________________________

---

### The mix

**New content : repurposed content ratio:** _____ / _____ %

**Goal weighting:**

- Awareness: _____ %
- Engagement: _____ %
- Conversion: _____ %

**Format mix (rough proportion of the quarter):**

- Blog posts: _____ %
- Video: _____ %
- Social posts: _____ %
- Email: _____ %
- Podcast: _____ %
- Other: _____ %

---

### Major events in this quarter

(Launches, sales, seasonal moments, conferences — anything the calendar should support.)

| Event | Date | Content implications |
|---|---|---|
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |

---

## Monthly view (one page per month)

Fill in at the start of each month, with reference to the quarterly view.

---

### Month 1: _______________

**Theme / focus this month:**

_______________________________________________

**Specific campaign or push (if any):**

_______________________________________________

**Distribution plan beyond native posting:**

- Email list: _______________
- Cross-posting channels: _______________
- Partnership opportunities: _______________
- Paid amplification: _______________

**Content slotted in this month (from the idea bank + repurposing audit):**

| # | Title | Format | Goal | New / Repurposed |
|---|---|---|---|---|
| 1 | _______________ | _______________ | A / E / C | N / R |
| 2 | _______________ | _______________ | A / E / C | N / R |
| 3 | _______________ | _______________ | A / E / C | N / R |
| 4 | _______________ | _______________ | A / E / C | N / R |
| 5 | _______________ | _______________ | A / E / C | N / R |
| 6 | _______________ | _______________ | A / E / C | N / R |
| 7 | _______________ | _______________ | A / E / C | N / R |
| 8 | _______________ | _______________ | A / E / C | N / R |

(Add rows for as many as the cadence requires — typically 8–20 per month.)

---

### Month 2: _______________

(Same structure as Month 1.)

---

### Month 3: _______________

(Same structure as Month 1.)

---

## Weekly view (one row per week within each month)

Fill in week by week — no point planning weeks 5–13 in detail at the start of the quarter; they'll change.

| Week of | Mon | Tue | Wed | Thu | Fri | Channel | Goal | Status |
|---|---|---|---|---|---|---|---|---|
| Week 1 | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |
| Week 2 | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |

---

## Daily detail (one block per piece of content)

Fill in for the next 7–14 days at any time. Detail beyond two weeks isn't worth it — too much will change.

### [Date / Day] — [Working title]

**Format:** _______________ (blog / video / podcast / social / email / etc.)

**Goal:** _______________ (Awareness / Engagement / Conversion)

**Who's creating:** _______________

**Where it's publishing:** _______________ (primary channel)

**Cross-posting:** _______________ (other channels with adapted version)

**Brief / outline:**

_______________________________________________

_______________________________________________

_______________________________________________

**Production block scheduled for:** _______________ (when you'll actually make it)

**CTA or next step (if applicable):** _______________

**Status:** Planned / In progress / Scheduled / Published

---

## Weekly results tracker

Fill in at the end of each week. 15 minutes max.

| Week | Pieces published | Awareness metric this week | Engagement metric this week | Conversion metric this week | Top performer | Notes |
|---|---|---|---|---|---|---|
| 1 | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |
| 2 | _______________ | _______________ | _______________ | _______________ | _______________ | _______________ |

---

## End-of-month review

Fill in at the end of each month. 60–90 minutes.

### Progress towards goals

| Goal | Target (90-day) | Where I am at end of month __ | On track? |
|---|---|---|---|
| Awareness | _______________ | _______________ | Yes / No |
| Engagement | _______________ | _______________ | Yes / No |
| Conversion | _______________ | _______________ | Yes / No |

### Best performing pieces this month

1. _______________ — why it worked: _______________
2. _______________ — why it worked: _______________
3. _______________ — why it worked: _______________

### Underperformers

1. _______________ — diagnosis: _______________
2. _______________ — diagnosis: _______________

### Ideas for next month

(Pull A-ranked ideas from the bank. Add new ideas surfaced this month from audience signals.)

1. _______________
2. _______________
3. _______________

### What I'll change for next month

_______________________________________________

_______________________________________________

---

## End-of-90-days review

Fill in at the end of the quarter. Half a day. The single most valuable session in the 90 days.

### The headline numbers

| Goal | Target | Final | % achieved |
|---|---|---|---|
| Awareness | _______________ | _______________ | _____ % |
| Engagement | _______________ | _______________ | _____ % |
| Conversion | _______________ | _______________ | _____ % |

### What worked

The patterns, formats, topics, and timings that consistently produced results. Be specific.

_______________________________________________

_______________________________________________

### What didn't work

The things that fell flat, regardless of effort.

_______________________________________________

_______________________________________________

### What surprised you

The signal you didn't see coming. New audience requests. Unexpected topics that performed. Channels that worked or didn't.

_______________________________________________

_______________________________________________

### The next 90-day shape

What's the focus next quarter? What's the goal weighting? What's repeating, what's stopping, what's new?

_______________________________________________

_______________________________________________

---

## How to use this template

**Once at quarter start (60 minutes):** fill in the quarterly view. Set the goals. Pick the topic areas.

**Once per month (80 minutes):** fill in the monthly view. Pull from the idea bank. Pull from the repurposing audit. Schedule production blocks.

**Once per week (45 minutes):** plan the next week's daily detail. Confirm production blocks. Set up scheduling.

**Daily (5 minutes):** glance at today's slot. Confirm or adjust.

**Once per week (15 minutes):** weekly results tracker.

**Once per month (60–90 minutes):** end-of-month review.

**Once per quarter (half a day):** end-of-90-days review.

That's the rhythm. The total time investment is roughly 4–5 hours per month for planning and review, on top of the time spent producing the content itself. Without the planning, content production is chaos and twice as slow.
