# Content Goals Worksheet

A 45-minute exercise to set three specific, measurable content goals for the next 90 days — one each for awareness, engagement, and conversion. Without these, every later content decision is guesswork.

---

## Step 1: Diagnose the current state

Three questions. Honest answers.

### Are you publishing consistently?

- [ ] Yes — weekly or more often, for at least the last quarter
- [ ] Inconsistently — bursts and gaps
- [ ] Almost never, or only when you remember

### Are people seeing the content?

- [ ] Yes, decent reach and growing audience
- [ ] Some reach, but it's flat or declining
- [ ] Almost no reach

### Is the content producing measurable business results?

- [ ] Yes — content is generating sign-ups, leads, or sales
- [ ] Some signal but unclear attribution
- [ ] No measurable results

The diagnosis tells you which goal type to weight most heavily.

---

## Step 2: Pick metrics for each goal type

Tick the metrics you'll actually track this quarter. Three to four total — not all of them.

### Awareness metrics

- [ ] New email subscribers
- [ ] New social followers
- [ ] Monthly unique website visitors
- [ ] Profile views on [main social platform]
- [ ] Brand mentions
- [ ] Other: _______________

### Engagement metrics

- [ ] Comments / replies per post
- [ ] Shares / saves
- [ ] Time-on-page or read-through rate
- [ ] Email reply rate
- [ ] DM volume
- [ ] Return visitors
- [ ] Other: _______________

### Conversion metrics

- [ ] Email sign-ups attributed to content
- [ ] Sales revenue attributed to content
- [ ] Click-through rate on CTAs
- [ ] Booking / consultation requests
- [ ] Lead form submissions
- [ ] Other: _______________

**Your three or four chosen metrics:**

1. _______________
2. _______________
3. _______________
4. _______________

---

## Step 3: Capture the baseline

For each chosen metric, the current number — today, before the 90 days start.

| Metric | Today's baseline |
|---|---|
| _______________ | _______________ |
| _______________ | _______________ |
| _______________ | _______________ |
| _______________ | _______________ |

If the baseline is unknown, capture an honest estimate and a note to set up tracking by week 2.

---

## Step 4: Set the 90-day goal in each category

Specific, measurable, time-bound, attached to one of the three jobs.

### Awareness goal

Template: *Add [number] new [audience members — email subscribers, followers, monthly readers] in the next 90 days from awareness-focused content.*

**Your awareness goal:**

_______________________________________________

**Specific number:** _______________

**Primary metric to track:** _______________

---

### Engagement goal

Template: *Lift [specific engagement metric] on [specific channel] from [current baseline] to [target] over the next 90 days.*

**Your engagement goal:**

_______________________________________________

**Specific number:** _______________

**Primary metric to track:** _______________

---

### Conversion goal

Template: *Produce [number] of [specific conversion outcome — sign-ups, leads, purchases, revenue] attributed to content over the next 90 days.*

**Your conversion goal:**

_______________________________________________

**Specific number:** _______________

**Primary metric to track:** _______________

---

## Step 5: Decide the goal weighting

How will the calendar split between the three goal types?

A new business with a small audience might weight 60% awareness / 30% engagement / 10% conversion.

An established business with a warm audience might weight 20% awareness / 40% engagement / 40% conversion.

A business with a launch coming might weight 30% awareness / 30% engagement / 40% conversion in the launch quarter.

**Your weighting:**

- Awareness: _____ %
- Engagement: _____ %
- Conversion: _____ %

(Should add up to 100.)

This weighting tells you what proportion of the calendar should be each type. It also tells the idea bank exercise which prompts to lean into.

---

## Step 6: Note your strengths, weaknesses, and challenges

A page of honest reflection before starting.

**Strengths in your current content:**

_______________________________________________

_______________________________________________

**Weaknesses or gaps:**

_______________________________________________

_______________________________________________

**Challenges that might get in the way of these goals (time, resources, skills, market):**

_______________________________________________

_______________________________________________

**How you'll handle the biggest challenge:**

_______________________________________________

---

## Worked example

For a B2B leadership coach who's been publishing inconsistently for a year:

**Diagnosis:** Inconsistent publishing. Some reach but flat. Some signal but unclear attribution.

**Metrics chosen:** New LinkedIn followers (awareness); comments per post (engagement); discovery calls booked (conversion); lead form submissions on the website (conversion).

**Baselines:** 1,200 LinkedIn followers; 3 comments per post on average; 2 discovery calls per month; 5 lead forms per month.

**Awareness goal:** Add 600 new LinkedIn followers in the next 90 days from thought-leadership posts.

**Engagement goal:** Lift average comments per LinkedIn post from 3 to 8 over the next 90 days.

**Conversion goal:** Generate 18 discovery calls (over 90 days) attributed to content via UTM links and "where did you hear" tracking on booking forms.

**Weighting:** 40% awareness, 30% engagement, 30% conversion.

**Strengths:** Strong perspective on first-time-manager challenges; existing customer testimonials; growing LinkedIn presence.

**Weaknesses:** Inconsistent publishing; weak attribution; underused email list.

**Challenges:** Limited time (5 hours/week for content); discomfort with video.

**Plan for the biggest challenge:** Block Monday mornings for content. Defer video until month 2 of the cycle.

That's a goals sheet. It fits on one page. The next 90 days run against it.

---

## Use it weekly

The goals sheet sits next to the calendar. Every week, the user looks at the metrics and asks: *am I on track for each goal?*

If yes — keep going.

If no — what's the gap? Is the content wrong, the distribution wrong, or the goal wrong?

By month 2 the goals are usually still right but the path needs adjusting. By month 3 the trajectory is clear. By day 90, the user knows which goals were realistic, which were aspirational, and where to set the next quarter's targets.
