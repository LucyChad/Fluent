# Magnetic Idea Bank

A structured ideation exercise to fill the user's content idea bank with 30–40 ranked, goal-tagged ideas in a single 90-minute session. Run it now and the next month's calendar fills itself.

---

## Before you start

Block 90 minutes. No interruptions. Get a notebook or open a doc.

Have to hand:

- Your content goals worksheet (so you know the goal weighting)
- The last week's customer questions, DMs, or sales conversations (real audience signal)
- Your last few months of content performance data (what's already worked)

---

## Part 1: Ideation (60 minutes)

Eight prompts. 8–10 minutes each. Volume over quality at this stage.

### Prompt 1 — What questions do my customers ask repeatedly?

Set a timer for 8 minutes. Write down every question that comes to mind. Don't filter.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 2 — What questions should they be asking, but aren't?

The flip side. The things you know they don't know they need to know. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 3 — What is something my customer could talk about all day?

Their genuine interest, not your assumption. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 4 — What could help my customer right now, this week?

Time-bound. Specific. Actionable. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 5 — What do I know that my customers don't, about my industry or niche?

The insider knowledge. The behind-the-curtain stuff. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 6 — What are my readers sharing or posting on social media right now?

Riding existing waves. What's already getting attention in your audience's feeds. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 7 — What's breaking in the industry that my customer needs to know about?

News-driven content. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

### Prompt 8 — What's the one-paragraph solution to a problem they have right now?

A challenge to yourself. Write the paragraph, not just the topic. 8 minutes.

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________

---

## Part 2: Filtering (15 minutes)

Take a five-minute break, then come back.

### Filter 1 — Goal-tag each idea

Go through every idea and tag it: **A** (awareness), **E** (engagement), or **C** (conversion). An idea might serve more than one — pick the primary.

Ideas with no clear goal: cross out.

### Filter 2 — Cut the duplicates

Often the same idea appears in slightly different framing across multiple prompts. Pick the strongest version of each duplicate; cross out the rest.

### Filter 3 — Cut the obvious dross

Ideas that on second look are weak, generic, or unrelated to the audience: cross out. Be ruthless. You should still have 25–35 ideas left.

---

## Part 3: Ranking (15 minutes)

For each goal category, rank the surviving ideas A / B / C.

**A** = "I'd start here, this idea has heat".
**B** = "Good to have in the bank".
**C** = "Lower priority but worth keeping".

Ranking by gut feel is fine — agonising over the precise rank wastes time.

---

## Part 4: The bank document

Move the ranked ideas into a single working bank — a spreadsheet, a Notion page, whatever you'll actually maintain.

Suggested fields per idea:

| Idea | Goal type | Rank | Format options | Source prompt | Status |
|---|---|---|---|---|---|
| _______________ | A / E / C | A / B / C | _______________ | _______________ | Available / Used / Dropped |

The "format options" field is useful: most ideas can be expressed as multiple format types (blog post, video, social thread, etc.). Capturing two or three options per idea makes calendar-filling faster later.

---

## Worked example

Three ideas from a session for a leadership coach for first-time managers:

| Idea | Goal | Rank | Format options |
|---|---|---|---|
| "Why your first management mistake won't end your career — five real recoveries" | A | A | Blog post, LinkedIn post, podcast episode |
| "The Sunday-night dread test: what it tells you about your team's psychological safety" | E | A | LinkedIn post, video, email to list |
| "Three questions to ask in your next 1:1 to find out what your direct report actually thinks" | C | B | Blog post, lead magnet PDF, LinkedIn carousel |

That's the shape. Every idea is goal-tagged, ranked, and format-flexible. When the next month's calendar needs filling, this list becomes the menu.

---

## Maintaining the bank over time

The session above is the first build. Maintenance happens in three modes:

**Add ideas as they appear.** A customer asks a great question — log it. A conversation surfaces an angle — log it. Five seconds, never delayed.

**Update before each month's planning.** Before populating the calendar for the coming month, scan the bank. Move A-ranked ideas into the calendar. Mark them "used".

**Refresh quarterly.** Every quarter, run the ideation session again. Same eight prompts. The bank grows; old unused ideas get re-ranked or dropped.

A working bank that's been maintained for a year holds 80–150 ideas — enough abundance that the user never feels stuck, and enough variety that the content keeps surprising the audience.

---

## What can go wrong

**Stopping after 10 ideas.** The 15th idea is often better than the first. Push through the timer.

**Filtering during ideation.** Killing ideas as they emerge halves the volume. Keep ideation and filtering in separate phases.

**Not goal-tagging.** A bank without tags is hard to use. Two minutes per idea pays off enormously later.

**Starting from your head, not the audience.** The eight prompts are designed to pull from the audience. Trust them. Resist the urge to brainstorm "what would I find interesting".

---

## What success looks like

By the end of one full session, the user has 25–35 ranked, goal-tagged ideas. The next month's calendar can be populated from this bank in under an hour. The maintenance habit means the bank refills as fast as it empties.

That's the substrate the rest of the content system runs on. Most content businesses never build it. The ones that do never run dry.
