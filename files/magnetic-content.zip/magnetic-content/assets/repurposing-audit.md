# Repurposing Audit

A 90-minute exercise to map your existing content, identify what's worth repurposing, and decide how. The output is a top-10 list of repurposing candidates with specific plans for each.

---

## Why this matters

Most small businesses producing content sit on a back catalogue they never reuse. A year or more of blog posts, videos, podcasts, social posts — all live but invisible. The audit surfaces it.

Done properly, the audit unlocks 30–50% of the next quarter's content without any new ideation. The most-leveraged 90 minutes a content business owner can spend.

---

## Step 1: List everything (45 minutes)

A spreadsheet or table. Five columns. Every meaningful piece of content the business has produced in the last 18–24 months.

| Title / topic | Format | Original date | Topic / theme | Performance tier |
|---|---|---|---|---|
| _______________ | _______________ | _______________ | _______________ | A / B / C |
| _______________ | _______________ | _______________ | _______________ | A / B / C |
| _______________ | _______________ | _______________ | _______________ | A / B / C |

Format examples: blog post, video, podcast episode, lead magnet, email, social post (for the standout ones), landing page, course module, webinar.

Performance tiers:
- **A** — Top 20% performer (high views, engagement, sales attributable, or external links)
- **B** — Middle 60%
- **C** — Bottom 20%

If you don't have performance data, mark with your best guess. Performance tier matters most for the A-rank items; the B and C items can be evaluated on other criteria below.

---

## Step 2: Tag the evergreen pieces (15 minutes)

Some content has a shelf life. Some doesn't. Add a column.

**Evergreen** = the topic is still relevant, the advice still holds, the framework still applies. These are the prime repurposing candidates regardless of performance tier.

**Time-bound** = tied to a specific event, a specific seasonal moment, or a specific industry development that's now stale. These are usually not worth repurposing.

| Title | Format | Date | Topic | Performance | Evergreen? |
|---|---|---|---|---|---|
| _______________ | _______________ | _______________ | _______________ | A / B / C | Yes / No |

---

## Step 3: Pick the candidates (10 minutes)

The repurposing candidates that almost always pay off:

- All A-tier evergreen pieces
- A-tier time-bound pieces only if there's a fresh angle (a "one year on" follow-up, a "what's changed since" update)
- B-tier evergreen pieces with strong fundamentals — usually pieces that didn't get the audience they deserved at the time
- Pieces that produced unexpected reactions — DMs, replies, external mentions — even if performance was middling

The candidates not worth repurposing:

- Underperformers without obvious diagnosis
- Time-bound pieces with no fresh angle
- Content tied to a position the user has since changed

**Your top 10 candidates:**

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________
6. _______________
7. _______________
8. _______________
9. _______________
10. _______________

---

## Step 4: Plan the repurposing for each (20 minutes)

For each candidate, decide the mode and the new format.

The three modes:

- **Rewrite** — same idea, fresh execution, often as the same format
- **Recombine** — multiple existing pieces stitched together
- **Reformat** — same idea, different format

Most candidates work best with reformatting. Some benefit from rewriting (especially older pieces that are still good but feel dated). A few are good candidates for recombining.

| Original piece | Mode | Target format | Notes |
|---|---|---|---|
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ | _______________ |

A single original piece often produces multiple repurposed pieces — one row per repurposing, even if the source is the same.

---

## Worked example

For a yoga studio with two years of blog content:

| Original | Mode | Target format | Notes |
|---|---|---|---|
| "5 mistakes new yoga students make" (top-performing blog from 18 months ago) | Reformat | Carousel for Instagram | One slide per mistake; visual pose images |
| Same blog | Reformat | Email newsletter series | Five sequential emails, one per mistake |
| Same blog | Rewrite | Updated blog post titled "5 mistakes new yoga students still make in 2026" | Fresh examples, new framing |
| "Behind the scenes of a class" video (B-tier) | Recombine | Instagram Reel (combined with two other behind-scenes clips) | 60-second compressed version |
| "How to start a daily practice" lead magnet (evergreen, A-tier) | Reformat | Audio version (15-min podcast episode) | Voiceover with calm music |

Five pieces of repurposed content from three originals. None required new ideation. All map onto existing audience appetite.

---

## Step 5: Slot into the calendar (5 minutes)

For each planned repurposing, decide roughly when it'll appear in the next 90 days.

- **Month 1:** typically 2–3 repurposed pieces
- **Month 2:** typically 3–4 repurposed pieces
- **Month 3:** typically 3–4 repurposed pieces

Total: ~30–50% of the calendar from repurposed work.

| Repurposed piece | Target month | Specific week (if known) |
|---|---|---|
| _______________ | _______________ | _______________ |
| _______________ | _______________ | _______________ |

These slots come into the calendar template as filled-in pieces. The remaining slots get filled from the idea bank.

---

## Maintenance

The audit isn't a one-off. After each quarterly cycle, return to the spreadsheet:

- Add the new pieces produced this quarter (with performance tiers once you have data)
- Re-evaluate which earlier pieces still merit repurposing
- Update performance tiers as some pieces age out and others surprise you

A spreadsheet maintained over two years becomes a real asset: it shows the user exactly what their audience has responded to, what they've forgotten, and what's worth pulling back into the rotation.

---

## Common mistakes

**Repurposing the same piece too quickly.** A piece freshly published shouldn't be repurposed the next week. Give it 2–3 months between airings, even across formats. The audience overlaps; they notice.

**Reformatting without adapting.** Just copy-pasting a blog post into LinkedIn doesn't work. Each format has its own conventions. Repurposing means adapting to the new format, not just relocating the content.

**Doing the audit and not the repurposing.** Most users do the audit, find candidates, and never act. The audit is only useful if the candidates make it into the calendar. Block the time for the actual repurposing work — typically 30 minutes per repurposed piece — at the time of the audit.

**Ignoring the bottom 80%.** B and C tier pieces often have hidden gems. The blog post with 200 views that produced three brilliant DMs is worth a closer look. Don't filter only by performance.

---

## What success looks like

After running the audit and acting on it, the user has:

- A clear map of their entire back catalogue
- A top-10 list of repurposing candidates with specific plans
- 30–50% of the next quarter's calendar populated without new ideation
- A maintenance habit that keeps the audit current

That's leverage. The work compounds: each quarter the back catalogue gets bigger, the audit gets more useful, and the proportion of effective content per hour spent rises.
