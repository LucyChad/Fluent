# Repurposing and Distribution

## The two highest-leverage moves a small business can make

Most small businesses producing content are in a treadmill: every week, write or shoot something new, post it once, and start over. The treadmill is exhausting and inefficient. Two moves break it: extending the life of existing content (repurposing) and amplifying its reach (distribution).

Done properly, these two moves can double or triple the output of a content business without doubling the production effort. Most users skip them entirely. The ones who don't pull ahead of their competitors quickly.

## The three modes of repurposing

**Rewriting.** Same idea, fresh execution. The original blog post becomes a new blog post that takes a different angle, uses different examples, or is updated for current circumstances. Useful when the underlying idea is good but the original execution is dated.

**Recombining.** Multiple existing pieces stitched together into a new piece. Three blog posts on related topics become one comprehensive guide. Six podcast episode transcripts become a quick-read article. Useful when the user has built up enough back catalogue to identify themes worth synthesising.

**Reformatting.** The same content, different medium. A blog post becomes a video. A video becomes a podcast. A podcast becomes a series of social posts. The idea doesn't change; the medium does. Useful for almost everything, because different audience members consume different formats.

The strongest content businesses use all three modes routinely. The weakest use none.

## How to audit the back catalogue

Before repurposing anything, the user has to know what they've got. The audit is a 90-minute exercise that pays off forever.

**Step 1: List everything.** Every blog post, podcast episode, video, social post worth mentioning, lead magnet, course module, sales page. Anywhere from 20 to 500+ items depending on how long the business has been running.

**Step 2: Tag each piece by format and topic.** A spreadsheet column for format (blog / video / podcast / social / lead magnet / etc.) and a column for primary topic.

**Step 3: Check performance.** For each piece, capture rough performance: total views, total engagement, any external links, any sales attributable. Three tiers: top 20%, middle 60%, bottom 20%.

**Step 4: Mark the evergreen.** Some content has a clear shelf life (a piece tied to a specific event or moment). Some doesn't (timeless advice, foundational frameworks). Tag the evergreen items separately — they're the prime repurposing candidates.

The output is a single spreadsheet showing what the back catalogue contains, what's performed, and what's still alive enough to be worth repurposing. Most users are surprised by what they have. Many discover content from 18 months ago that's still pulling traffic and could be republished, updated, or expanded with minimal effort.

## Picking the repurposing candidates

Not everything is worth repurposing. The candidates that almost always pay off:

- **Top 20% performers.** These have already proven they resonate. Repurpose them aggressively.
- **Evergreen pieces from any tier.** A foundational explainer from two years ago can be updated and re-released as if new.
- **Pieces that produced unexpected reactions.** A blog post that drew lots of replies, a video that got shared a lot, a piece that generated DMs. The reaction is the signal.
- **Pieces that you wish more people had seen.** The user's gut says "this was good but didn't get the audience it deserved" — usually right.

The candidates that aren't worth repurposing:

- **Time-bound or event-driven pieces.** A post about Christmas sales is dead in February.
- **Underperformers without obvious diagnosis.** If a post bombed, repurposing it without changing the angle is unlikely to help.
- **Content that's clearly outdated.** Industries shift. What was right two years ago might be wrong now.

A good audit produces a top-10 list of repurposing candidates, each with a proposed mode (rewrite, recombine, reformat) and target format.

## A working repurposing example

The user has a 1,500-word blog post from a year ago titled "Five mistakes new freelancers make with their pricing". It performed well at the time. The repurposing plan might be:

- **Reformat 1:** Carve into five LinkedIn posts, one per mistake, posted weekly over a month
- **Reformat 2:** Record a 10-minute video version, post on YouTube and embed on the blog
- **Reformat 3:** Create a downloadable cheat sheet of the five mistakes plus the fix for each, used as a lead magnet
- **Reformat 4:** Pull the strongest example or anecdote into a single Instagram carousel
- **Recombine:** Combine with two related posts into a longer "complete guide to freelancer pricing", as a paid resource or premium content

One blog post, five repurposed pieces, several months of content. The original write-up was the hard work. Everything that followed was leverage.

## The 30/50 rule for repurposed content

A working content calendar can be 30–50% repurposed content without the audience noticing or caring. The rest is new.

Why this works: each format reaches a slightly different segment of the audience, evergreen content holds up, and even readers who saw the original post a year ago benefit from a refresh.

The discipline: don't go above 50% repurposed content for too long. Beyond that, the audience starts to notice the staleness and the brand stops feeling like a current voice. New content keeps the business alive; repurposed content gives the brand depth.

## Distribution: the often-skipped half

Producing content is only half the job. Getting it in front of people who'll value it is the other half. Most "I publish but nobody sees it" problems are distribution problems, not content problems.

The five distribution modes worth knowing:

**1. Native posting.** Publishing directly to the channels where the audience is. Each channel has its own conventions — what works on LinkedIn doesn't always work on Instagram, what works as a blog post might fail as a thread. The native version is rarely just a copy-paste of the original.

**2. Cross-channel republishing.** The same content, adapted for the format conventions of multiple channels. A blog post → a LinkedIn article → a Medium piece → a Twitter thread. Same idea, four different surfaces.

**3. Email distribution.** The user's email list is the channel they own. Every important piece of content should reach the email list. Most users underuse email — sending too rarely or treating email as an afterthought to social.

**4. Partnership distribution.** Other businesses, podcasters, newsletter publishers, communities — anyone with an audience that overlaps with the user's. Guest posts, podcast appearances, newsletter swaps, joint content. High effort to set up; high payoff once running.

**5. Paid amplification.** Putting money behind specific pieces of content to get them in front of new audiences. Useful when content is converting (paid amplifies the conversion); a waste when content isn't (paid amplifies the failure too).

A balanced distribution strategy uses 3–4 of these. Solo native posting on one channel is the weakest possible setup; most "I publish but nobody sees it" diagnoses end here.

## The distribution check

For every piece of content the user produces, ask:

1. Where does it live natively?
2. Where will it be cross-posted, and in what adapted form?
3. Will the email list see it?
4. Is there a partnership or pickup opportunity?
5. Is it good enough to put paid money behind?

A content piece that ships only via mode 1 is using maybe 15% of its possible reach. The same content, distributed across modes 1–4, can reach 5–10x as many people without any change to the content itself.

## What happens when both work together

The user with a strong idea bank, a populated repurposing pipeline, and a multi-channel distribution strategy doesn't have to choose between volume and quality. They produce roughly the same number of "core" pieces — but each one shows up in 4–6 different places over its life, and the existing back catalogue keeps generating new shapes of itself.

Three months in, the content engine starts to feel less like work and more like a system. Six months in, the calendar fills itself because the bank, the back catalogue, and the distribution channels are all working in concert.

That's the leverage. Once it's running, the user is producing more content than businesses with twice the resources, because the system is doing the multiplication.
