# Setting Content Goals

## The three jobs content can do

Every piece of content does one of three jobs. The mistake most businesses make is asking every piece to do all three at once.

**Awareness.** Who knows about you? Awareness content is designed to reach new people, get the brand in front of new audiences, and produce the first impression. Metrics: reach, impressions, traffic, profile views, new followers, brand mentions.

**Engagement.** Who's talking about you? Engagement content is designed to deepen the relationship with people who already know you exist. Metrics: comments, replies, shares, time-on-page, return visits, email reply rate, DMs.

**Conversion.** Who's buying from you? Conversion content is designed to move people from interested to acting. Metrics: sign-ups, leads, purchases, revenue attributed to content, click-through rates on calls to action.

The three jobs need different content, different angles, different formats, and different placement on the calendar. A piece designed for awareness shouldn't be measured by conversions. A piece designed for conversion shouldn't be expected to go viral.

The discipline: every piece of content has one primary goal. The other two might happen as side effects, but they're not the test of success.

## The goal-setting trap

Most content goals are too vague to be useful. "Grow the audience". "Build engagement". "Drive sales". These are wishes, not goals.

Useful content goals are specific, measurable, time-bound, and attached to one of the three jobs.

**Vague:** *"Grow the audience."*
**Useful:** *"Add 500 new email subscribers in the next 90 days from awareness content."*

**Vague:** *"Increase engagement."*
**Useful:** *"Lift average comments per Instagram post from 3 to 8 over the next 90 days."*

**Vague:** *"Drive more sales."*
**Useful:** *"Generate £4,000 in revenue from conversion content over the next 90 days, attributed via UTM links and post-purchase surveys."*

The specificity does three things. It tells the user what to measure. It tells them when the goal is met. And it forces them to be honest about whether they're producing the kind of content that could plausibly hit it.

## Picking the right metrics

For each goal type, the metrics that genuinely tell you whether it's working.

### Awareness metrics

- **Total reach / impressions.** The biggest number, the easiest to inflate, the least useful in isolation.
- **New audience members per period.** New email subscribers, new social followers, new website visitors. The growth rate is the signal.
- **Traffic to the site.** From content posts. Especially from new sources.
- **Brand mentions.** How often the business's name appears in places it didn't appear before.
- **Profile views / About page visits.** Curiosity signals. People who saw a post and clicked through to find out more.

The trap: vanity metrics. A million impressions to people who'll never buy is worse than five thousand impressions to the right audience. Track quality of reach, not just volume.

### Engagement metrics

- **Comments and replies per post.** Quality of engagement, not just quantity. One thoughtful reply outweighs 50 emoji reactions.
- **Shares.** The audience signal that "I want my people to see this".
- **Time-on-page / read-through rate.** For longer-form content. People who read to the end versus people who bounce.
- **Return visits.** People who came back for more after the first piece. Often the strongest signal.
- **Email reply rate.** For email content, this is gold. Even a 2% reply rate on a 5,000-person list is 100 conversations.
- **DM volume / direct conversations.** People reaching out off the back of content.

The trap: engagement that doesn't convert. Sometimes engagement is its own reward (community-building); sometimes it's a signal that content is entertaining but not motivating. Pay attention to whether engagement leads anywhere.

### Conversion metrics

- **Sign-ups attributed to content.** Email list growth from specific posts, lead form submissions, free-trial starts.
- **Sales revenue attributed to content.** Tracked via UTM links, post-purchase "where did you hear about us?", or analytics attribution.
- **Click-through rate on CTAs.** The proportion of readers who clicked the action you wanted.
- **Booking / consultation requests.** For service businesses, the highest-leverage signal.
- **Cost per acquisition (CPA) on content vs paid.** When content converts efficiently, the CPA is excellent.

The trap: attribution. Content rarely produces a single-touch conversion; people read multiple pieces, sit on it, then convert weeks later. Build attribution that captures last-touch and assisted conversions, not just immediate ones.

## The current-state diagnosis

Before setting goals, diagnose where the business is now. Three honest questions to answer:

**Are you publishing consistently?**

- *Yes, weekly or more often, for at least the last quarter.* You have a content rhythm. Goals can build on it.
- *Inconsistently — bursts and gaps.* The first goal needs to be consistency, before any specific awareness/engagement/conversion target.
- *Almost never, or only when you remember.* The 90 days is going to start at a different baseline than someone with a year of weekly posts.

**Are people seeing the content?**

- *Yes, decent reach and growing audience.* Awareness is in reasonable shape; focus on engagement and conversion.
- *Some reach, but it's flat or declining.* Awareness is the priority. Distribution is probably underweight.
- *Almost no reach.* Distribution problem, content problem, or both. Need to diagnose which.

**Is the content producing measurable business results?**

- *Yes, content is generating sign-ups, leads, or sales.* Conversion engine is working; goals can scale up the existing pattern.
- *Some signal but unclear attribution.* Measurement is the priority. Set up tracking before optimising for conversion.
- *No measurable results.* Either the content isn't aimed at conversion, or it's aimed at conversion badly. Likely the first; many businesses produce only awareness/engagement content and wonder why nothing converts.

The diagnosis tells you which of the three goal types to weight most heavily over the 90 days.

## Setting the 90-day goals

A working 90-day goal sheet has one specific, measurable goal in each of the three categories.

**Awareness goal:**

> *Add [number] new [specific audience members — email subscribers, followers, monthly readers] in the next 90 days, from awareness-focused content.*

**Engagement goal:**

> *Lift [specific engagement metric] on [specific channel] from [current baseline] to [target] over the next 90 days.*

**Conversion goal:**

> *Produce [number] of [specific conversion outcome — sign-ups, leads, purchases, revenue] attributed to content over the next 90 days.*

The proportions matter. A new business with a small audience might weight 60% awareness, 30% engagement, 10% conversion. An established business with a warm audience might weight 20% awareness, 40% engagement, 40% conversion. The split should match the business's actual stage and the diagnosis above.

## Reviewing against the goals

Two cadences:

**Weekly review.** 15 minutes. Track the week's metrics against the targets. Note what worked, what didn't.

**Monthly review.** 60–90 minutes. Bigger-picture analysis. Are the goals on track? What does the trajectory look like? What needs to change for next month?

Without the review rhythm, content runs on autopilot and the goals become wallpaper. With it, the calendar becomes a learning loop — each month sharper than the last.

## What the goals enable

Goals aren't just for tracking. They're for selecting. With clear goals, every content idea can be tested:

- *Does this piece serve the awareness goal?*
- *Does it serve the engagement goal?*
- *Does it serve the conversion goal?*

If the answer is "none of the three", the idea doesn't make the calendar. If the answer is "all three", the user should pick one as the primary and design the piece for that one specifically.

Without goals, every idea looks plausible. With goals, only the right ideas look plausible.
