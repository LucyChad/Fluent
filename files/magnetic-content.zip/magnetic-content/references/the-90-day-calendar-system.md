# The 90-Day Calendar System

## Why 90 days

A week is too short. A year is too long. Ninety days is the working unit that lets the user plan with intention while staying responsive to what's actually happening with the audience.

Three months is enough time to:

- Test multiple content angles and see what works
- Build distribution rhythms across multiple channels
- Get measurable signal on awareness, engagement, and conversion goals
- Learn enough about the audience to refine the next quarter's plan

Ninety days isn't the end of content marketing. It's the cycle length. The user runs a 90-day cycle, reviews, and runs the next one with everything they learned baked in.

## The structure of the calendar

Three nested levels:

**Quarterly view.** The 90-day plan as a whole. What's the focus this quarter? Which goals are weighted heaviest? What's the overall theme or arc?

**Monthly view.** Each of the three months in the quarter. What's the specific plan for this month? Which content from the idea bank slots in? What's being repurposed?

**Weekly view.** Each week within the month. The five (or three, or seven, depending on cadence) pieces of content scheduled for the week, with format, goal, and primary channel.

**Daily view.** The detail for each piece of content. Title, format, goal, who's creating, where it's publishing, when it's publishing, status.

The user fills the levels top-down: quarter first, then months, then weeks, then days. Filling bottom-up — picking individual posts in isolation — produces a calendar that has no shape.

## What goes in each level

### Quarterly level

A single page (or document section) that captures:

- The three 90-day goals (awareness, engagement, conversion) — pulled from the goals worksheet
- The three primary topic areas or themes for the quarter
- The proportion of new vs repurposed content (typically 50/50 to 70/30 new-to-repurposed)
- The proportion of content per goal type (e.g., 50% awareness, 30% engagement, 20% conversion)
- Major events or campaigns the calendar should support (a launch, a sale, a seasonal moment)

This sets the shape that everything else fits into.

### Monthly level

For each month, capture:

- The month's specific theme or focus (an arc within the quarter)
- The list of content slotted in from the idea bank, plus the repurposed pieces
- Any specific campaigns or pushes scheduled
- Distribution plan beyond native posting

A working monthly view fits on one page.

### Weekly level

For each week, capture:

- A summary table of the week's content — title, format, goal, day of week, channel
- Any creation/production tasks scheduled for the week
- Anything scheduled to happen at the end of the week (review, metrics check)

A working weekly view also fits on one page. Most users plan one week at a time at this level, in advance of producing it.

### Daily level

For each piece of content:

- **Title:** the working title, can be polished later
- **Format:** blog / video / podcast / social post / email / etc.
- **Goal:** awareness / engagement / conversion (one primary)
- **Who's creating:** the user, a team member, a contractor
- **Where it's publishing:** primary channel + cross-posting channels
- **Outline or brief:** enough notes that the creator (even if it's the user themselves) doesn't have to start from a blank page
- **Status:** planned / in progress / scheduled / published

A working daily view fits in a single row of a spreadsheet, or a single card in a planning tool.

## The cadences that keep the system alive

Three review rhythms:

**Daily (5 minutes).** Glance at today's content slot. Confirm the plan. Note anything urgent.

**Weekly review (30 minutes, end of week).** Look at the week's content performance. Update metrics. Note what worked and what didn't. Confirm next week's plan.

**Monthly review (90 minutes, end of month).** Bigger-picture analysis. Three goal types — how are we tracking? Best-performing pieces of the month — why? Underperformers — why? What's the plan for next month, and what changes from this one?

**Quarterly review (half a day, end of 90 days).** The full reset. Did the goals get hit? What's the trajectory? What's the next 90-day shape? Refresh the idea bank, audit the back catalogue, repopulate the calendar.

The reviews are non-optional. A calendar without reviews is just a list of dates.

## How to populate the next month

A specific working sequence for filling in the next month at the start of it.

**Step 1 (15 minutes):** Read the quarterly plan and the previous month's review. Confirm the focus and the goals.

**Step 2 (20 minutes):** Pull from the idea bank. Pick the A-ranked ideas that match the month's goal weighting. Drop them into the daily slots.

**Step 3 (15 minutes):** Pick the repurposing pieces. From the audit, choose 4–6 pieces to repurpose into the month's calendar. Slot them into days that pair well with the new content.

**Step 4 (10 minutes):** Confirm format mix. The month should have format variety — not five blog posts in a row, not five videos. Mix it.

**Step 5 (10 minutes):** Confirm the distribution plan. For each piece, what's the cross-posting and email plan?

**Step 6 (10 minutes):** Block the production time on the calendar. If you're producing all of next week's content on Monday morning, block it now.

Total: 80 minutes once a month. The investment is what makes the rest of the month easy.

## What to do when things go wrong

The plan won't survive the month intact. Things slip. Content takes longer than expected. A planned video falls through. Life happens.

Three rules for handling slippage:

**Don't catch up by doubling up.** Two posts on Wednesday because Monday's slipped is exhausting and produces lower-quality work. Move Monday's piece to next Monday. Drop the slot, don't double it.

**Repurposing is the safety valve.** When the calendar is slipping, lean on the back catalogue. A repurposed post takes 30% of the time of a new one and still serves the audience.

**Plan small recovery, not heroic catch-up.** If three weeks have slipped, don't try to publish nine pieces in one week. Pick the three most important and ship those. Move on.

The plan is a guide, not a contract. The discipline is in returning to it consistently, not in executing it perfectly.

## What "running" looks like once it's running

By month 3 of the first 90 days, the user should have:

- A populated calendar that's filled in for at least 30 days ahead, always
- A weekly review habit that takes less than 30 minutes
- A monthly review that produces real learning
- A back catalogue being actively repurposed
- An idea bank that's growing rather than shrinking
- Metrics being tracked against the three goals
- A clear sense of which content shapes work in their specific business

That's the system running. Past month 3, the calendar starts feeling less like a project and more like a habit. The user produces consistently good content because the structure makes it the path of least resistance.

That's the goal. Not "I will write more". A system that does the writing-more for you.
