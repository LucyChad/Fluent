# The Magnetic Idea Bank

## What an idea bank is for

An idea bank is a running list of content ideas the user can draw from when it's time to plan the calendar. Done properly, it has 30+ ideas at any given time, each one ranked, tagged with a goal, and ready to slot into a daily plan.

The point of having an idea bank is to remove the worst part of content production: staring at an empty calendar wondering what to write. With a populated bank, the question shifts from "what should I write?" to "which of these is the right one for this slot?".

The other point is quality. Ideas captured in a flow state of audience-questioning produce better content than ideas grabbed at deadline pressure. The idea bank front-loads the thinking.

## Where good ideas come from

The best content ideas don't come from the user's head. They come from the audience.

This isn't a marketing platitude — it's a literal observation. Content pulled from real audience questions, real audience problems, and real audience language consistently outperforms content pulled from the user's sense of "what would be useful". The audience is telling the user what to write about. The discipline is listening properly.

Eight prompts that reliably surface audience-driven ideas:

**1. What questions do my customers ask repeatedly?**

The single highest-leverage prompt. Whatever question comes up over and over in conversations, DMs, emails, sales calls — that's a content idea waiting to happen. The repetition is the signal.

**2. What questions should they be asking, but aren't?**

The flip side. The things the user knows the customer doesn't know they need to know. These produce contrarian, value-dense content that lands hard.

**3. What is something my customer could talk about all day?**

Not the topic the user finds interesting — the topic the audience finds interesting. Often related to the user's product or service, but sometimes adjacent.

**4. What could help my customer right now, this week?**

Time-bound. Specific. Actionable. Content tied to current concerns rather than evergreen advice.

**5. What do I know that my customers don't, about my industry or niche?**

Insider knowledge. The behind-the-curtain stuff. The things the user takes for granted that the audience genuinely doesn't know.

**6. What are my readers sharing or posting on social media right now?**

Riding the existing wave. Whatever's already capturing the audience's attention is fertile ground for content that catches the same wave.

**7. What's breaking in the industry that the customer needs to know about?**

News-driven content. Often the highest-reach pieces because they tap into existing search and conversation interest.

**8. What's the one-paragraph solution to a problem they have right now?**

A challenge to the user. If they can't write a paragraph that solves a current customer problem, the content business has bigger issues than the idea bank.

Run all eight prompts in a single ideation session. Aim for 3–5 ideas per prompt. That gives 24–40 ideas in the bank from one sitting.

## How to run the ideation session

Block 60–90 minutes. Get a notebook or open a doc. No interruptions.

For each prompt above:

1. Write the prompt at the top of a fresh page or section
2. Set a timer for 8–10 minutes
3. Write down every idea that comes to mind. Don't filter. Don't judge.
4. Stop when the timer goes off, even if you have more

The discipline is volume over quality in this phase. Bad ideas are fine — they create momentum, and 90% of the gold comes from the second half of the list anyway, when the user has run out of the obvious answers.

After all eight prompts, take a break. Come back. Filter and rank.

## Ranking the ideas

Three filters in order:

**Filter 1: Goal-tag each idea.** Awareness, engagement, or conversion? An idea might serve more than one — pick the primary. Ideas with no clear goal get cut.

**Filter 2: Cut the duplicates.** Often the same idea appears across multiple prompts in slightly different framing. Merge them.

**Filter 3: Rank within each goal category.** A through C, where A is "I'd start here", B is "good to have in the bank", C is "lower priority". Don't agonise — gut feel is fine.

After filtering, the user typically has 20–30 ideas that survive: maybe 8–12 awareness ideas, 6–10 engagement ideas, and 4–8 conversion ideas. Roughly proportional to the goal weighting from the goals worksheet.

## Maintaining the bank over time

The idea bank isn't a one-off exercise. It's a living document.

The maintenance habit:

- **Add ideas as they appear.** Customer asks a great question — add it to the bank. New industry development — add it. Conversation surfaces an interesting angle — add it. Five seconds, never delayed.
- **Review monthly.** When planning the next month's calendar, scan the bank. Pull the best ideas for the slots that need filling. Mark used ideas as "in the calendar".
- **Refresh quarterly.** A 60-minute ideation session every quarter to top up the bank. Same eight prompts. By this point the user knows their audience better, so each round produces sharper ideas.

A working idea bank that's been maintained for a year typically holds 80–150 ideas. Most never get used. That's fine — the abundance is what makes selection easy.

## What "magnetic" looks like at the idea level

Not every idea in the bank will produce magnetic content. The ones that do tend to share characteristics:

- **They name something the audience feels but hasn't articulated.** "Five reasons I almost quit last year" lands harder than "Strategies for resilience".
- **They make a specific claim.** Not "Some thoughts on pricing" but "Why your hourly rate is the wrong number to focus on".
- **They take a position.** Magnetic content often disagrees with the consensus or names something the user thinks but most don't say out loud.
- **They use the audience's language.** Words and phrases the audience actually uses, not industry jargon.
- **They're framed as the start of a conversation, not the end.** An idea that invites a reply or comment is going to land harder than one that closes the topic.

When ranking the bank, give A's to ideas that have several of these characteristics. Give C's to ideas that have none.

## Common idea-bank mistakes

**Building the bank without a content goals sheet.** Without goals, the user can't goal-tag ideas. Without tags, the bank is just a list of unsorted possibilities. Build the goals first.

**Stopping after 5–10 ideas.** Most users want to stop early because the next idea feels harder than the last. The discipline is pushing through. The 15th idea is often better than the first.

**Filtering during ideation.** Killing ideas as they emerge cuts the volume in half and produces a flatter bank. Keep ideation and filtering in separate sessions.

**Not tagging by goal.** A bank without goal tags is hard to use when planning the calendar. Two minutes per idea to tag pays off enormously later.

**Not refreshing.** A bank built once and never updated runs dry within a few months. The maintenance habit is non-negotiable.

## What the bank produces

By the end of the first ideation session and one filter pass, the user has:

- 20–30 ranked content ideas, tagged by goal
- A clear sense of where ideas are abundant (probably awareness) and where they're scarce (probably conversion)
- A starting point for next month's calendar — the A-ranked ideas slot directly in
- A maintenance habit for keeping the bank populated

That's the substrate that the 90-day calendar runs on. Without it, content planning is reinvention every month. With it, content planning is selection — much faster, much sharper, much more producible.
