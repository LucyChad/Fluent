# How To Manage Your Time Effectively

*Installation guide*

This skill works by giving your AI assistant deep knowledge about time management for small business owners: the 3 P's system (Prioritise, Plan, Produce), goal-setting before task-setting, cutting a bloated to-do list down to what matters, planning a realistic week with time blocks and buffers, and producing without the distractions and perfectionism that eat your day. Once it's set up, you can bring it any time problem you're stuck on and it'll apply the whole system to your actual situation.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Manage Your Time" or "Time Management"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/the-three-ps-of-time-management.md`
- `references/prioritise-your-to-do-list.md`
- `references/plan-your-week.md`
- `references/produce-without-distraction.md`
- `references/building-your-time-system.md`
- `assets/goals-and-time-audit.md`
- `assets/daily-priority-list.md`
- `assets/weekly-plan-and-timeblock.md`
- `assets/focus-and-reflection-log.md`
- `assets/time-system-tracker.md`

**Step 3: Add your business and time context**

In the **Project instructions** field, paste and complete the following:

```
My business: [What you do, who you serve. Specific.]
My working hours: [How much time you actually have for work each week]
My biggest time problem: [Overloaded list? Constant interruptions? Perfectionism? No plan? Can't finish anything?]
My peak hours: [When in the day you're genuinely sharpest]
My current goals: [Paste from the goals-and-time-audit worksheet, or note your top two or three]
What I keep meaning to do but never get to: [The important work that keeps sliding]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a coach who knows how your week runs.

A good first message: *"Run the goals and time audit with me, then help me prioritise today."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A practical time management coach for small business owners. Knows the 3 P's system: Prioritise, Plan, Produce, plus goal-setting, time-boxing, batching, and beating distraction and perfectionism. Helps me build a working system, not just a tidy list for one day."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack: SKILL.md, all five files in `references/`, and all five in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, practical time management coach for small business owners. Use the uploaded knowledge files to guide every response. Always work from my real day, not a hypothetical one. Apply the 3 P's system: Prioritise, Plan, Produce, and start from goals before tasks. Have opinions and share them. Tell me when my list is too long, when I'm scheduling hard work in my worst hours, or when I'm chasing perfect instead of shipping.

My context:
- My business: [fill in]
- My working hours per week: [fill in]
- My biggest time problem: [fill in]
- My peak hours: [fill in]
- My current goals: [fill in]
- The work that keeps sliding: [fill in]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Manage Your Time*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- My business: [fill in]
- My working hours per week: [fill in]
- My biggest time problem: [fill in]
- My peak hours: [fill in]
- My current goals: [fill in]
- The work that keeps sliding: [fill in]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your time

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**How much time you actually have.** Not the fantasy week, the real one. If you have five usable hours between school runs, the skill plans for five, not fifty. Ambition without a buffer is just a missed deadline with extra steps.

**Your biggest time problem.** The specific thing that breaks your days. An overloaded list, constant interruptions, never finishing anything, perfectionism that won't let you ship. Naming it focuses the first few conversations.

**Your peak hours.** When you're genuinely sharpest. The skill schedules your hardest work there instead of letting it land in your post-lunch slump by accident.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Run the goals and time audit with me. Here are my goals and where I think my time leaks."*
- *"I have twenty things on my list today. Cut it to the five that matter."*
- *"What's my one high-impact task today?"*
- *"Plan my week. Here's everything I need to get done and the hours I have."*
- *"Help me time-box this project properly. I always run over."*
- *"When should I do my hardest creative work?"*
- *"Help me batch my content so I'm not setting up five times a week."*
- *"I finished the day exhausted with nothing to show. Walk me through the reflection."*
- *"I'm a perfectionist and it's costing me hours. Help me ship."*
- *"Set up a weekly review so this actually sticks."*

---

*Manage Your Time is part of the Fluent skill library. More skills at fluent.md.*
