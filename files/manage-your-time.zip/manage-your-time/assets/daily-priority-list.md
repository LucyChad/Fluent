# Daily Priority List

The worksheet for Step 1: Prioritise. Use it each morning, or the evening before. It takes a full, overwhelming list and turns it into three to five tasks in genuine order of importance, with the single highest-impact one on top.

Photocopy it, retype it into your notes app, or just keep the shape in your head. The method matters more than the page.

---

## Step 1: Brain-dump everything

Write down every task on your plate today. Do not rank, do not filter, just empty your head. You cannot prioritise a list you have not fully seen.

- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________
- _______________________________________________

---

## Step 2: Trim

Count your items. More than seven or eight? Trim now.

Cross out:

- [ ] Everyday tasks you'll do anyway (checking email, routine admin)
- [ ] Things that will happen regardless (a call you're already expecting)
- [ ] Anything that does not need to happen *today*

---

## Step 3: Find the order

Ask: **"If I could only do one thing today, what would it be?"** Write it at number 1. Then ask again of what's left for number 2, and keep going.

As you place each one, sense-check against impact: which task has the greatest direct or indirect effect on your business or goals? High impact moves up. And remember the bonus rule: greatest impact for the *least effort* moves up furthest.

| # | Task | Impact (high / med / low) | Rough time needed |
|---|---|---|---|
| 1 (the one thing) | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

If you have more than five, the rest go to the backburner below.

---

## Step 4: Remove or delegate

Go through the list once more. Anything you can delete entirely or hand to someone else?

**Delete:** _______________________________________________

**Delegate (to whom):** _______________________________________________

---

## The backburner

Everything that did not make today's top five. These are not forgotten, they are parked. Give them a home so they stop nagging.

**Backburner tasks:**

- _______________________________________________
- _______________________________________________
- _______________________________________________

**When I'll deal with them** (a weekly catch-up slot, a daily end-of-day window, delegation, or an "if I finish early" list):

_______________________________________________

---

## Today's headline

Finish the sentence before you start work:

**The one thing that will make today a win is:** _______________________________________________
