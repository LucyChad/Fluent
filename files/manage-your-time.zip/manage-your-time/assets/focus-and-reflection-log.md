# Focus And Reflection Log

The worksheet for Step 3: Produce. Two parts: a focus checklist to run *before* and *during* a work block, and a reflection to run *after* the day. The checklist keeps you on the rails. The reflection turns one messy day into a smoother week.

---

## Before you start a block: the focus checklist

- [ ] **Timer set** for the block. Now forget the clock and work; the alarm decides when you stop.
- [ ] **The "is this necessary?" test passed.** Does this task move a goal? If it appeared unplanned, can it be deleted, delegated, or automated instead?
- [ ] **Distractions designed out.** Notifications off, social media closed, others told you're heads-down.
- [ ] **Good enough, not perfect.** Decide the finish line now so perfectionism can't move it later.

During the block: **see it through.** You chose this task deliberately. Don't task-hop, don't drift. If you hit a genuine wait, use the dead minutes on another task rather than letting them leak.

---

## After the day: the reflection

A few honest minutes. Not a guilt exercise, just data on how you really spend your time versus how you planned to.

**What did I get done?**

_______________________________________________

**What did I NOT get done that I was supposed to?**

_______________________________________________

**What distracted me?**

_______________________________________________

**What helped me work faster?**

_______________________________________________

**Which tasks needed MORE time than I blocked?**

_______________________________________________

**Which tasks needed LESS time than I blocked?**

_______________________________________________

**Quick yes/no gut checks:**

- Am I trying to do too many things? _______
- Is anything taking longer than it's worth? _______
- Should any task have happened at a different time of day? _______
- Can I delegate anything? _______
- What shortcut (template, automation, reusable asset) could I use next time? _______

**The single change I'll make tomorrow:**

_______________________________________________

---

## Spot the pattern

The reflection only pays off when you look across several days. After a week, skim your logs and finish these:

- The distraction that keeps reappearing: _______________
- The estimate I keep getting wrong: _______________
- The time of day I keep wasting: _______________
- The one habit that would fix the most: _______________
