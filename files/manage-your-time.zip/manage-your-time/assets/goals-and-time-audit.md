# Goals And Time Audit

A 30-minute exercise to do once, before you touch a to-do list. You cannot manage your time well until you know what you are managing it towards, and where it is currently leaking. This worksheet sets both.

Revisit it at the start of each quarter, or whenever your goals shift.

---

## Part 1: Set your goals

Keep this tight. No more than three long-term and three short-term goals. A long list is a wish, not a plan. For each, set a milestone that tells you that you are on track and a deadline that gives you a reason to move.

### Long-term goals (the next 6 to 12 months)

| Goal | Milestone (how you'll know you're on track) | Deadline |
|---|---|---|
| 1. | | |
| 2. | | |
| 3. | | |

### Short-term goals (the next 30 to 90 days)

| Goal | Milestone | Deadline |
|---|---|---|
| 1. | | |
| 2. | | |
| 3. | | |

---

## Part 2: Audit where your time goes

Time management is not about finding more hours. It is about reclaiming the ones being eaten by non-essential work. So find the leaks.

### Where am I wasting time?

List the tasks and habits that eat your day without moving anything that matters.

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________

### Why is each one a problem?

For each leak above, note why it is costing you. Is it low value? A distraction? Something that only feels urgent? Something you could hand off?

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________

### Which leaks will I focus on first?

Pick the two or three you most want to fix as you start the system. Be specific.

- _______________________________________________
- _______________________________________________
- _______________________________________________

---

## Part 3: The one honest question

Looking at your goals and your leaks side by side: **how much of your typical week is currently spent on work that actually moves a goal?**

Your honest estimate: _______ %

Where you'd like it to be in 30 days: _______ %

That gap is the work. The rest of this skill closes it.
