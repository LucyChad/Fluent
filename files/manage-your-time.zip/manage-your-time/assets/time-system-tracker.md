# Time System Tracker

This is what turns a good week into a system. A rolling record of what you got done and the progress it made towards your goals, plus a weekly review that tunes the machine. Run it for your first 10 days on the system, then keep the weekly review going for good.

---

## The 10-day progress tracker

At the end of each day, one line. Keep it short. The point is the trend, not the detail.

| Day | What I got done (the wins that mattered) | Progress towards a goal? |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |

After 10 days, you should have a clear sense of what's working and what needs changing. That sense is the system starting to teach you about yourself.

---

## The weekly review

Once a week, step back further. Two questions only.

### 1. Am I making progress towards my goals?

Pull out your goals from the Goals And Time Audit. Check each milestone.

| Goal | On track? | If not, what's the gap? |
|---|---|---|
| | | |
| | | |
| | | |

If a whole week of effort hasn't advanced anything that matters, that's a signal. Something in your priorities needs to change, not your effort.

### 2. Is the system itself working?

Be honest about the method, not just the output.

- Are my time blocks the right length? _______________
- Are my buffers big enough? _______________
- Is my batching in the right place? _______________
- Am I scheduling hard work in my peak hours? _______________
- What one adjustment will I make to the system next week? _______________

---

## Remember

This system is yours, and it's perfected by trial, error, and constant small revision, not copied wholesale from anyone else. The version you finish the quarter with won't be the version you started with. That's not failure. That's the system working exactly as it should.

The goal was never more hours. It's the same hours, finally pointed at the work that matters, on a method that improves itself a little every week.
