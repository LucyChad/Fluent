# Weekly Plan And Time-Block

The worksheet for Step 2: Plan. It turns your prioritised tasks into a realistic week, with time blocks sized to allow for real life, scheduled into the hours you are actually sharp, with buffers and catch-up time built in, and similar work batched.

Plan the week ahead on a Sunday or Monday, then refine each day at its close.

---

## First, map your natural rhythms

Before you schedule anything, know yourself. When are you genuinely at your best?

- **My sharpest / most creative hours:** _______________
- **My best problem-solving hours:** _______________
- **My most sociable hours (calls, emails, meetings):** _______________
- **My low-energy slump (save for light admin):** _______________

Schedule demanding work into your peak hours. Do not waste your best brain on tasks any version of you could do.

---

## The weekly grid

Fill in your blocks. Keep each block honest: overestimate how long things take, and leave a buffer of 20 to 30 minutes between blocks. Mark batched work (similar tasks grouped) and your daily catch-up slot.

| Time block | Mon | Tue | Wed | Thu | Fri |
|---|---|---|---|---|---|
| Morning block 1 | | | | | |
| Buffer | | | | | |
| Morning block 2 | | | | | |
| Catch-up / lunch | | | | | |
| Afternoon block 1 | | | | | |
| Buffer | | | | | |
| Afternoon block 2 | | | | | |

---

## Batch your similar work

What can you group into one block or one day instead of dripping it across the week?

| Type of work to batch | Day / block I'll do it |
|---|---|
| e.g. content recording | |
| e.g. client calls | |
| e.g. admin and invoicing | |
| | |

---

## Time-boxing your top priority

Take your single highest-impact task and break it into its actual sub-tasks. Box each one.

**Priority task:** _______________________________________________

| Sub-task | Time box | Day / when |
|---|---|---|
| 1. | | |
| 2. | | |
| 3. | | |
| 4. | | |

Rule for the boxes: when you hit the end of a box, decide deliberately to extend it or to pick the task up fresh tomorrow. Do not let one task quietly eat the day.

---

## Close-of-day check (do this each evening)

- [ ] Did anything not get done? Move it to tomorrow.
- [ ] Refine tomorrow's blocks while today is fresh.
- [ ] Anything from the backburner ready to come forward?
- [ ] Did my estimates hold? Adjust tomorrow's boxes accordingly.

---

## A note on tools

Whatever you use to hold this plan, a paper planner, a calendar, or a project management app, keep it simple. The tool exists to reduce friction, not to become a second job. If you're trying a paid app, use the free trial first and never pay for features you won't use.
