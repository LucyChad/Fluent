# Step 2: Plan

## From a list to a week

You have a prioritised list. Now comes the step most people skip, and the reason their good intentions keep evaporating: turning that list into a plan for *when* and *how* the work actually happens. A priority with no slot on the calendar is just a hope with a deadline attached.

Planning is about completing your list in the most efficient and effective way possible. It is where you decide how much time each task gets, when in the day it runs, and how you protect it from the chaos that every real week contains.

## Time-box your tasks

Think of time as a flexible resource that stretches or shrinks to fit the limits you set. Give it no limit and a single task will quietly swallow the morning.

So plan a box of time for each task. Decide in advance, for example, that the landing page copy gets two hours this morning. When you reach the end of that box, you make a deliberate choice: extend the box because the task genuinely needs more, or stop and pick it up fresh tomorrow when your mind has reset. The box does not force you to finish. It forces you to *decide*, instead of drifting, and it stops one sticky task from eating the work behind it.

The common trap is the task that gets stuck in the details. You set two hours for the copy, and at the end you are still fiddling with the wording. Rather than grind on with a tired brain, it is often smarter to make it tomorrow's first priority and move on to the next item today.

## Find your natural rhythms

You are not equally capable at every hour. There are times of day when you think most clearly, solve problems best, or communicate most easily, and there are times when you are better off doing something that does not need much of you. Schedule against your real rhythms instead of fighting them.

If your sharpest creative window is late morning, put content creation or strategy there, not the admin that any version of you could handle. If you are most personable in the late afternoon, that is when to write the important emails or take the calls. Matching the task to the hour is free productivity. Most people throw it away by doing their hardest work in their worst window simply because that is when it landed on the list.

## Plan for interruptions

No matter how cleanly you plan, some things will run long and some interruptions will arrive unannounced. A plan that assumes a perfect day is a plan that breaks by ten o'clock. So build the imperfection in from the start.

**Overestimate.** When you set time limits, overestimate how long each task will take. Do not pack a morning so tightly that the first overrun puts you behind for the rest of the day, because once you are behind you are back on the treadmill, forever chasing.

**Buffer.** Add a buffer of empty time between blocks of work. If you are working in two-hour blocks, drop a twenty or thirty minute gap with no assigned task in between. That gap absorbs the overruns and the interruptions without damaging the next block.

**Plan for catch-up.** Schedule a specific catch-up slot, perhaps before lunch or at the end of the day, for whatever slipped. And here is the quiet benefit: if you do not need it, the catch-up time becomes a break, or a head start on tomorrow. Padding the schedule never costs you. Either it saves a difficult day, or it gives you the rare gift of finishing early.

## Batch similar tasks

It is often inefficient to do a little of everything every day, because every task type carries a setup cost. Batching groups similar work into one longer block, or even a whole day, so you pay that setup cost once instead of repeatedly.

If you publish a weekly video or podcast, the setting up, recording, editing, and producing all take time each round. Do it all in one reserved block, say Friday, and you save hours over spreading it across the week. If you have a stack of client calls to make, two focused mornings beats sprinkling them through every day and breaking your concentration each time. Batching is also the right move for any work where you need to get "in the zone", because getting into the zone is itself a cost you only want to pay once.

## Use tools, but keep them simple

Any system for tracking your tasks is fine as long as you actually use it. A paper planner is a system. An online calendar is a system. For some people a project management tool makes keeping track genuinely easier, especially with several projects running at once, because it offers interactive calendars, an at-a-glance view of multiple projects, built-in planning methods, and easy sharing with anyone who works with you.

If you go that route, try the free options first. A simple free tool is often all you need, and you should never pay for features you will not use. Take advantage of free trials and make sure a tool fits before you commit to it. Above all, do not let the tool become the project. The whole point is to reduce friction, not to acquire a new hobby that happens to look like work. Plenty of people manage perfectly well on a calendar and a notebook.

## Get ready for tomorrow, and plan the week

Close each day by preparing the next one. Look at your list, move anything you did not get to onto tomorrow, and refine tomorrow's shape while today is still fresh in your mind. Five minutes here saves you inventing the day from scratch at eight the next morning.

Better still, plan the whole week in advance. A week planned ahead lets you place your blocks intelligently, batch across days, and protect your peak hours before other people's requests fill them. Then at the end of each day you simply adjust the next day for whatever changed. The week gives you the structure; the daily tidy keeps it current.

Once a week or so, step back and review your longer-term projects and the system itself. Is it working? These planning systems are deeply personal and they are perfected through trial, error, and constant small revision, not by copying someone else's wholesale. The plan you finish the quarter with will not be the plan you started it with, and that is exactly as it should be.

## What you walk away with

A planned week is one where every priority has a place: a time block sized with a little room to spare, scheduled into the hour where you are actually capable of it, with buffers and a catch-up slot absorbing the inevitable mess, and similar work batched so you are not forever starting over. That is what Step 3 executes against. A plan this realistic is one you can actually keep.
