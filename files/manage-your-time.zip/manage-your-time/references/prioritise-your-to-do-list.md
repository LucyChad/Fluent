# Step 1: Prioritise

## A to-do list is not a plan

Everyone knows how to write a to-do list. That is precisely the problem. A plain list puts every task on the same line, at the same weight, as though answering an email carried the same value as landing a client. It does not. Learning to prioritise properly is the single biggest lever you have on your productivity, because it decides where all the rest of your effort lands.

Prioritising is the act of working out which items are essential and which are simply present. Most lists are mostly present.

## The core move: find the one thing

Start by getting everything out of your head and onto the page. Write down every task you have to do today. Do not rank as you go, do not filter, just empty the lot out. You cannot prioritise a list you have not fully seen.

Now count it. If you have more than seven or eight items, the list is too long to be a day and you need to trim. Take out the everyday tasks that you will do anyway, like checking email, and take out the things that will happen regardless, like a call you are already expecting to receive. Those do not need a slot on a priority list; they will occur without your management.

Then make the move that does the real work. Look at what is left and ask: *if I could only do one thing today, what would it be?* Put that single task at the top. Now look at the rest and ask the same question again for second place. Keep going, and you end up with something a plain list never gives you: your tasks in genuine order of importance.

## The impact lens

When you are deciding what your "one thing" is, the most useful test is impact. Which task will have the greatest direct or indirect effect on your business? Which one moves you towards a goal, brings in income, or unlocks other work? Those are your high-impact tasks, and they belong at the top regardless of how appealing or unappealing they are.

This matters because the appealing tasks and the high-impact tasks are rarely the same. Tidying your files feels productive and changes nothing. The awkward sales follow-up feels uncomfortable and might be the most valuable hour of your week. Prioritise by impact, not by ease or by mood.

A refinement worth keeping in mind: the best task is often the one with the greatest impact for the least effort. When two items matter, the one that takes twenty minutes beats the one that takes a day. Move the high-impact, low-effort work up.

## Tactics for refining the list

The "one thing" method is enough most days. When it is not, these tactics sharpen it further. Use whichever ones fit how your mind works; the goal is a simple system, not a complicated one.

**Rank items with a scoring system.** Tag each task: 1 means must be done today, 2 means should be done today, 3 means does not need to be done today. Then prioritise within each band. This is especially handy when you have a pile of small things and need to sort them fast.

**Set a deadline for everything, specific to a time of day.** Give every task a deadline even when there is no real time pressure, and make it a time, not just a date. If one task is due by mid-morning and another by end of day, you have just told yourself which one comes first.

**Categorise by work area.** Split work-related and personal tasks, or break work into its functional areas, and focus on one list at a time. One list during the working day, the other after it.

**Categorise by time of day.** If certain tasks naturally belong to the morning and others to the afternoon, make small lists for each part of the day rather than one long undifferentiated one.

**Break up big tasks.** Anything that takes longer than a day is not one to-do item, it is a project. Break it into daily milestones and put those milestones on the list. "Write the course" is paralysing; "draft module one introduction" is doable.

## The backburner

You should be aiming for three to five real tasks on a daily list. This means most of what you wrote down will not make the cut, and that is the point. You have to break the habit of believing you must do everything, and be ruthless about throwing out what is not essential right now.

So what happens to everything that gets bumped? That is the backburner, and the trick is to have a deliberate home for it rather than letting it haunt the edges of every day. Choose one of these:

- **A recurring catch-up slot.** Pick a regular time, perhaps the end of a workday while you are still at your desk, or one afternoon a week, when you work through the backburner items together.
- **Delegation.** Hand the task to someone who can carry it out for you. The backburner is the most honest list you have of what you should be delegating.
- **A secondary list.** Keep an "if I finish early" list so that on the rare day you clear your priorities, you have productive overflow ready rather than drifting.

The backburner is not where tasks go to be forgotten. It is where non-urgent tasks wait their turn so they stop competing with the work that matters today.

## What you walk away with

A finished prioritisation is short. Three to five real tasks, in order, with the single highest-impact one sitting at the top, and everything else either trimmed, delegated, or parked on the backburner with a time to be dealt with. That list is what Step 2 plans, and what Step 3 produces. Get this right and the rest of the system has something worth scheduling.
