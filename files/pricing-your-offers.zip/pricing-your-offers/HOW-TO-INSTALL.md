# How To Price Your Offers

*Installation guide*

This skill works by giving your AI assistant deep, specialised knowledge about pricing strategy — and your specific business context. Once it's set up, it runs in the background of every conversation. You don't have to invoke it or remind it what it knows. You just talk, and it applies the right frameworks to whatever you're working on.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**
- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Price Your Offers"

**Step 2: Add the skill files**
- Inside your project, click **Add content** (or the upload icon)
- Upload all the files from this skill pack:
  - `SKILL.md`
  - `references/pricing-foundations.md`
  - `references/find-your-price.md`
  - `references/creative-pricing-strategies.md`
  - `references/handle-pricing-objections.md`
  - `assets/pricing-audit-worksheet.md`

**Step 3: Add your business context**
- In the **Project instructions** field, paste and complete the following:

```
My business: [Describe what you do and who you do it for]
My main offers: [List your key services or products and current prices]
My target customer: [Describe them specifically]
My current pricing challenge: [What are you trying to figure out or fix?]
My competitors: [Name 2-3 if you know them]
```

**Step 4: Start a conversation**
You're ready. Open a new chat inside the project and talk to it like you'd talk to a pricing consultant who already knows your business.

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**
- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**
- In the **Create** tab, describe what you want: *"A pricing strategist for my small business, with deep knowledge of pricing strategy, value communication, and objection handling."*
- Click **Configure** to set it up more precisely

**Step 3: Add the skill files**
- In the **Configure** tab, scroll to **Knowledge**
- Upload all files from this skill pack (SKILL.md and all files in references/ and assets/)

**Step 4: Set the instructions**
In the **Instructions** field, paste:

```
You are a pricing strategist for small business owners. Use the uploaded knowledge files to inform all your responses. Always apply frameworks to the user's specific situation rather than giving generic advice. Ask one clarifying question at a time when you need more context.

My business context:
- What I do: [fill in]
- My offers and current prices: [fill in]
- My target customer: [fill in]
- My main pricing challenge: [fill in]
```

**Step 5: Save and use**
Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**
- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**
- Name: *Price Your Offers*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**
- Upload the files from `references/` and `assets/` using the attachment option in the instructions area

**Step 4: Add your context**
At the end of the instructions, add:

```
My business context:
- What I do: [fill in]
- My offers and current prices: [fill in]
- My target customer: [fill in]
- My main pricing challenge: [fill in]
```

**Step 5: Save and start**
Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your business

The more context you give at setup, the more useful it is from the first conversation. Here's what to include:

**Describe your business clearly.** Not just what you do, but who you do it for and why they hire you over alternatives.

*Weak:* "I'm a graphic designer."
*Strong:* "I'm a graphic designer specialising in brand identity for independent food and drink businesses. Most of my clients are launching their first proper brand and have never worked with a designer before."

**List your offers with current prices.** If you're not sure whether your prices are right, just put what you currently charge — that's the starting point.

**Name your pricing challenge.** Are you undercharging? Struggling to sell at your current rate? Trying to create tiers? Moving from hourly to project pricing? Being specific here means you get useful answers faster.

---

## Getting the most from the skill

Some prompts to get you started:

- *"I want to do a full pricing audit. Can we work through the worksheet together?"*
- *"A prospect just said my price is too high. Here's what I said — how should I have handled it?"*
- *"I want to raise my prices. Walk me through how to do it without losing clients."*
- *"Help me write the pricing section of my website."*
- *"I'm thinking of creating a premium tier. What should go in it and how do I price it?"*

---

*Price Your Offers is part of the Fluent skill library. More skills at fluent.md*
