# Pricing Audit Worksheet

Work through this with your AI pricing strategist. Answer each section as honestly as you can — there are no right answers, only useful ones.

---

## Part 1: Your current pricing

**What do you currently offer?**
List your main offers (services, products, programmes) and what you currently charge for each.

| Offer | Current price | How you charge (hourly / project / retainer / other) |
|-------|--------------|------------------------------------------------------|
|       |              |                                                      |
|       |              |                                                      |
|       |              |                                                      |

**How did you arrive at these prices?**
*(e.g. "I looked at competitors," "I worked out my costs," "I asked someone," "I guessed")*

---

## Part 2: Your costs and floor

**What does it actually cost you to deliver each offer?**
Include your time (at a rate that reflects your expertise), tools, overheads, and any subcontracted work.

| Offer | Time spent | Direct costs | Minimum price to break even |
|-------|-----------|-------------|----------------------------|
|       |           |             |                            |
|       |           |             |                            |

**What would you need to earn per month to feel well-paid and financially stable?**

Monthly target: £ ___________

**How many clients or sales per month do you want to take on?**

Target client volume: ___________

**Implied price per client/sale to hit your target:**
(Monthly target ÷ target volume) = £ ___________

---

## Part 3: Your customers

**Who is your ideal customer?**
*(Be specific — not "small business owners" but "independent consultants in their first three years who are moving from employed to self-employed")*

**What specific problem does your offer solve for them?**

**What does that problem cost them if they don't solve it?**
*(Time, money, stress, missed opportunities — be concrete)*

**What outcome do they get from your offer?**

**What have they tried before? What did that cost?**

---

## Part 4: Your market

**Who are your three closest competitors?**

| Competitor | What they offer | Their price | What customers say about them |
|-----------|----------------|------------|-------------------------------|
|           |                |            |                               |
|           |                |            |                               |
|           |                |            |                               |

**Where do you sit relative to them?**
- [ ] I'm the cheapest option
- [ ] I'm in the middle of the market
- [ ] I'm at the premium end
- [ ] I'm not sure

**Is that where you want to sit? Why?**

---

## Part 5: Your value proposition

**In one sentence, what does your offer do for your customer?**
*(Try: "[Offer] helps [specific customer] to [outcome] by [your method or approach]")*

Draft UVP:

**What three things make your offer different from the alternatives?**

1.
2.
3.

---

## Part 6: The honest assessment

**Are you currently undercharging?**
Signs: customers say yes immediately with no hesitation; you feel resentful delivering the work; you're busy but not hitting your financial targets; you're attracting clients who don't value your work.

**Are you overcharging (or struggling to sell)?**
Signs: prospects consistently hesitate or go elsewhere; you're having to over-explain or over-deliver to justify the price; conversion rate is very low.

**What's the one pricing change that would have the biggest impact on your business right now?**

---

## Part 7: Next steps

Based on your answers, work with your pricing strategist to identify:

- [ ] The price adjustment you'll make (and when)
- [ ] The pricing structure that suits your offer best
- [ ] The messaging changes needed to support the new price
- [ ] Any new offers to create (entry-level, premium, bundle)
- [ ] The client or customers you'll communicate price changes to

---

*This worksheet is part of the Price Your Offers skill pack by Fluent.*
