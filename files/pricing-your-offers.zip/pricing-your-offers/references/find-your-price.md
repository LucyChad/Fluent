# Finding Your Price

## Start with research, not a number

The most common pricing mistake is picking a number before doing any research — usually based on gut feeling, what a friend charges, or fear. Research doesn't have to be elaborate, but it should happen before you set anything.

There are three things to research: your competitors, your customers, and your costs. In that order of importance.

---

## Research your competitors

Competitor pricing tells you what the market currently accepts. It's your benchmark, not your ceiling.

**How to do it:**
1. List your five nearest competitors — businesses offering a similar outcome to a similar customer
2. Find their pricing (or estimate it from how they position themselves)
3. Note what's included, how it's structured, and how they justify it in their marketing
4. Look at reviews: what do customers praise, and what do they complain about?

What you're looking for is the gap — the thing your competitors either don't offer, don't explain well, or get consistently criticised for. That gap is where you position yourself.

**Two strategies once you have the data:**

*Undercut:* Price below competitors to win on accessibility. Works if your offer is genuinely comparable and you have the volume to make the margin work. Risk: it's easy to undercut further. Don't make low price your only selling point.

*Premium:* Price above competitors by offering something demonstrably better — a stronger outcome, a faster result, a more specific focus, better support. Requires stronger marketing, but earns more per customer and attracts buyers who aren't shopping on price.

---

## Research your customers

Your price is ultimately validated by customers, not by you. The goal is to find the range — not just what they'll pay, but where "too cheap" starts to feel untrustworthy and where "too expensive" triggers hesitation.

**Methods:**

*Direct conversations:* Talk to existing or past customers. Ask what made them decide to buy, what nearly put them off, and how they'd describe the value they got. Don't ask "what would you pay?" directly — people understate it. Ask instead: "What would you have paid if you'd seen this for the first time?"

*Surveys:* For larger audiences, a short survey works well. The Van Westendorp Price Sensitivity Meter uses four questions:
- At what price would this feel too cheap to be credible?
- At what price would this feel like good value?
- At what price would this start to feel expensive?
- At what price would this be too expensive to consider?

The range between "good value" and "starting to feel expensive" is your optimal pricing zone.

*Test with a soft launch:* Offer to a small group at your proposed price and watch what happens. A high conversion rate suggests you may have priced too low. Near-zero conversions, despite interest, suggests a messaging or positioning problem — rarely a price problem.

---

## Know your costs (then set them aside)

Costs are the floor, not the ceiling. You need to know them so you don't accidentally lose money, but they shouldn't determine your price.

Calculate:
- Your direct costs per offer (tools, materials, subcontractors)
- Your time per offer (including admin, client comms, revisions)
- Your overheads allocated per offer (software, workspace, marketing)
- Your desired take-home, expressed as an hourly or daily rate

If your value-based price is above this floor — which it should be — proceed. If it's below, you either have a cost problem or you're not yet articulating the value clearly enough.

---

## Testing your price in the real world

Pricing isn't a one-time decision. It's a hypothesis you test and revise.

**Signs you've priced too low:**
- Customers say yes immediately with no hesitation
- You're fully booked but not earning what you need
- Customers treat you like an order-taker rather than an expert
- Raising prices feels terrifying because you think you'd lose everyone

**Signs you've priced too high (or have a messaging problem):**
- People show genuine interest but don't buy
- You get consistent "I'll think about it" responses
- You're losing deals to significantly cheaper competitors

Note: most "too expensive" objections are messaging problems, not price problems. Before lowering your price, look at how clearly you're communicating the outcome.

---

## Pricing services: the shift from time to outcome

If you charge by the hour, you create a perverse incentive — the faster and better you get, the less you earn. Outcome-based pricing breaks that trap.

**Instead of:** "£75/hour, approximately 10 hours = £750"
**Try:** "£950 for a complete brand naming project, delivered in two weeks"

The client buys certainty and an outcome. You earn more as your efficiency improves. Everyone wins.

If hourly billing is unavoidable in your industry, consider charging a *day rate* or *project minimum* to establish a value floor.
