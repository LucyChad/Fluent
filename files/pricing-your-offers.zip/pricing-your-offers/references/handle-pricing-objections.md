# Handling Pricing Objections

## What "it's too expensive" actually means

When a prospect tells you your price is too high, the instinct is to lower it. Don't.

"It's too expensive" is almost never a statement about your price. It's a statement about perceived value — the customer doesn't yet see a clear enough connection between what you're charging and what they'll get. That's a communication problem, not a pricing problem.

Before you change your price, get curious about the objection. There are usually four things going on:

1. **They don't understand what they're getting.** Your value hasn't been communicated clearly enough. The outcome is abstract, the process is unclear, or the comparison to alternatives hasn't been made.

2. **They're comparing you to something cheaper.** They've seen a lower price elsewhere and can't yet see why yours is higher. This is a positioning question, not a price question.

3. **They're not the right customer.** They're optimising for price because the outcome doesn't matter enough to them to pay for it. In this case, no discount will make them a good client.

4. **They genuinely can't afford it right now.** This is rare, but real. The answer here is a different offer at a different price point — not a discount on your main offer.

---

## How to respond to "it's too expensive"

**Step 1: Don't panic, don't discount.**

A pause is fine. "I appreciate you being direct with me" is fine. Immediately halving your price signals desperation and tells them the first price was arbitrary.

**Step 2: Get curious.**

Ask a question that gets underneath the objection:
- "Can you tell me a bit more about that? Is it the overall investment, or is it more about the timing?"
- "Is it that you're not sure it's the right fit, or more that the budget isn't there right now?"
- "What were you expecting the investment to be?"

The answer will tell you which of the four scenarios above you're in.

**Step 3: Reframe to outcome.**

Most objections dissolve when you anchor the price to the result. Help them see the cost of *not* solving the problem.

- "What's it costing you to keep handling this yourself — in time, in stress, in lost revenue?"
- "If this solves [specific problem], what would that be worth to your business over the next year?"
- "The clients I work with typically see [result]. What would that change for you?"

You're not being pushy. You're helping them make a better-informed decision.

**Step 4: Offer a different entry point — not a discount.**

If the price is genuinely out of reach, offer a different *offer* at a lower price — not the same offer at a reduced price. A smaller scope, an entry-level version, a payment plan.

"I totally understand. I do have a smaller engagement that's designed for people earlier in the process — it's £X and it covers Y. Would that be worth exploring?"

This preserves the value of your main offer and creates a pathway in.

---

## When a client says "I found someone cheaper"

This is a comparison objection, not a price objection. Your response is to focus on differentiation, not to match the price.

"That's good to know — it's worth comparing carefully. The main differences between what I offer and a cheaper alternative are usually [specific things: depth of work, what's included, your background, the outcome guarantee, the speed]. Does any of that matter for what you're trying to achieve?"

Let them answer. If those differences don't matter to them, they're probably not your customer. If they do, you've just made the case for your price without lowering it.

---

## When to add value instead of cutting price

If you're consistently getting "too expensive" across multiple prospects, before reducing your price ask: what could I add that would make this feel like an obvious yes?

Things that add genuine value:
- A faster delivery timeline
- More direct access to you (calls, reviews, feedback)
- A tangible deliverable they don't currently get (a report, a template, a plan)
- An extended guarantee or support period
- Complementary resources that help them implement faster

The goal is to widen the gap between your price and their perceived value — by increasing the value, not by reducing the price.

---

## Raising prices on existing clients

This deserves its own note because it stops many small businesses from ever increasing their rates.

The rules:
1. **Give notice.** Tell clients about a price increase before it happens — four to six weeks minimum.
2. **Frame it around value, not your costs.** "My pricing is going up because of X I've been able to add" lands better than "I need to charge more."
3. **Be matter-of-fact.** The more you apologise or over-explain, the more you signal uncertainty. A confident, clear message is easier for clients to accept.
4. **Honour existing contracts.** If someone's mid-project or on a fixed-term arrangement, finish at the agreed price and implement the new rate at renewal.

Most clients, if they value your work, will accept a reasonable price increase. The ones who don't were probably already not your ideal clients.

---

## Scripts at a glance

**"Your price is too high"**
→ "Can you tell me more? Is it the overall investment, or is it about timing?"

**"I found someone cheaper"**
→ "Worth comparing carefully. The key differences tend to be [X, Y, Z] — do any of those matter for what you're trying to do?"

**"I need to think about it"**
→ "Of course. What would help you decide? Is there anything you'd want to know more about?"

**"Can you do it for less?"**
→ "I'm not able to reduce the price on this, but I do have a smaller option at £X that covers [core part]. Would that work better for where you are right now?"

**Raising prices with existing clients**
→ "I wanted to let you know that my rates are increasing from [date]. New projects from that date will be priced at [new rate]. I wanted to give you plenty of notice, and I'm happy to answer any questions."
