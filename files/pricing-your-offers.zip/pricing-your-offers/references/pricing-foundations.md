# Pricing Foundations

## The fundamental mistake most small businesses make

Most small business owners price their offers using cost-plus logic: work out what it costs to deliver, then add a margin on top. It feels rational. It's actually backwards.

Cost-plus pricing asks "what do I need to charge?" Value-based pricing asks "what is this worth to the person buying it?" Those are very different questions, and the second one almost always leads to a higher — and more defensible — number.

The cost of your time is not the value of your expertise. A consultant who saves a client £50,000 in a single conversation shouldn't charge £150 for the hour. The price should reflect the outcome, not the input.

## Cost vs value: the distinction that changes everything

**Cost** is what it takes to deliver your offer — your time, your tools, your overheads, your learning curve.

**Value** is the benefit your customer receives — the problem solved, the time saved, the revenue gained, the stress removed, the transformation achieved.

Prices are justified by value. Marketing's job is to make that value legible.

The gap between cost and value is where your margin lives. The wider you can make that gap — by genuinely delivering more, and by communicating it clearly — the more you can charge without resistance.

## Customer-driven pricing

The right price isn't whatever covers your costs. It's whatever your target customer will pay once they understand what your offer does for them.

This means pricing starts with understanding your customer, not your spreadsheet.

**Build a customer profile that includes:**
- The specific problem they're trying to solve
- What it costs them *not* to solve it (time, money, stress, opportunity)
- What other solutions they've tried and what they paid
- Their relationship with money — do they buy on price or on trust?
- The language they use to describe the problem

The more precisely you understand the problem your offer solves — and what that problem is costing them — the more confidently you can set and defend your price.

## The Unique Value Proposition (UVP)

A UVP is a single sentence that tells a potential customer exactly what your offer does for them and why it's different from everything else available.

**Structure:** [Offer] helps [specific customer] to [achieve outcome] by [your distinctive method or approach].

**A weak UVP:** "I help businesses with their marketing."

**A strong UVP:** "I help independent retailers sell more without spending more on ads, by building a repeat-customer system they can run in under an hour a week."

The strong version is specific about who it's for, what they get, and how it's different. That specificity is what makes a price feel justified rather than arbitrary.

**To find your UVP, answer these questions:**
1. What specific outcome do customers get from working with you?
2. What's the fastest or clearest way you deliver that outcome?
3. What do you do that no one else does, or does in the same way?
4. Why do customers come back or refer others?

Your UVP isn't just a marketing tool — it's the foundation of your pricing. If you can't articulate what makes your offer uniquely valuable, you'll always struggle to charge for it.

## Benefits vs features

When communicating value, the instinct is to list features — what the offer includes, what you deliver, how many sessions, what's in the package. Features describe the offer. Benefits describe the outcome.

**Feature:** "Six one-hour coaching sessions."
**Benefit:** "A clear business plan and the confidence to act on it, in six weeks."

Customers buy outcomes. Price to the outcome, and sell the outcome. The features are the evidence that the outcome is real.

## A note on services vs products

If you sell services rather than physical products, value-based pricing is even more important — and often more powerful. You're not selling something with a bill of materials. You're selling expertise, judgement, and outcomes. Those are genuinely hard to compare. That makes them hard to commoditise — which is exactly where you want to be.
