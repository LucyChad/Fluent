# How To Sound Human Using AI

*Installation guide*

This skill works by giving your AI assistant deep knowledge about keeping your voice when you write with AI. Once it's set up, it runs in the background of every conversation. You don't have to remind it what it knows. You just talk, and it applies the workflow to whatever you're working on.

Setup takes about ten minutes. Here's how to do it in each of the three main AI tools.

---

## Claude (claude.ai)

Claude uses **Projects** to hold permanent context. Everything you add to a Project is available in every conversation inside it.

**Step 1: Create a new Project**

- Go to claude.ai and click **Projects** in the left sidebar
- Click **New Project** and name it something like "Sound Human" or "Writing Coach"

**Step 2: Add the skill files**

Inside your project, click **Add content** (or the upload icon) and upload all the files in this skill pack:

- `SKILL.md`
- `references/voice-and-reader-snapshots.md`
- `references/prompting-for-human-drafts.md`
- `references/spotting-robot-tells.md`
- `references/adding-the-human-touch.md`
- `references/the-humaniser-workflow.md`
- `assets/voice-snapshot-worksheet.md`
- `assets/reader-snapshot-worksheet.md`
- `assets/humaniser-checklist.md`
- `assets/starter-prompt-library.md`

**Step 3: Add your business and writing context**

In the **Project instructions** field, paste and complete the following:

```
My work: [What you do — coach, consultant, writer, founder, etc.]
What I write most: [LinkedIn posts, emails, newsletters, web copy, etc.]
My main writing problem: [What you're trying to fix — too generic? too polished? too slow?]
My voice in two words: [If you've built your Voice Snapshot, paste it here. If not, leave this for now and Claude will help you build one in the first conversation.]
```

**Step 4: Start a conversation**

You're ready. Open a new chat inside the project and talk to it like you'd talk to a writing coach who already knows your voice and your reader.

A good first message: *"Help me build my Voice Snapshot — start with the questions, then we'll refine it."*

---

## ChatGPT (chat.openai.com)

ChatGPT uses **Custom GPTs** to hold specialist knowledge and instructions.

**Step 1: Create a Custom GPT**

- Go to chat.openai.com and click **Explore GPTs** in the sidebar
- Click **Create** (top right)

**Step 2: Configure it**

In the **Create** tab, describe what you want:

> "A writing coach who helps me keep my voice when I use AI to write. Knows the five-step Humaniser Workflow, can spot robot tells, and helps me build voice and reader snapshots."

Click **Configure** to set it up more precisely.

**Step 3: Add the skill files**

In the **Configure** tab, scroll to **Knowledge**. Upload all files from this skill pack — SKILL.md, all four files in `references/`, and all four in `assets/`.

**Step 4: Set the instructions**

In the **Instructions** field, paste:

```
You are a sharp, opinionated writing coach who helps me keep my voice when I use AI to write. Use the uploaded knowledge files to guide every response. Always work from my actual writing, not in the abstract. Apply the Humaniser Workflow. Ask one question at a time when you need context. Have opinions and share them.

My context:
- What I do: [fill in]
- What I write most: [fill in]
- My main writing problem: [fill in]
- My Voice Snapshot: [paste it if you have one, or leave blank]
```

**Step 5: Save and use**

Click **Save**, choose who can access it (just you is fine), and start a conversation.

---

## Gemini (gemini.google.com)

Gemini uses **Gems** to store specialist personas and knowledge.

**Step 1: Create a Gem**

- Go to gemini.google.com
- Click **Gems** in the left sidebar
- Click **New Gem**

**Step 2: Name and describe it**

- Name: *Sound Human*
- Instructions: paste the contents of `SKILL.md` into the instructions field

**Step 3: Add supporting files**

Upload the files from `references/` and `assets/` using the attachment option in the instructions area.

**Step 4: Add your context**

At the end of the instructions, add:

```
My context:
- What I do: [fill in]
- What I write most: [fill in]
- My main writing problem: [fill in]
- My Voice Snapshot: [paste it if you have one]
```

**Step 5: Save and start**

Click **Save** and open a new conversation in your Gem.

---

## What to tell it about your writing

The more context you give at setup, the more useful it is from the first conversation. Three things matter most:

**Your work.** Not your job title — what you actually produce and who you produce it for. "I'm a coach" is weak. "I'm a coach for first-time founders, mostly tech, and most of my writing is LinkedIn posts and a fortnightly newsletter to about 1,400 people" is strong.

**Your main writing problem.** Be specific. Are your drafts too generic? Too long? Too slow to write? Sounding like a stranger? Naming the actual problem makes the whole skill more useful from message one.

**Your Voice Snapshot, if you've built one.** If you haven't, that's fine — your first conversation can be building it. The worksheet in `assets/voice-snapshot-worksheet.md` walks you through it. Ten minutes of that work pays off forever.

---

## Getting the most from the skill

Some prompts to get you started:

- *"Help me build my Voice Snapshot — let's start with the questions and then refine it from a few real examples of my writing."*
- *"Run the Humaniser Checklist on this piece I just wrote."*
- *"Spot the robot tells in this paragraph and fix them."*
- *"This LinkedIn post is technically fine but it sounds like everyone else's. What's wrong with it?"*
- *"Build me a prompt I can use for my newsletter intros — make it work with my voice."*
- *"I keep getting drafts that feel polished but not personal. Diagnose what's happening."*

---

*Sound Human is part of the Fluent skill library. More skills at fluent.md.*
