# The Humaniser Checklist

Run this on every AI-assisted draft before publishing. Five questions. Ninety seconds. Catches what the rest of the workflow misses.

---

## 1. Does the tone match my Voice Snapshot?

Read three random sentences from the draft.

Could a stranger reading them tell *you* wrote them, or could those same sentences have come from any of a hundred other coaches and consultants?

If the answer is "any of a hundred others", the prompt didn't do its job. Re-prompt with a tighter tone instruction, or rewrite the sentences yourself.

- [ ] Yes — it sounds like me

---

## 2. Is this written to a specific reader, not a general audience?

Open the piece and ask: who is this aimed at, exactly?

If you can name a specific person — even an imagined one — you're fine. If your honest answer is "anyone interested in the topic", the writing is too vague and the reader will feel it before they can name why.

The fix: re-read with one specific person in mind and adjust the lines that don't quite fit them.

- [ ] Yes — there's a specific reader behind this

---

## 3. Are there any stiff or overly formal phrases I'd never say out loud?

Scan the draft for the words you tagged in your Voice Snapshot as "I never use".

Also scan for AI defaults that slip past: "utilise", "leverage", "empower", "robust", "comprehensive", "elevate", "drive", "unlock", "transform", "in today's fast-paced world", "at the end of the day", "more often than not".

Swap each one for the way you'd say it.

- [ ] Yes — they're all gone

---

## 4. Is there at least one specific example or human moment in this piece?

The general-claim trap is the one most drafts fail at. Look for the words "this", "it", "things", "stuff", "ways" — they flag general statements that could be replaced with one concrete example.

Add at least one specific. If the topic warrants it, add an empathy line — one sentence that acknowledges the difficulty without performing it.

- [ ] Yes — at least one specific or human moment is in there

---

## 5. Would I read this aloud comfortably?

The final test. Read the piece out loud, properly, not in your head.

If anything trips your tongue or sounds wrong in your own voice, mark it and fix it. If nothing snags, ship it.

This catches things the previous four questions miss — usually a sentence rhythm that looked fine on the page but doesn't survive contact with the spoken word.

- [ ] Yes — it reads aloud cleanly

---

## When you're done

If all five boxes are ticked, ship it. Resist the urge to do another pass. Over-editing is its own form of robot tell — the small awkwardnesses you'd polish out are often the small awkwardnesses that mark the writing as human.

If two or more boxes are unchecked, you've got more to do. Don't publish a piece with three failures and a hopeful caveat. Fix it.
