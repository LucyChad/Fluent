# Reader Snapshot Worksheet

A Reader Snapshot is a short, specific description of the person on the other end of the writing. Not a demographic. Not a marketing avatar. A description sharp enough that AI can choose words and assumptions correctly.

You'll write a fresh Reader Snapshot for each piece where the audience genuinely shifts. Most people end up with three or four go-to snapshots covering their main reader segments, then write one-offs for unusual pieces.

**Time it takes:** 5 minutes if you can picture a specific real person. Longer if you're trying to describe a "type" — and the result will be worse.

---

## The trick that makes this work

Don't describe a category. Describe a specific person you've actually written for, recently. The last client you sent a long email to. The reader who DM'd you after a post and asked the question you wish more people would ask. A friend who keeps asking you about this topic over coffee.

When you describe a category ("small business owners aged 35–55"), AI gets nothing useful and writes for everyone, which means writing for no one. When you describe a specific person, AI can hear them — and the writing that comes out feels like it was meant for someone real, even when other people read it.

---

## The four questions

### 1. What are they trying to do or solve right now?

The live concern, not the lifetime concern. Specific to this week or this month, not their general situation.

Not "improve their business". Try: "trying to raise prices without losing the bottom 20% of clients" or "deciding whether to fire their VA" or "staring at six bookings for next month and wondering if the slowdown is permanent".

**Their live concern:**

_______________________________________________

_______________________________________________

---

### 2. How do they describe the problem to themselves?

The actual words they'd use. The half-formed thoughts. The sentences they say to their partner over dinner when they're worrying out loud.

Not the polished version they'd say to a peer. The honest, slightly messy version.

**The actual words:**

_______________________________________________

_______________________________________________

_______________________________________________

---

### 3. What do they already know, and what don't they?

Knowing this stops the writing being patronising or going over their heads.

**They already know:**

_______________________________________________

_______________________________________________

**They don't know yet:**

_______________________________________________

_______________________________________________

---

### 4. What do they need from you to feel understood?

Sometimes a reader needs the specifics. Sometimes they need the acknowledgement that the thing is genuinely hard. Sometimes they need a clear opinion when they've been drowning in options. It's different per piece.

**For this piece, they need:**

_______________________________________________

_______________________________________________

---

## Build the snapshot

Combine your answers into a four-line block. Paste it into prompts directly under your Voice Snapshot.

```
Reader:
- Live concern: [from Q1]
- How they'd describe it themselves: "[from Q2 — in quotes if it's the words they'd use]"
- Already know: [from Q3a]. Don't know yet: [from Q3b]
- What they need from this piece: [from Q4]
```

---

## Worked example

```
Reader:
- Live concern: trying to raise prices for the first time in 18 months without losing the clients who've been with her longest.
- How she'd describe it: "I know I'm undercharging but I genuinely don't know how to send the email."
- Already knows: that her prices are out of date and that her clients can afford the new rates. Doesn't know yet: how to actually word the announcement, or whether to grandfather anyone in.
- What she needs from this piece: a worked example of an email that does it well, and someone telling her it's normal to feel sick about it.
```

That snapshot will produce drafts that meet the reader where she actually is. A generic snapshot would produce drafts that miss her entirely.

---

## How many of these to keep

Most people end up with three or four standing snapshots — one per main audience segment they write for regularly. Save them in a notes file. Update them when the audience genuinely shifts.

For one-off pieces aimed at someone specific (a sales email, a personal note, a piece for a particular client), write a fresh snapshot just for that piece. It takes five minutes. The draft quality jumps.

---

## A common mistake

The mistake is using a Reader Snapshot that's too generic — the marketing-avatar trap. "Sarah, 42, owns a service business, wants growth." That avatar generates avatar-level writing. Specific real people generate specific real writing. Always err towards specificity, even if it feels like the snapshot is "too narrow". It almost never is.
