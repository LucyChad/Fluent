# Starter Prompt Library

A working set of prompts to adapt to your own voice and reader. Each one uses the four-part structure — context, purpose, tone, reader focus — and includes placeholders where your Voice Snapshot and Reader Snapshot go.

The point of this library isn't to use these prompts verbatim. It's to give you a starting shape for the prompts *you'll* save in your own library after a few weeks of using the workflow.

---

## How to use this file

Copy the prompt you need. Replace the placeholders in `[square brackets]` with your actual content. Paste your Voice Snapshot and Reader Snapshot where indicated.

Run the prompt. If the draft is close to publishable, save the prompt — with your customisations — to your personal library.

If it's not close, change *one* thing (tone cues, reader sharpness, or the purpose), re-run, evaluate. Don't rewrite the whole prompt every time.

---

## LinkedIn post — single point

```
Write a LinkedIn post that makes one specific point about [topic].

The point: [the one thing you want a reader to take away]

Length: 100–180 words. No CTA. No hashtags. End on the most surprising
or sharpest sentence — not a tidy conclusion.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Avoid: rhetorical questions answered in the next sentence; setup-and-pivot
sentences; em dashes used as connective tissue; the words "unlock",
"empower", "journey", "robust", "transform"; opening with "Whether you're".

Open with a fragment or a one-line claim. Use contractions throughout.
Maximum 18 words per sentence except for one or two that earn the length.
```

---

## Newsletter intro — three to four paragraphs

```
Write the opening section of a newsletter that frames today's main
topic and earns the click to keep reading.

Topic: [topic]

What the reader should take away from the intro alone: [outcome]

Length: 120–200 words across three or four short paragraphs.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Structure rules:
- Open with a specific scene, sentence, or claim — never a generality.
- One paragraph maximum on what the topic is.
- One paragraph that names something the reader is probably feeling
  about it.
- One paragraph that previews what the rest of the piece will give them
  without giving it away.

Avoid: "in today's fast-paced world", "at the end of the day", any version
of "let me ask you a question", any rhetorical question.
```

---

## Sales email for an existing offer

```
Write a sales email to [reader] about [offer].

What the reader should walk away believing: [the core belief shift]

What they should do at the end: [single specific action]

Length: 220–320 words.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Structure:
- Subject line: under 7 words. Curiosity over hype.
- Open: name the specific situation the reader is in. Not the topic — the situation.
- Middle: explain the offer in terms of what changes for them. Use one specific example
  of a result, not a general claim.
- Close: the action they should take, plus one line that lowers their risk
  (a guarantee, a way to ask questions, a small step).

Avoid: bullet lists of features, the words "transform" / "unlock" / "amazing",
all-caps for emphasis, exclamation marks (one allowed if it really earns it),
any line that begins "Whether you're".

End on a sentence that sounds like you, not like a salesperson.
```

---

## Podcast or video show notes

```
Write the show notes for an episode where I [discuss / interview / explain]
[topic].

Length: 250–350 words.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Structure:
- 2 sentence open that frames the episode's main idea — not what we
  "covered", but what we figured out.
- 4–6 bullets of what the listener will get. Each bullet is a specific
  takeaway, not a topic. ("How to handle the price-objection email
  without flinching" — not "objection handling".)
- 2 sentence close that invites the listener to send a reply or ask
  a question.

Avoid: "in this episode we discussed", "tune in", "join us", "we hope
you enjoyed", and any sentence beginning "Whether you're".
```

---

## Quick caption / Instagram post

```
Write a short Instagram caption to go with a [photo / quote / behind-the-
scenes] post about [topic].

Length: 50–100 words.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Open with a sentence that earns the second sentence. End with one specific
ask or one observation that lands. No CTAs that read like CTAs. No
emoji bullets.

Avoid: "double tap if", "comment below", "tag a friend who", any opening
that begins with "POV:" or "Reminder:".
```

---

## Cold outreach (with care)

```
Write a short outreach message to [recipient context] about [reason].

What I want from them: [specific small ask, not a full meeting]

Length: 80–130 words.

Voice: [paste Voice Snapshot]

Reader: [paste Reader Snapshot]

Structure:
- Open with one sentence that proves I've actually paid attention to who
  they are and what they're working on. No flattery. One real, specific
  observation.
- One sentence that says why I'm writing.
- One sentence that names the small ask.
- A close that doesn't beg.

Avoid: "I hope this finds you well", "I'd love to pick your brain", any
sentence using the word "synergy", "value-add", or "circle back". Never
open with "My name is" or "I am".
```

---

## Re-prompts when a draft is off

When the draft is wrong in *register* rather than detail, don't edit. Re-prompt with one of these:

```
Rewrite this so it sounds like I'm explaining it to a friend over coffee,
not delivering a presentation.
```

```
Same content, but conversational. Use contractions. Cut the lede.
Start with the most surprising sentence in the piece.
```

```
This is too polished. Make it feel like I dashed it off in five minutes —
confident but unfussy. Keep the structure, change the texture.
```

```
Take out every em dash that isn't doing real work. Replace each one
with a full stop or a comma. Read what's left and tell me where it now
needs tightening.
```

---

## How to grow this library into your own

After two weeks of using the workflow, you'll know which formats you write most often and which prompts produce the cleanest first drafts. Move those into your own file. Replace these starter prompts with your refined versions.

A library that's *yours* — that knows your voice and your reader at the level of saved-prompt detail — is genuinely transformative. It compounds. By month three, most users have eight to twelve prompts that produce publishable drafts on the first try.

That's the real goal. This file is just the on-ramp.
