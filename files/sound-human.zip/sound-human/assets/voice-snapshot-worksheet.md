# Voice Snapshot Worksheet

A Voice Snapshot is a short, paste-able description of how you actually write. Not how you wish you wrote. Not your brand voice document. The honest version.

Fill this in and you'll have a five-line block you can paste into any prompt to get drafts that sound dramatically more like you.

**Time it takes:** 10–15 minutes if you have a few of your real emails or posts to skim. Doing it cold from memory takes longer and produces a vaguer snapshot.

---

## Before you start

Open three pieces of writing you've produced recently without AI help. Real emails, LinkedIn posts, voice notes you transcribed. Skim them with these questions in mind. Patterns will jump out within a few minutes.

---

## The five questions

### 1. How do you sound when you're not performing?

Pick two adjectives that genuinely fit. Avoid the obvious safe ones — "professional" and "approachable" describe almost everyone, so they describe no one.

Try harder. Direct? Dry? Warm? Blunt? Playful? Considered? Mildly contrarian? Quietly confident? Disarmingly honest?

**Two adjectives:**

_______________________________________________

_______________________________________________

---

### 2. What sentence shape do you favour?

Tick everything that genuinely applies:

- [ ] Short and declarative
- [ ] Longer and rhythmic
- [ ] Comfortable with sentence fragments
- [ ] Use one-word paragraphs for emphasis
- [ ] Active voice almost always
- [ ] Allergic to semicolons
- [ ] Prefer commas to dashes (or the other way round)
- [ ] Often start sentences with "But", "And", or "So"
- [ ] Use the occasional aside in brackets
- [ ] Keep it tight — fewer than 18 words per sentence most of the time

---

### 3. Which phrases or constructions do you actually use?

The ones that show up in your real writing — not the ones you wish you used. List five to eight:

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________
6. _______________________________________________
7. _______________________________________________
8. _______________________________________________

---

### 4. Which phrases or constructions would you never use?

The negative space. The words that feel like a stranger when you see them in your own drafts. List five to eight:

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________
6. _______________________________________________
7. _______________________________________________
8. _______________________________________________

---

### 5. A sentence you wrote recently that you're proud of

One real example beats ten adjectives. Paste it below. Don't tidy it up.

_______________________________________________

_______________________________________________

_______________________________________________

---

## Now build the snapshot

Combine your answers into a five-line block. Use this template, adjust the structure, paste it as-is into prompts.

```
Voice:
- Tone: [two adjectives from Q1]
- Sentence shape: [a sentence describing your shape from Q2]
- I use: [3 phrases or constructions from Q3]
- I never use: [3 things from Q4]
- A sample of my real writing: "[paste from Q5]"
```

---

## Worked example

Here's what one finished Voice Snapshot looks like. Yours doesn't need to be similar in tone — only similar in specificity.

```
Voice:
- Tone: warm but a bit blunt. Comfortable being mildly contrarian.
- Sentence shape: short, mostly. Frequent sentence fragments. One-word paragraphs for emphasis. Active voice.
- I use: "right", "honestly", "the obvious mistake here is", "—" only when I really mean it.
- I never use: "unlock", "empower", "journey", "robust", "drive results", exclamation marks (almost never).
- A sample of my real writing: "Most pricing problems aren't pricing problems. They're confidence problems. The price is fine. The story you tell yourself about the price is broken."
```

That snapshot, pasted into any prompt, will radically improve the first draft. Yours will too.

---

## Two things to remember

**Update it every couple of months.** Your voice evolves. A snapshot written in January is probably wrong by July.

**It's allowed to be unfinished.** Better to ship a rough snapshot today than a perfect one in three weeks. You'll improve it as you use it.
