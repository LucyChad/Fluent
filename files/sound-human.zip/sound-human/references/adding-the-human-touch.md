# Adding the Human Touch

## What this step is for

By the time a draft has been through a Voice Snapshot, a strong prompt, and a robot-tell clean-up, it reads well. It's not embarrassing. The grammar is fine. The tone is closer to right.

It might still be cold.

There's a final layer that AI cannot supply on its own, because it requires the writer's actual life experience and judgement: the small touches that make the reader feel addressed by a human being who understands them. Without these, content is technically correct and emotionally inert. Readers don't share emotionally inert content. They don't remember it. They don't trust the writer enough to buy from them.

This step adds two or three small, specific things to a draft. Nothing dramatic. Nothing performative. Just enough to make the difference between competent and connecting.

## What human connection actually means

Connection in writing isn't about telling stories. It isn't about being vulnerable on demand. It's about giving the reader the felt sense that the writer knows what they're going through — that the writer has been close enough to the situation to describe it accurately and kindly.

That feeling is built from very small materials:

- One sentence that names the reader's actual experience, in their actual words
- One specific example that proves the writer has been there themselves
- One line of empathy that acknowledges something is hard, without sentimentalising it

A piece with one of these in it feels different to read than a piece with none of them. The reader doesn't know why they trust this writer more. They just do.

## The specificity move

The single most powerful upgrade to AI-generated writing is replacing one general statement with one specific example. AI defaults to general statements because they're safe and broadly applicable. Generality is also what makes the writing feel hollow.

**General:** "This step is important."
**Specific:** "Skip this step and your client either ghosts you in week three or asks for a discount in week four."

**General:** "It saves you time."
**Specific:** "It saves the eleven minutes you currently spend every Monday wondering what to post."

**General:** "Your customers will appreciate the difference."
**Specific:** "Two of mine asked, on the same day, what had changed."

The pattern: the general claim says *that* something is true. The specific example *shows* it's true. Showing always lands harder than telling.

When editing AI drafts, hunt for the words "this", "it", "things", "stuff", "ways" — they're flags for general statements that could be replaced with one concrete thing.

## The empathy line

Most writing about a problem skips straight to the solution. That feels efficient and is actually a mistake. Readers respond when the writer pauses for one sentence to acknowledge that the problem is real and difficult.

Empathy lines are short. They don't perform. Examples that work:

> "I know this part is annoying — it was annoying for me too."

> "If you're staring at this thinking it sounds like a lot of work, you're not wrong."

> "Most people I've worked with hated this step at first."

> "This was the part I got wrong for a year."

What's happening in those lines: the writer is briefly stepping out from behind the explanation to be a person for one sentence, then stepping back. Done well, it costs the reader half a second of reading time and earns the writer enormous goodwill.

Done badly — too long, too earnest, too humble-bragging — it backfires. One sentence. No more.

## What to avoid

**Stories for the sake of stories.** AI-generated content has trained a lot of people to open with a personal anecdote that connects loosely to the topic. It rarely works. The anecdote takes 80 words and the payoff isn't worth it. If a story belongs in the piece, it belongs structurally — not as flavour.

**Performed vulnerability.** "I used to struggle so much with this" is fine if it's true and short. It's not fine if it's a calculated trust-building move with no specifics behind it. Readers can tell.

**Generic uplift.** "You've got this!" "You're amazing!" "Believe in yourself!" These read as filler. Readers don't believe AI when it cheerleads, and they don't believe writers who use AI to cheerlead.

**Over-explaining the empathy.** If the writer says "this is hard, I know it's hard, I've been there, I want you to know I see you" — the reader switches off. One line, clearly placed, then move on.

## The Trust Check

Before publishing anything that's been through this process, run one question:

> "Would a real person who actually cares about the reader say it this way?"

Read the piece with that question in mind. Underline anything that fails. Adjust those lines specifically. The check takes ninety seconds.

It catches the things the previous steps miss — the lines that are technically correct, free of robot tells, on-brand for the voice, and still somehow distant. Usually those lines are the ones where the writing is *talking at* the reader rather than *to* them. The Trust Check makes them visible so they can be fixed.

## How much human touch is enough

Two adjustments per piece is plenty. One specific example replacing one general claim. One empathy line where the topic warrants it. That's enough to move a piece from technically capable to genuinely connecting.

More than two and the piece tips over into trying-too-hard. The writing should feel like a real person, not a real person performing realness.
