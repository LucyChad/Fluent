# Prompting for Human Drafts

## The point of a good prompt

Most people prompt AI like they're searching Google: short string, vague hope, regret afterwards. The drafts they get back are competent and characterless and require half an hour of editing to feel like theirs. They blame the AI.

The fix is the prompt. A good prompt isn't longer for the sake of being longer — it gives the AI four specific bits of information it can't guess, and the draft that comes back is 70% of the way there instead of 30%. The user's editing time drops from half an hour to five minutes. The voice survives. That's the whole game.

## The four parts of a prompt that produces a human first draft

Every prompt that consistently works contains:

**Context.** What is this piece, where will it live, what's the format? "A LinkedIn post" is context. "A 150-word LinkedIn post that opens with a question and ends without a CTA" is better context.

**Purpose.** What should the reader take away or do? Not what the writer wants to say. What the reader should walk away with. "Make them realise their pricing is broken" is a purpose. "Discuss pricing" is not.

**Tone.** This is where the Voice Snapshot goes. Not a one-word tone like "casual". The actual five-line snapshot.

**Reader focus.** This is where the Reader Snapshot goes. Specific enough that the AI can choose words and assumptions correctly.

A prompt missing any one of those four will produce a draft that's clearly off in the corresponding way. Missing context: wrong format. Missing purpose: vague point. Missing tone: stranger's voice. Missing reader: writing aimed at no one in particular.

## Tone cues that actually do something

Vague tone cues are decoration. Specific tone cues are instructions.

**Decoration:** "friendly", "professional", "approachable", "engaging".

**Instruction:** "use contractions", "max 18 words per sentence", "no questions in the opening line", "no em dashes", "no rhetorical questions answered in the next sentence", "include one specific example", "write like you're emailing one person, not a list".

Cues phrased as concrete rules outperform cues phrased as adjectives every time. Adjectives are interpreted. Rules are applied.

When helping a user write tone cues, ask them: what specifically would you delete if you saw it in the draft? Those deletions become the cues, phrased as "don't".

## The "AI as first draft" mindset

Users come to AI hoping for the perfect prompt — one that produces a publishable piece on the first try. That's the wrong target. The right target is a first draft that's close enough to fix in five minutes.

Reframe it for them: AI is the world's fastest first-drafter, not a content factory. Their judgement adds the last 30%, which is where the writing becomes theirs. If they keep trying to engineer the perfect prompt, they're just delaying the editing they were always going to need to do — and they'll burn more time fiddling with prompts than they would have spent editing a decent draft.

The 70/30 split is the goal. AI gets you to 70%. You take it to 100%.

## How to test and refine a prompt

The most useful exercise is the A/B comparison. Ask the AI to write the same piece twice — once with a bare-bones prompt (just the topic), once with the full four-part prompt. Show the user both drafts side by side.

The difference is always obvious. The bare prompt produces something that could have been written for anyone. The full prompt produces something with a specific voice and a specific reader in mind. The user *feels* it before they can articulate why.

Once a prompt produces a draft they'd be happy to edit lightly and ship, save it. That prompt becomes the template for everything in that category — LinkedIn posts, newsletter intros, podcast show notes, sales emails. Most users land on a working prompt for each format after two or three rounds of small adjustments.

## Variations worth testing

When a prompt is *almost* working but not quite, change one variable at a time:

- Tighten the tone cues — replace adjectives with rules
- Sharpen the reader — make them more specific
- Cut the purpose down to one outcome
- Add a constraint — word count, sentence length, structural rule

Avoid the temptation to rewrite the whole prompt every time something's off. One change, re-test, evaluate, repeat. This is how prompt libraries get built.

## The biggest prompting mistake

The biggest mistake is asking AI to do too much in a single prompt. "Write a 600-word newsletter about my new offer that introduces it, builds desire, handles objections, and ends with a strong CTA, in my voice" is asking for a finished piece. The AI will produce something that's technically a finished piece and feels like ten templates stitched together.

Better: prompt for one thing at a time. The lede. The setup. The pitch. The CTA. Each section gets its own prompt with its own purpose. The pieces stitch together more cleanly because each one was written for one job.

This sounds slower. It's not. The total time is shorter because the editing time collapses.

## When to stop prompt-engineering and start writing

If a user has rewritten their prompt four times and still isn't happy with the draft, the prompt isn't the problem. The piece itself is unclear in their head. Tell them to write three sentences in plain prose describing what they want this thing to do — for whom, why, and what they want the reader to feel by the end. That clarity exercise solves more drafts than any further prompt fiddling.
