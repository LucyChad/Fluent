# Spotting Robot Tells

## What a robot tell is

A robot tell is a pattern in AI-generated writing that, once you've seen it, you can't unsee. The text reads as competent. It has no obvious mistakes. But there's a faint plastic quality to it that experienced readers register subconsciously — and increasingly, ordinary readers register consciously.

This is the layer most people don't catch with quick edits, because individually each tell is grammatically fine. The problem is the *accumulation*. Three tells in a paragraph and the reader's brain has clocked "this was written by AI" before they could put their finger on why.

The fixes are fast — under two minutes per tell once you've trained your eye. The catalogue below is what to look for and what to do.

## The catalogue

### 1. The em dash, used as connective tissue

Em dashes are a real punctuation mark with a real job. AI uses them constantly, almost as a default sentence joiner, and the result is prose that feels permanently mid-thought.

**The fix:** in most cases, replace with a full stop or a comma. The reader's pace improves. Save the em dash for the one moment in the piece where it actually earns its keep.

### 2. Setup-and-pivot sentences

A pattern where the first half of the sentence sets up an idea and the second half pivots to a related-but-different idea, joined by "and" or a comma. Reads smoothly. Adds nothing.

> "Pricing your offer well is essential, and it also signals to your clients that you take your business seriously."

The first clause is the actual point. The second clause is restating the first clause with different vocabulary. Cut it.

**The fix:** keep the first half. Delete the pivot. The sentence almost always gets stronger.

### 3. Questions immediately answered in the next sentence

> "Why does this matter? Because it changes how your readers feel about your business from the very first impression."

The rhetorical question is not adding anything the answer wouldn't have delivered alone. AI reaches for this pattern when it's been told to write "engagingly". It's the sound of someone trying.

**The fix:** delete the question. Lead with the answer. The writing gets more direct and the reader doesn't feel handheld.

### 4. Filler phrases and "word salad"

Phrases that sound like they're saying something but evaporate when you press on them.

> "in today's fast-paced world", "at the end of the day", "the reality is", "more often than not", "when it comes to", "it's important to note that".

**The fix:** delete on sight. The sentence almost always still works without them.

### 5. Inflated vocabulary

When AI reaches for the formal version of a word that has a perfectly good plain version. "Utilise" instead of "use". "Implement" instead of "do". "Significantly elevate" instead of "lift". "Robust framework" instead of "system that works".

**The fix:** swap for the word the user would actually say out loud. Read aloud test: if they wouldn't say it in conversation, it shouldn't be in the post.

### 6. Long, multi-idea sentences

The most common giveaway. AI sentences trying to cover three points in one breath, joined by commas, semicolons, and gerunds.

> "By learning to identify your voice and apply it consistently across every piece of content you produce, you create a stronger connection with readers, who in turn become more engaged with your business and more likely to convert into paying clients."

That's four ideas in one sentence. No human writes that way.

**The fix:** find the natural breaks. Make it three or four sentences. Cut the weakest of the four. The reader's pace doubles.

### 7. Repetitive sentence openings

Three paragraphs in a row that start with "Whether", or "When", or a participle. AI loves a consistent rhythm because it learned from documents that prized consistency. Real writing varies.

**The fix:** open one paragraph with a fragment. Start another with a one-word sentence. Mix it up.

### 8. Hollow enthusiasm

The default upbeat AI tone — exclamation marks, "amazing", "powerful", "transform". It has the energy of a stock photo.

**The fix:** delete the exclamation marks. Replace "amazing" with the specific thing that's actually impressive. Replace "transform" with what specifically changes.

## The three-fix edit

For any AI paragraph that needs sharpening but isn't worth a full rewrite, the three-fix edit takes about ninety seconds:

1. **Shorten one line.** Pick the longest sentence. Cut it by 30%.
2. **Split one sentence.** Find a multi-idea sentence and break it where it naturally wants to break.
3. **Swap one formal word.** Find one inflated word and replace it with the way the user would say it.

Three small changes. The paragraph reads dramatically better. This is what to use 80% of the time.

## When to re-prompt instead

If the whole tone is wrong — not just a sentence here and there but the *register* — quick edits won't save it. Re-prompt instead. The phrasings that work:

> "Rewrite this so it sounds like I'm explaining it to a friend over a coffee, not delivering a presentation."

> "Same content, but conversational. Use contractions. Cut the lede. Start with the most surprising sentence."

> "This is too polished. Make it feel like I dashed it off in five minutes — confident but unfussy."

Re-prompt sparingly. If you're re-prompting more than once, the prompt itself is the problem and you should go back to fix that.

## When to stop editing

The read-aloud test ends the process. Read the piece out loud. If nothing trips up your tongue and the rhythm feels natural, it's done. If something snags, fix the snag. If nothing snags, ship it.

Over-editing is its own form of robot tell. Writing that's been polished too many times loses the small awkwardnesses that mark it as human. Stop sooner than feels comfortable.
