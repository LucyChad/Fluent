# The Humaniser Workflow

## What the workflow is for

The previous four steps are the components: voice and reader, prompting, fixing the tells, adding the human touch. The workflow is the order in which they get used and the discipline that makes them repeatable.

Most people who learn the components go back to their old chaotic process within a fortnight. They write a prompt, get a draft, and start fiddling with whatever bothers them most. The output is better than before, but it's inconsistent and they're still spending too long on each piece.

The workflow fixes that. It's a four-stage process you can run on any piece of writing, in any format, without having to think about what to do next.

## The four stages, in order

**Stage 1 — Direct.** Set the voice and reader before the AI does anything. Paste the Voice Snapshot. Paste a Reader Snapshot for this specific piece. This stage takes thirty seconds if the snapshots already exist. It saves twenty minutes downstream.

**Stage 2 — Prompt.** Write the four-part prompt: context, purpose, tone, reader focus. Generate the draft. If it's clearly wrong in tone or register, re-prompt once. Don't fix anything yet.

**Stage 3 — Fix.** Run the three-fix edit on each paragraph: shorten one line, split one sentence, swap one formal word. Hunt the catalogue of robot tells. Cut the em dashes that aren't earning their keep, kill the setup-and-pivot sentences, delete the rhetorical questions answered in the next breath.

**Stage 4 — Touch.** Add up to two human elements: replace one general statement with a specific example, add one empathy line if the topic warrants it. Run the Trust Check. Read aloud. Ship.

That's the whole workflow. Twenty minutes for a LinkedIn post, an hour for a 1,500-word piece, faster as the user gets fluent in the steps.

## Why the order matters

Each stage protects the next stage from doing the wrong work.

Stage 1 protects Stage 2 from producing generic drafts. Stage 2 protects Stage 3 from having to do massive rewrites. Stage 3 protects Stage 4 from polishing a piece that still has structural problems. Stage 4 catches what the earlier stages can't.

People who skip Stage 1 spend their lives in Stage 3, fixing tells that wouldn't have appeared if the prompt had been better. People who skip Stage 4 ship technically-correct content that no one shares. The order is load-bearing.

## The Humaniser Checklist

Stage 4 includes running a five-question checklist on the draft before publishing. The questions:

1. **Does the tone match my Voice Snapshot?** Read three random sentences. Could a stranger reading them tell you wrote them?
2. **Is this written to a specific reader, or to a general audience?** Vague writing is the symptom of a vague reader.
3. **Are there any stiff or overly formal phrases I'd never say out loud?** If yes, swap them.
4. **Is there at least one specific example or human moment in this piece?** If not, the writing is probably technically fine and emotionally inert.
5. **Would I read this aloud comfortably?** Read it. If anything trips you up, fix it. If nothing does, ship it.

Five questions. Ninety seconds. Done.

## Building the Prompt Library

Every time the workflow produces a prompt that consistently delivers a strong first draft, save it. Over time, the user accumulates a personal Prompt Library — usually 8 to 15 prompts that cover their main writing formats: social posts, newsletter intros, sales emails, podcast show notes, web copy.

The library compounds. Each new prompt benefits from the lessons of the previous ones. After two or three months of disciplined saving, most users have a library that produces publishable drafts on the first attempt 70% of the time, and the other 30% needs only Stage 3 cleanup.

Where to keep the library: a Notion page, a single document, a notes app, the bottom of the SKILL.md. The format matters less than the habit of adding to it. The Prompt Library asset in this skill pack is a starter set the user can adapt.

## Style patterns to keep an eye on

Even after Stage 3, AI has a few sentence patterns it returns to that aren't strictly robot tells but flatten the writing:

**Tricolons used for rhythm rather than meaning.** "It's faster, it's clearer, and it's more enjoyable." Sometimes a list of three is exactly right. Often it's a stand-in for "I needed to make this sentence feel finished".

**Pivots from one register to another within a sentence.** "This shifts how you communicate, which ultimately drives stronger relationships." The first half is plain. The second half is corporate. The mismatch is jarring.

**Dramatic punctuation.** Em dashes that make a beat into a sigh. Ellipses where a full stop would do.

**Inflated qualifiers.** "Truly", "incredibly", "absolutely", "fundamentally". Cut them on sight unless they're load-bearing.

These won't kill a piece. They'll make a good piece feel slightly less alive. Watch for them in Stage 3.

## How to keep the workflow alive over time

Two habits keep the workflow useful instead of becoming theatre:

**Review your snapshots monthly.** Five minutes, last Friday of the month. Re-read the Voice Snapshot. Update one line if your voice has shifted. Re-read the Reader Snapshot for the audiences you actually wrote for that month. Adjust as needed.

**Add to the Prompt Library every time something works.** It takes thirty seconds at the end of a writing session. Most people forget. Build the habit and the library doubles in value every quarter.

**Run the workflow even when you're in a hurry.** The temptation when a deadline is tight is to skip Stages 1 and 4 and go straight to a rough draft. Don't. The whole workflow takes twenty minutes. Skipping it doesn't save time — it shifts the time onto editing the wrong things.

The point of the workflow is to free up the user's attention for the part that actually matters: the human judgement that makes their writing theirs. Everything before that is mechanical. The workflow makes it mechanical so they can stop thinking about it.
