# Voice and Reader Snapshots

## Why this is the one step nobody skips

Most people who use AI to write have never properly described their own voice, and they've certainly never described their reader. Then they sit down, type "write a LinkedIn post about pricing", get something competent and bland, and assume the problem is the AI.

The problem is that they handed the AI a blank canvas and asked it to be them. The AI did the only thing it can do without information: pattern-matched to the average post on the topic. That's where the homogeneity comes from. Not from the model. From the missing brief.

Voice and Reader snapshots are how you fix this in fifteen minutes and never have to fix it again.

## What a Voice Snapshot actually contains

A Voice Snapshot is a short, paste-able description of how the user actually writes. It's not a brand voice document and it's not aspirational. It's an honest description of the writing they already produce when they're not trying.

The minimum viable Voice Snapshot answers five questions:

1. **How do you sound when you're not performing?** Direct, warm, dry, blunt, playful, considered? Pick two adjectives that genuinely fit and avoid the obvious ones — "professional" and "approachable" describe almost everyone.
2. **What sentence shape do you favour?** Short and declarative, or longer and rhythmic? Mostly active voice? Comfortable with fragments? Allergic to semicolons?
3. **Which phrases or constructions do you actually use?** Not the ones you wish you used. The ones that show up in your real emails and posts.
4. **Which phrases or constructions would you never use?** This is the negative space. "Unlock". "Empower". "Game-changer". "Robust". "Journey". The list is personal.
5. **What's a sentence you wrote recently that you're proud of?** One real example beats ten adjectives.

Tell them: skim the last ten emails or LinkedIn posts they wrote without AI help. Patterns appear within five minutes.

## Why "warm and friendly" is not a Voice Snapshot

If a user gives you a Voice Snapshot that reads "warm, friendly, approachable, professional", the snapshot is doing nothing. Those words apply to about 80% of small business writing. They give the AI no information.

A Voice Snapshot has to discriminate. It has to tell the AI something it couldn't have guessed. "Warm but a bit blunt — comfortable being mildly contrarian. Short sentences. Hates the word 'journey'. Will use a one-word paragraph for emphasis." That's a snapshot.

Push back on bland snapshots. They're worse than no snapshot — they invite generic output and feel like they shouldn't.

## What a Reader Snapshot actually contains

A Reader Snapshot is a short description of the specific person on the other end of the writing. Not a demographic. Not an avatar with a stock photo. A description that tells the AI what to assume about what the reader knows, what they care about, and how they talk.

The four things to capture:

1. **What they're trying to do or solve right now** — the live concern, not the lifetime concern. "Trying to raise prices without losing the bottom 20% of clients" is more useful than "small business owner".
2. **How they describe the problem to themselves** — the actual words they'd use, the half-formed thoughts. This is where AI gets the language right.
3. **What they already know, and what they don't** — so the writing doesn't over-explain or under-explain.
4. **What they need from you to feel understood** — sometimes it's specifics, sometimes it's the acknowledgement that the thing is hard. Different posts call for different things.

Reader Snapshots are different per piece. Voice Snapshots stay broadly stable. The user only writes the Voice Snapshot once. They write a fresh Reader Snapshot each time the audience genuinely shifts.

## Pasting both into a prompt

Once both snapshots exist, the user can append them to almost any prompt and the quality of the first draft jumps immediately. The structure that works:

> [The actual instruction — what you want written, what it's for.]
>
> Voice: [paste Voice Snapshot]
>
> Reader: [paste Reader Snapshot]

That's it. It looks unsophisticated. It's load-bearing.

## Common mistakes when building snapshots

**Writing the voice you wish you had.** The snapshot has to describe the writing the user actually produces, not the writing they admire. Aspirational snapshots produce aspirational drafts that don't sound like the user — which is exactly the problem they were trying to solve.

**Confusing tone with topic.** "I write about pricing strategy" is a topic, not a voice. The voice is *how* they write about pricing strategy.

**Going too long.** Five sharp lines beat a thousand-word brand bible. The AI will use 30% of what you give it. Make sure the most important 30% is the bit it can't ignore.

**Treating it as a one-off.** Voice evolves. A snapshot written in January is probably wrong by July. Reviewing the snapshot every couple of months — and updating one or two lines — keeps it honest.

## How to help a user build theirs in conversation

The fastest way is to ask them to paste two or three pieces of their own real writing, then draft a Voice Snapshot from that and let them refine it. Five questions answered cold rarely produce a good snapshot. Five questions answered while looking at their own sentences usually do.

For the Reader Snapshot, ask: who's the last specific person you wrote this kind of thing for, and what were they actually worrying about that day? The specificity unlocks the rest.
